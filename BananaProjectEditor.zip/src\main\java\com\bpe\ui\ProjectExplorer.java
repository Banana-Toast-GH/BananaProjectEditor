package com.bpe.ui;

import com.bpe.project.*;
import com.bpe.editor.EditorFrame;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.File;
import java.util.List;

public class ProjectExplorer extends JFrame {

    private ProjectHistory history;
    private JPanel recentPanel;
    private ProjectTemplates.Template selectedTemplate = null;

    public ProjectExplorer() {
        history = new ProjectHistory();
        setTitle("Banana Project Editor");
        setSize(960, 600);
        setMinimumSize(new Dimension(800, 500));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setIconImage(BPETheme.createBananaIcon(32));
        getContentPane().setBackground(BPETheme.BG_DEEPEST);
        setLayout(new BorderLayout());

        add(buildSidebar(), BorderLayout.WEST);
        add(buildMain(), BorderLayout.CENTER);
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                // Subtle gradient
                GradientPaint gp = new GradientPaint(0, 0, BPETheme.BG_DEEP, getWidth(), getHeight(), new Color(28, 28, 32));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                // Right border
                g2.setColor(BPETheme.BORDER);
                g2.drawLine(getWidth() - 1, 0, getWidth() - 1, getHeight());
            }
        };
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(240, 0));
        sidebar.setOpaque(false);
        sidebar.setBorder(BorderFactory.createEmptyBorder(32, 20, 24, 20));

        // Banana icon + logo
        JPanel logoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        logoPanel.setOpaque(false);
        logoPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Banana icon
        JLabel iconLabel = new JLabel(new ImageIcon(BPETheme.createBananaIcon(36)));
        logoPanel.add(iconLabel);
        logoPanel.add(Box.createHorizontalStrut(10));

        JPanel titleStack = new JPanel();
        titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
        titleStack.setOpaque(false);
        JLabel bpe = new JLabel("BPE");
        bpe.setForeground(BPETheme.ACCENT);
        bpe.setFont(new Font("Consolas", Font.BOLD, 26));
        JLabel full = new JLabel("Project Editor");
        full.setForeground(BPETheme.TEXT_SECONDARY);
        full.setFont(BPETheme.FONT_MONO_SMALL);
        titleStack.add(bpe);
        titleStack.add(full);
        logoPanel.add(titleStack);

        sidebar.add(logoPanel);
        sidebar.add(Box.createVerticalStrut(40));

        // New Project button - accent colored
        JButton newBtn = BPETheme.primaryButton("  + New Project");
        newBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        newBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        newBtn.addActionListener(e -> showNewProjectDialog());
        sidebar.add(newBtn);

        sidebar.add(Box.createVerticalStrut(10));

        // Open Project button
        JButton openBtn = BPETheme.secondaryButton("  Open Project...");
        openBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        openBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        openBtn.addActionListener(e -> openProject());
        sidebar.add(openBtn);

        sidebar.add(Box.createVerticalGlue());

        // Version
        JLabel ver = new JLabel("BCode v1.0  |  Java " + System.getProperty("java.version"));
        ver.setForeground(BPETheme.TEXT_DIM);
        ver.setFont(BPETheme.FONT_MONO_SMALL);
        ver.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(ver);

        return sidebar;
    }

    private JPanel buildMain() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(BPETheme.BG_DEEPEST);
        main.setBorder(BorderFactory.createEmptyBorder(32, 28, 24, 28));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));

        JLabel title = new JLabel("Recent Projects");
        title.setForeground(BPETheme.TEXT_PRIMARY);
        title.setFont(BPETheme.FONT_MONO_LARGE);
        header.add(title, BorderLayout.WEST);

        JButton clearBtn = new JButton("Clear History");
        clearBtn.setFont(BPETheme.FONT_MONO_SMALL);
        clearBtn.setForeground(BPETheme.TEXT_DIM);
        clearBtn.setBackground(BPETheme.BG_DEEPEST);
        clearBtn.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        clearBtn.setFocusPainted(false);
        clearBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        clearBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(ProjectExplorer.this,
                "Clear all recent project history?", "Clear History", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                for (ProjectHistory.HistoryEntry entry : new java.util.ArrayList<>(history.getEntries())) {
                    history.removeEntry(entry.path);
                }
                refreshRecent();
            }
        });
        header.add(clearBtn, BorderLayout.EAST);

        main.add(header, BorderLayout.NORTH);

        recentPanel = new JPanel();
        recentPanel.setLayout(new BoxLayout(recentPanel, BoxLayout.Y_AXIS));
        recentPanel.setBackground(BPETheme.BG_DEEPEST);
        refreshRecent();

        JScrollPane scroll = new JScrollPane(recentPanel);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setBackground(BPETheme.BG_DEEPEST);
        scroll.getViewport().setBackground(BPETheme.BG_DEEPEST);
        scroll.getVerticalScrollBar().setBackground(BPETheme.BG_DEEP);
        main.add(scroll, BorderLayout.CENTER);

        return main;
    }

    private void refreshRecent() {
        recentPanel.removeAll();
        List<ProjectHistory.HistoryEntry> entries = history.getEntries();

        if (entries.isEmpty()) {
            JPanel empty = new JPanel(new BorderLayout());
            empty.setBackground(BPETheme.BG_DEEPEST);
            empty.setBorder(BorderFactory.createEmptyBorder(40, 0, 0, 0));
            JLabel msg = new JLabel("No recent projects — create or open one to get started");
            msg.setForeground(BPETheme.TEXT_DIM);
            msg.setFont(BPETheme.FONT_MONO);
            msg.setHorizontalAlignment(SwingConstants.CENTER);
            empty.add(msg, BorderLayout.CENTER);
            recentPanel.add(empty);
        } else {
            for (ProjectHistory.HistoryEntry entry : entries) {
                recentPanel.add(makeRecentCard(entry));
                recentPanel.add(Box.createVerticalStrut(6));
            }
        }
        recentPanel.revalidate();
        recentPanel.repaint();
    }

    private JPanel makeRecentCard(ProjectHistory.HistoryEntry entry) {
        boolean exists = new File(entry.path).exists();

        JPanel card = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                g2.setColor(BPETheme.BORDER);
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
            }
        };
        card.setOpaque(false);
        card.setBackground(BPETheme.BG_MID);
        card.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 64));
        card.setCursor(exists ? Cursor.getPredefinedCursor(Cursor.HAND_CURSOR) : Cursor.getDefaultCursor());

        // Left: banana dot + name/path
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);

        JLabel nameLabel = new JLabel(entry.name);
        nameLabel.setForeground(exists ? BPETheme.TEXT_PRIMARY : BPETheme.TEXT_DIM);
        nameLabel.setFont(BPETheme.FONT_MONO_BOLD);

        JLabel pathLabel = new JLabel(exists ? entry.path : entry.path + "   [NOT FOUND]");
        pathLabel.setForeground(exists ? BPETheme.TEXT_DIM : BPETheme.RED);
        pathLabel.setFont(BPETheme.FONT_MONO_SMALL);

        left.add(nameLabel);
        left.add(Box.createVerticalStrut(3));
        left.add(pathLabel);

        // Right: date + accent bar
        JPanel right = new JPanel(new BorderLayout());
        right.setOpaque(false);
        JLabel dateLabel = new JLabel(entry.lastOpened);
        dateLabel.setForeground(BPETheme.TEXT_DIM);
        dateLabel.setFont(BPETheme.FONT_MONO_SMALL);
        right.add(dateLabel, BorderLayout.EAST);

        card.add(left, BorderLayout.CENTER);
        card.add(right, BorderLayout.EAST);

        if (exists) {
            card.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) { openProject(new File(entry.path)); }
                @Override public void mouseEntered(MouseEvent e) { card.setBackground(BPETheme.BG_HOVER); card.repaint(); }
                @Override public void mouseExited(MouseEvent e) { card.setBackground(BPETheme.BG_MID); card.repaint(); }
            });
        }

        return card;
    }

    private void showNewProjectDialog() {
        JDialog dialog = new JDialog(this, "New Project", true);
        dialog.setSize(740, 520);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(BPETheme.BG_DEEPEST);
        dialog.setLayout(new BorderLayout());
        dialog.setIconImage(BPETheme.createBananaIcon(32));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BPETheme.BG_DEEP);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, BPETheme.BORDER),
            BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));
        JLabel title = new JLabel("Create New Project");
        title.setForeground(BPETheme.TEXT_PRIMARY);
        title.setFont(BPETheme.FONT_MONO_LARGE);
        JLabel sub = new JLabel("Choose a template, then name your project");
        sub.setForeground(BPETheme.TEXT_DIM);
        sub.setFont(BPETheme.FONT_MONO_SMALL);
        JPanel titleStack = new JPanel();
        titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
        titleStack.setOpaque(false);
        titleStack.add(title);
        titleStack.add(sub);
        header.add(titleStack, BorderLayout.WEST);
        dialog.add(header, BorderLayout.NORTH);

        // Content
        JPanel content = new JPanel(new BorderLayout(16, 0));
        content.setBackground(BPETheme.BG_DEEPEST);
        content.setBorder(BorderFactory.createEmptyBorder(16, 16, 0, 16));

        // Template grid
        JPanel grid = new JPanel(new GridLayout(0, 2, 10, 10));
        grid.setBackground(BPETheme.BG_DEEPEST);

        JPanel[] selectedCard = {null};

        for (ProjectTemplates.Template tmpl : ProjectTemplates.getAll()) {
            JPanel card = new JPanel() {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(getBackground());
                    g2.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 10, 10);
                    // Border
                    Color border = (selectedTemplate == tmpl) ? BPETheme.ACCENT : BPETheme.BORDER;
                    g2.setColor(border);
                    g2.setStroke(new BasicStroke((selectedTemplate == tmpl) ? 2f : 1f));
                    g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 10, 10);
                }
            };
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBackground(BPETheme.BG_MID);
            card.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));
            card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            card.setOpaque(false);

            JLabel iconLbl = new JLabel(tmpl.icon);
            iconLbl.setForeground(BPETheme.ACCENT);
            iconLbl.setFont(new Font("Consolas", Font.BOLD, 20));

            JLabel nameLbl = new JLabel(tmpl.name);
            nameLbl.setForeground(BPETheme.TEXT_PRIMARY);
            nameLbl.setFont(BPETheme.FONT_MONO_BOLD);

            JLabel descLbl = new JLabel("<html><body style='width:140px;color:#888'>" + tmpl.description + "</body></html>");
            descLbl.setFont(BPETheme.FONT_MONO_SMALL);

            card.add(iconLbl);
            card.add(Box.createVerticalStrut(6));
            card.add(nameLbl);
            card.add(Box.createVerticalStrut(4));
            card.add(descLbl);

            card.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) {
                    selectedTemplate = tmpl;
                    if (selectedCard[0] != null) selectedCard[0].repaint();
                    selectedCard[0] = card;
                    card.repaint();
                }
                @Override public void mouseEntered(MouseEvent e) {
                    if (selectedTemplate != tmpl) { card.setBackground(BPETheme.BG_HOVER); card.repaint(); }
                }
                @Override public void mouseExited(MouseEvent e) {
                    if (selectedTemplate != tmpl) { card.setBackground(BPETheme.BG_MID); card.repaint(); }
                }
            });
            grid.add(card);
        }

        JScrollPane gridScroll = new JScrollPane(grid);
        gridScroll.setBorder(BorderFactory.createEmptyBorder());
        gridScroll.getViewport().setBackground(BPETheme.BG_DEEPEST);
        content.add(gridScroll, BorderLayout.CENTER);

        // Right: form
        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(BPETheme.BG_DEEPEST);
        form.setPreferredSize(new Dimension(210, 0));

        JLabel nameLabel = new JLabel("Project Name");
        nameLabel.setForeground(BPETheme.TEXT_SECONDARY);
        nameLabel.setFont(BPETheme.FONT_MONO_SMALL);
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextField nameField = BPETheme.textField("MyGame");
        nameField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        nameField.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel locLabel = new JLabel("Location");
        locLabel.setForeground(BPETheme.TEXT_SECONDARY);
        locLabel.setFont(BPETheme.FONT_MONO_SMALL);
        locLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextField locField = BPETheme.textField(System.getProperty("user.home") + File.separator + "BPEProjects");
        locField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        locField.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton browseBtn = BPETheme.secondaryButton("Browse...");
        browseBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        browseBtn.setFont(BPETheme.FONT_MONO_SMALL);
        browseBtn.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser(locField.getText());
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            if (chooser.showOpenDialog(dialog) == JFileChooser.APPROVE_OPTION)
                locField.setText(chooser.getSelectedFile().getAbsolutePath());
        });

        form.add(nameLabel);
        form.add(Box.createVerticalStrut(4));
        form.add(nameField);
        form.add(Box.createVerticalStrut(14));
        form.add(locLabel);
        form.add(Box.createVerticalStrut(4));
        form.add(locField);
        form.add(Box.createVerticalStrut(6));
        form.add(browseBtn);
        form.add(Box.createVerticalGlue());

        content.add(form, BorderLayout.EAST);
        dialog.add(content, BorderLayout.CENTER);

        // Footer
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(BPETheme.BG_DEEP);
        footer.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, BPETheme.BORDER),
            BorderFactory.createEmptyBorder(10, 16, 10, 16)
        ));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(BPETheme.BG_DEEP);

        JButton cancelBtn = BPETheme.secondaryButton("Cancel");
        cancelBtn.addActionListener(e -> dialog.dispose());

        JButton createBtn = BPETheme.primaryButton("Create Project");
        createBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String loc = locField.getText().trim();
            if (name.isEmpty()) { JOptionPane.showMessageDialog(dialog, "Please enter a project name."); return; }
            if (selectedTemplate == null) { JOptionPane.showMessageDialog(dialog, "Please select a template."); return; }
            createProject(name, loc + File.separator + name, selectedTemplate);
            dialog.dispose();
        });

        btnRow.add(cancelBtn);
        btnRow.add(createBtn);
        footer.add(btnRow, BorderLayout.EAST);
        dialog.add(footer, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    private void createProject(String name, String path, ProjectTemplates.Template template) {
        BPEProject project = new BPEProject(name, template.id, path);
        project.objects.addAll(template.objects);
        project.scripts.putAll(template.scripts);
        project.settings.windowTitle = template.settings.windowTitle.equals("My Game") ? name : template.settings.windowTitle;
        try {
            project.save();
            history.addEntry(project);
            launchEditor(project);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to create project:\n" + ex.getMessage());
        }
    }

    private void openProject() {
        JFileChooser chooser = new JFileChooser(System.getProperty("user.home"));
        chooser.setFileFilter(new FileNameExtensionFilter("BPE Project (*.bpe)", "bpe"));
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
            openProject(chooser.getSelectedFile());
    }

    private void openProject(File bpeFile) {
        try {
            BPEProject project = BPEProject.load(bpeFile);
            history.addEntry(project);
            launchEditor(project);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Failed to open project:\n" + ex.getMessage());
        }
    }

    private void launchEditor(BPEProject project) {
        dispose();
        SwingUtilities.invokeLater(() -> new EditorFrame(project).setVisible(true));
    }
}
