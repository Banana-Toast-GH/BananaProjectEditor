package com.bpe.bcode;

import com.bpe.project.BPEProject;
import java.util.*;
import java.util.function.Consumer;

/**
 * BCode Interpreter - full language spec.
 *
 * SYNTAX:
 *   attach "Name";
 *   deattach;
 *   local x = 5;
 *   x = x + 1;
 *
 *   Single-line if:
 *     if (condition) =
 *         statement]
 *
 *   Multi-line if:
 *     if (condition) =
 *         stmt1;
 *         stmt2]
 *
 *   if/else:
 *     if (condition) =
 *         stmt]
 *     else =
 *         stmt]
 *
 *   forever loop (runs each onUpdate tick):
 *     forever =
 *         stmt]
 *
 * NAMESPACES:
 *   engine.log/warn/error, engine.LoadScene(name), engine.Quit(), engine.SceneReload()
 *   object.SetPosition(x,y), object.GetPosition() -> (x,y)
 *   object.SetSize(w,h), object.SetRotation(deg)
 *   object.Show(opacity), object.Hide()
 *   object.SetText(text), object.GetText()
 *   object.Clone(), object.Destroy()
 *   object.KeyDown("Key"), object.KeyPressed("Key"), object.KeyReleased("Key")
 *   object.MouseDown(), object.MouseClicked()
 *   window.SetTitle(s), window.GetFPS(), window.GetDeltaTime(), window.SetSize(w,h)
 *   sound.Play(name)
 *   time.GetTime()
 *   math.Sin/Cos/Tan/Abs/Floor/Ceil/Sqrt/Pow/Random/Clamp
 *
 * EVENTS:
 *   event:onStart(), event:onUpdate(), event:onDestroy(),
 *   event:onCollide(other), object.event:OnClick()
 */
public class BCodeInterpreter {

    private final BPEProject        project;
    private final Consumer<String>  log, warn, error;
    private final Map<String,Object> globals = new HashMap<>();
    private boolean running   = false;
    private long    startTime = 0;

    // Input state — updated each frame by GameWindow
    private final Set<String> keysDown     = new HashSet<>();
    private final Set<String> keysPressed  = new HashSet<>();
    private final Set<String> keysReleased = new HashSet<>();
    private boolean mouseDown    = false;
    private boolean mouseClicked = false;

    // forever-block bodies per script (name -> statements)
    private final Map<String,List<String>> foreverBlocks = new HashMap<>();

    public BCodeInterpreter(BPEProject project,
                            Consumer<String> log,
                            Consumer<String> warn,
                            Consumer<String> error) {
        this.project = project;
        this.log   = log;
        this.warn  = warn;
        this.error = error;
    }

    // Called by GameWindow each frame
    public void setInputState(Set<String> down, Set<String> pressed,
                              Set<String> released, boolean mDown, boolean mClick) {
        keysDown.clear();     keysDown.addAll(down);
        keysPressed.clear();  keysPressed.addAll(pressed);
        keysReleased.clear(); keysReleased.addAll(released);
        mouseDown    = mDown;
        mouseClicked = mClick;
    }

    public void runAllScripts() {
        running   = true;
        startTime = System.currentTimeMillis();
        globals.clear();
        foreverBlocks.clear();
        for (Map.Entry<String,String> e : project.scripts.entrySet())
            new ScriptRunner(e.getKey(), e.getValue()).runEvent("onStart");
    }

    public void runUpdateScripts() {
        if (!running) return;
        for (Map.Entry<String,String> e : project.scripts.entrySet())
            new ScriptRunner(e.getKey(), e.getValue()).runEvent("onUpdate");
        // Run forever blocks
        for (Map.Entry<String,List<String>> e : foreverBlocks.entrySet())
            new ScriptRunner(e.getKey(), "").execBlock(e.getValue());
    }

    public void stop() {
        running = false;
        globals.clear();
        foreverBlocks.clear();
        keysDown.clear(); keysPressed.clear(); keysReleased.clear();
    }

    // ═════════════════════════════════════════════════════════════════════════
    private class ScriptRunner {
        final String        name;
        final List<String>  lines;
        String              attachedObject = null;
        final Map<String,Object> locals    = new HashMap<>();

        ScriptRunner(String name, String source) {
            this.name  = name;
            this.lines = new ArrayList<>();
            if (source != null)
                for (String l : source.split("\n")) lines.add(l);
        }

        // ── run a named event block ───────────────────────────────────────────
        void runEvent(String eventName) {
            int start = -1;
            for (int i = 0; i < lines.size(); i++)
                if (lines.get(i).trim().equals("script.start")) { start = i; break; }
            if (start < 0) return;

            boolean inScript = false;
            String  curEvent = null;
            boolean capture  = false;
            List<String> body = new ArrayList<>();

            for (int i = start; i < lines.size(); i++) {
                String line = lines.get(i).trim();
                if (line.isEmpty() || line.startsWith("--")) continue;

                if (line.equals("script.start")) { inScript = true;  continue; }
                if (line.equals("script.end"))   { break; }
                if (!inScript) continue;

                // top-level (outside any event)
                if (curEvent == null) {
                    if (line.startsWith("attach ")) {
                        String arg = unquote(stripSemi(line.substring(7).trim()));
                        BPEProject.ProjectObject o = findObj(arg);
                        if (o != null) attachedObject = o.name;
                        // else = root/project name, silently accepted
                        continue;
                    }
                    if (line.startsWith("deattach")) { attachedObject = null; continue; }
                    if (line.startsWith("local "))   { handleLocal(line); continue; }
                }

                // event start
                if (line.startsWith("event:") || line.startsWith("object.event:")) {
                    curEvent = extractEventName(line);
                    capture  = curEvent.equalsIgnoreCase(eventName);
                    body.clear();
                    continue;
                }

                // event end
                if (line.equals("event.end")) {
                    if (capture) execBlock(body);
                    curEvent = null; capture = false; body.clear();
                    continue;
                }

                if (curEvent != null && capture) body.add(line);
            }
        }

        // ── execute a list of statements ──────────────────────────────────────
        void execBlock(List<String> stmts) {
            int i = 0;
            while (i < stmts.size()) {
                String line = stmts.get(i).trim();

                // forever block
                if (line.equals("forever =") || line.startsWith("forever =")) {
                    List<String> body = collectBlock(stmts, i + 1);
                    foreverBlocks.put(name, new ArrayList<>(body));
                    i += body.size() + 1;
                    continue;
                }

                // if block
                if (line.startsWith("if (") && line.endsWith("=")) {
                    String cond = line.substring(3, line.length() - 1).trim();
                    // remove surrounding parens
                    if (cond.startsWith("(") && cond.endsWith(")"))
                        cond = cond.substring(1, cond.length()-1);
                    List<String> ifBody   = collectBlock(stmts, i + 1);
                    i += ifBody.size() + 1;
                    // check for else
                    List<String> elseBody = new ArrayList<>();
                    if (i < stmts.size() && stmts.get(i).trim().equals("else =")) {
                        elseBody = collectBlock(stmts, i + 1);
                        i += elseBody.size() + 1;
                    }
                    if (evalCondition(cond)) execBlock(ifBody);
                    else if (!elseBody.isEmpty()) execBlock(elseBody);
                    continue;
                }

                execStatement(line);
                i++;
            }
        }

        /** Collect statements until one ends with ] (strip the ]) */
        List<String> collectBlock(List<String> stmts, int from) {
            List<String> block = new ArrayList<>();
            for (int j = from; j < stmts.size(); j++) {
                String s = stmts.get(j).trim();
                if (s.endsWith("]")) {
                    // Strip the ]
                    String cleaned = s.substring(0, s.length()-1).trim();
                    if (!cleaned.isEmpty()) block.add(cleaned);
                    break;
                }
                block.add(s);
            }
            return block;
        }

        // ── single statement ──────────────────────────────────────────────────
        void execStatement(String raw) {
            String line = stripSemi(raw.trim());
            if (line.isEmpty() || line.startsWith("--")) return;

            try {

                // ── engine ────────────────────────────────────────────────────
                if (line.startsWith("engine.log(")) {
                    log.accept(evalArg(line, "engine.log")); return;
                }
                if (line.startsWith("engine.warn(")) {
                    warn.accept(evalArg(line, "engine.warn")); return;
                }
                if (line.startsWith("engine.error(")) {
                    error.accept(evalArg(line, "engine.error")); return;
                }
                if (line.startsWith("engine.LoadScene(")) {
                    log.accept("[engine] LoadScene: " + evalArg(line, "engine.LoadScene")); return;
                }
                if (line.equals("engine.Quit()")) {
                    log.accept("[engine] Quit called"); running = false; return;
                }
                if (line.equals("engine.SceneReload()")) {
                    log.accept("[engine] SceneReload called"); return;
                }

                // ── window ────────────────────────────────────────────────────
                if (line.startsWith("window.SetTitle(")) {
                    String t = evalArg(line, "window.SetTitle");
                    project.settings.windowTitle = t;
                    log.accept("[window] Title → " + t); return;
                }
                if (line.startsWith("window.SetSize(")) {
                    String[] p = innerArgs(line, "window.SetSize").split(",", 2);
                    if (p.length == 2) {
                        project.settings.windowWidth  = (int) toDouble(p[0]);
                        project.settings.windowHeight = (int) toDouble(p[1]);
                    }
                    return;
                }
                if (line.startsWith("window.GetFPS()")) {
                    storeResult(line, "window.GetFPS()", 60.0); return;
                }
                if (line.startsWith("window.GetDeltaTime()")) {
                    storeResult(line, "window.GetDeltaTime()", 0.016); return;
                }

                // ── time ──────────────────────────────────────────────────────
                if (line.startsWith("time.GetTime()")) {
                    storeResult(line, "time.GetTime()",
                        (System.currentTimeMillis() - startTime) / 1000.0); return;
                }

                // ── sound ─────────────────────────────────────────────────────
                if (line.startsWith("sound.Play(")) {
                    log.accept("[sound] Play: " + evalArg(line, "sound.Play")); return;
                }

                // ── math ──────────────────────────────────────────────────────
                if (line.startsWith("math.")) {
                    handleMath(line); return;
                }

                // ── object.KeyDown / KeyPressed / KeyReleased / Mouse ─────────
                if (line.startsWith("object.KeyDown(")) {
                    String key = evalArg(line, "object.KeyDown");
                    storeResult(line, line, keysDown.contains(key.toUpperCase())); return;
                }
                if (line.startsWith("object.KeyPressed(")) {
                    String key = evalArg(line, "object.KeyPressed");
                    storeResult(line, line, keysPressed.contains(key.toUpperCase())); return;
                }
                if (line.startsWith("object.KeyReleased(")) {
                    String key = evalArg(line, "object.KeyReleased");
                    storeResult(line, line, keysReleased.contains(key.toUpperCase())); return;
                }
                if (line.equals("object.MouseDown()")) {
                    storeResult(line, line, mouseDown); return;
                }
                if (line.equals("object.MouseClicked()")) {
                    storeResult(line, line, mouseClicked); return;
                }

                // ── object.GetPosition() ──────────────────────────────────────
                // local x, y = object.GetPosition()
                if (line.contains("object.GetPosition()")) {
                    BPEProject.ProjectObject obj = requireObj();
                    if (obj == null) return;
                    // parse "local x, y = object.GetPosition()"
                    if (line.startsWith("local ")) {
                        String lhs = line.substring(6, line.indexOf("=")).trim();
                        String[] vars = lhs.split(",");
                        if (vars.length >= 1) locals.put(vars[0].trim(), obj.x);
                        if (vars.length >= 2) locals.put(vars[1].trim(), obj.y);
                    }
                    return;
                }

                // ── object setters ────────────────────────────────────────────
                if (line.startsWith("object.SetPosition(")) {
                    BPEProject.ProjectObject obj = requireObj();
                    if (obj == null) return;
                    String[] p = innerArgs(line, "object.SetPosition").split(",", 2);
                    if (p.length == 2) { obj.x = toDouble(p[0]); obj.y = toDouble(p[1]); }
                    return;
                }
                if (line.startsWith("object.SetSize(")) {
                    BPEProject.ProjectObject obj = requireObj();
                    if (obj == null) return;
                    String[] p = innerArgs(line, "object.SetSize").split(",", 2);
                    if (p.length == 2) { obj.width = toDouble(p[0]); obj.height = toDouble(p[1]); }
                    return;
                }
                if (line.startsWith("object.SetRotation(")) {
                    BPEProject.ProjectObject obj = requireObj();
                    if (obj == null) return;
                    obj.rotation = toDouble(innerArgs(line, "object.SetRotation"));
                    return;
                }
                if (line.startsWith("object.Show(")) {
                    BPEProject.ProjectObject obj = requireObj();
                    if (obj == null) return;
                    obj.visible = true;
                    String a = innerArgs(line, "object.Show");
                    if (!a.isEmpty()) obj.opacity = toDouble(a);
                    return;
                }
                if (line.startsWith("object.Hide()")) {
                    BPEProject.ProjectObject obj = requireObj();
                    if (obj != null) obj.visible = false;
                    return;
                }
                if (line.startsWith("object.SetText(")) {
                    BPEProject.ProjectObject obj = requireObj();
                    if (obj == null) return;
                    obj.name = evalArg(line, "object.SetText");
                    return;
                }
                if (line.startsWith("object.GetText()")) {
                    BPEProject.ProjectObject obj = requireObj();
                    if (obj != null) storeResult(line, "object.GetText()", obj.name);
                    return;
                }
                if (line.startsWith("object.Destroy()")) {
                    BPEProject.ProjectObject obj = requireObj();
                    if (obj != null) { project.objects.remove(obj); attachedObject = null; }
                    return;
                }
                if (line.startsWith("object.Clone()")) {
                    BPEProject.ProjectObject obj = requireObj();
                    if (obj != null) {
                        BPEProject.ProjectObject clone = new BPEProject.ProjectObject(
                            obj.name + "_clone", obj.type);
                        clone.x = obj.x + 10; clone.y = obj.y + 10;
                        clone.width = obj.width; clone.height = obj.height;
                        clone.color = obj.color; clone.layer = obj.layer;
                        project.objects.add(clone);
                    }
                    return;
                }

                // ── local var ─────────────────────────────────────────────────
                if (line.startsWith("local ")) { handleLocal(line); return; }

                // ── assignment  var = expr ────────────────────────────────────
                if (line.matches("^[a-zA-Z_][a-zA-Z0-9_]* = .*")) {
                    int eq = line.indexOf(" = ");
                    String var = line.substring(0, eq).trim();
                    String val = line.substring(eq + 3).trim();
                    Object result = evalExpr(val);
                    if (locals.containsKey(var))  locals.put(var, result);
                    else                           globals.put(var, result);
                    return;
                }

                // Unknown — silently skip

            } catch (Exception e) {
                error.accept("[BCode] " + name + ": " + e.getMessage() + "  →  " + line);
            }
        }

        // ── condition evaluator ───────────────────────────────────────────────
        boolean evalCondition(String cond) {
            cond = cond.trim();
            // ==
            if (cond.contains("==")) {
                String[] p = cond.split("==", 2);
                return toString(evalExpr(p[0].trim())).equals(toString(evalExpr(p[1].trim())));
            }
            // ~= (Lua not-equal)
            if (cond.contains("~=")) {
                String[] p = cond.split("~=", 2);
                return !toString(evalExpr(p[0].trim())).equals(toString(evalExpr(p[1].trim())));
            }
            // !=
            if (cond.contains("!=")) {
                String[] p = cond.split("!=", 2);
                return !toString(evalExpr(p[0].trim())).equals(toString(evalExpr(p[1].trim())));
            }
            // >= / <=
            if (cond.contains(">=")) {
                String[] p = cond.split(">=", 2);
                return toDouble(p[0].trim()) >= toDouble(p[1].trim());
            }
            if (cond.contains("<=")) {
                String[] p = cond.split("<=", 2);
                return toDouble(p[0].trim()) <= toDouble(p[1].trim());
            }
            // > / <
            if (cond.contains(">")) {
                String[] p = cond.split(">", 2);
                return toDouble(p[0].trim()) > toDouble(p[1].trim());
            }
            if (cond.contains("<")) {
                String[] p = cond.split("<", 2);
                return toDouble(p[0].trim()) < toDouble(p[1].trim());
            }
            // boolean / truthy
            Object v = evalExpr(cond);
            if (v instanceof Boolean) return (Boolean) v;
            if (v instanceof Double)  return (Double) v != 0;
            return v != null && !v.toString().isEmpty() && !v.toString().equals("false");
        }

        // ── math functions ────────────────────────────────────────────────────
        void handleMath(String line) {
            String func = line.substring(5, line.indexOf('(')); // after "math."
            String arg  = innerArgs(line, "math." + func);
            double result = 0;
            switch (func) {
                case "Sin":    result = Math.sin(Math.toRadians(toDouble(arg))); break;
                case "Cos":    result = Math.cos(Math.toRadians(toDouble(arg))); break;
                case "Tan":    result = Math.tan(Math.toRadians(toDouble(arg))); break;
                case "Abs":    result = Math.abs(toDouble(arg)); break;
                case "Floor":  result = Math.floor(toDouble(arg)); break;
                case "Ceil":   result = Math.ceil(toDouble(arg)); break;
                case "Sqrt":   result = Math.sqrt(toDouble(arg)); break;
                case "Pow": {
                    String[] p = arg.split(",", 2);
                    result = Math.pow(toDouble(p[0]), toDouble(p[1])); break;
                }
                case "Random": {
                    String[] p = arg.split(",", 2);
                    double mn = toDouble(p[0]), mx = toDouble(p[1]);
                    result = mn + Math.random() * (mx - mn); break;
                }
                case "Clamp": {
                    String[] p = arg.split(",", 3);
                    double v = toDouble(p[0]), mn = toDouble(p[1]), mx = toDouble(p[2]);
                    result = Math.max(mn, Math.min(mx, v)); break;
                }
            }
            storeResult(line, "math." + func + "(" + arg + ")", result);
        }

        // ── expression evaluator ──────────────────────────────────────────────
        Object evalExpr(String expr) {
            expr = expr.trim();
            if (expr.isEmpty()) return "";

            // String concat with ..
            if (expr.contains("..")) {
                String[] parts = expr.split("\\.\\.", -1);
                StringBuilder sb = new StringBuilder();
                for (String p : parts) sb.append(toString(evalExpr(p.trim())));
                return sb.toString();
            }

            // Arithmetic — handle +, -, *, / (right-to-left for simple cases)
            for (String op : new String[]{"+", "-", "*", "/"}) {
                int idx = findOperator(expr, op);
                if (idx > 0) {
                    String left  = expr.substring(0, idx).trim();
                    String right = expr.substring(idx + op.length()).trim();
                    // Only do arithmetic if both sides look numeric / variable
                    try {
                        double l = toDouble(left), r = toDouble(right);
                        switch (op) {
                            case "+": return l + r;
                            case "-": return l - r;
                            case "*": return l * r;
                            case "/": return r != 0 ? l / r : 0.0;
                        }
                    } catch (Exception ignored) {
                        // left or right is a string — fall through to string concat for +
                        if (op.equals("+"))
                            return toString(evalExpr(left)) + toString(evalExpr(right));
                    }
                }
            }

            // String literal
            if (expr.startsWith("\"") && expr.endsWith("\""))
                return expr.substring(1, expr.length()-1);

            // Number
            try { return Double.parseDouble(expr); } catch (NumberFormatException ignored) {}

            // Boolean / null
            if (expr.equals("true"))  return Boolean.TRUE;
            if (expr.equals("false")) return Boolean.FALSE;
            if (expr.equals("null"))  return null;

            // Function calls that return a value
            if (expr.equals("object.GetPosition()")) {
                BPEProject.ProjectObject o = requireObj();
                return o != null ? "(" + o.x + ", " + o.y + ")" : "(0, 0)";
            }
            if (expr.equals("object.GetText()")) {
                BPEProject.ProjectObject o = requireObj();
                return o != null ? o.name : "";
            }
            if (expr.equals("window.GetFPS()"))       return 60.0;
            if (expr.equals("window.GetDeltaTime()")) return 0.016;
            if (expr.equals("time.GetTime()"))
                return (System.currentTimeMillis() - startTime) / 1000.0;
            if (expr.startsWith("object.KeyDown(")) {
                String key = unquote(innerArgs(expr, "object.KeyDown"));
                return keysDown.contains(key.toUpperCase());
            }
            if (expr.startsWith("object.KeyPressed(")) {
                String key = unquote(innerArgs(expr, "object.KeyPressed"));
                return keysPressed.contains(key.toUpperCase());
            }
            if (expr.startsWith("object.KeyReleased(")) {
                String key = unquote(innerArgs(expr, "object.KeyReleased"));
                return keysReleased.contains(key.toUpperCase());
            }
            if (expr.equals("object.MouseDown()"))    return mouseDown;
            if (expr.equals("object.MouseClicked()")) return mouseClicked;

            // Variable lookup
            if (locals.containsKey(expr))  return locals.get(expr);
            if (globals.containsKey(expr)) return globals.get(expr);

            return expr;
        }

        /** Find operator index, skipping inside strings/parens */
        int findOperator(String expr, String op) {
            int depth = 0; boolean inStr = false;
            for (int i = expr.length() - op.length(); i >= 0; i--) {
                char c = expr.charAt(i);
                if (c == '"') inStr = !inStr;
                if (inStr) continue;
                if (c == ')') depth++; if (c == '(') depth--;
                if (depth == 0 && expr.startsWith(op, i))
                    return i;
            }
            return -1;
        }

        // ── helpers ───────────────────────────────────────────────────────────
        void handleLocal(String line) {
            String rest = line.substring(6).trim();
            // Handle "local x, y = object.GetPosition()"
            if (rest.contains("object.GetPosition()")) {
                BPEProject.ProjectObject o = requireObj();
                String lhs = rest.substring(0, rest.indexOf("=")).trim();
                String[] vars = lhs.split(",");
                if (o != null) {
                    if (vars.length >= 1) locals.put(vars[0].trim(), o.x);
                    if (vars.length >= 2) locals.put(vars[1].trim(), o.y);
                }
                return;
            }
            int eq = rest.indexOf('=');
            if (eq >= 0) {
                String var = rest.substring(0, eq).trim();
                String val = rest.substring(eq + 1).trim();
                locals.put(var, evalExpr(val));
            }
        }

        BPEProject.ProjectObject requireObj() {
            if (attachedObject == null) return null;
            return findObj(attachedObject);
        }

        BPEProject.ProjectObject findObj(String n) {
            for (BPEProject.ProjectObject o : project.objects)
                if (o.name.equalsIgnoreCase(n)) return o;
            return null;
        }

        String evalArg(String line, String func) {
            return toString(evalExpr(innerArgs(line, func)));
        }

        String innerArgs(String line, String func) {
            int s = line.indexOf('('), e = line.lastIndexOf(')');
            return (s >= 0 && e > s) ? line.substring(s+1, e).trim() : "";
        }

        String extractEventName(String line) {
            if (line.startsWith("object.event:")) line = line.substring("object.event:".length());
            else if (line.startsWith("event:"))   line = line.substring("event:".length());
            int p = line.indexOf('(');
            return p >= 0 ? line.substring(0, p) : line;
        }

        /** If this line is "local result = someFunc()", store in locals */
        void storeResult(String line, String func, Object value) {
            // Check if assigned: "local x = func()" or "x = func()"
            if (line.startsWith("local ")) {
                String rest = line.substring(6).trim();
                int eq = rest.indexOf('=');
                if (eq >= 0) locals.put(rest.substring(0, eq).trim(), value);
            } else if (line.contains(" = " + func)) {
                String var = line.substring(0, line.indexOf(" = ")).trim();
                if (locals.containsKey(var)) locals.put(var, value);
                else globals.put(var, value);
            }
        }

        double toDouble(String s) {
            Object v = evalExpr(s.trim());
            if (v instanceof Double)  return (Double) v;
            if (v instanceof Boolean) return ((Boolean) v) ? 1.0 : 0.0;
            try { return Double.parseDouble(v.toString()); } catch (Exception e) { return 0; }
        }

        String toString(Object v) {
            if (v == null) return "null";
            if (v instanceof Double) {
                double d = (Double) v;
                return d == Math.floor(d) && !Double.isInfinite(d)
                    ? String.valueOf((long) d) : String.valueOf(d);
            }
            return v.toString();
        }

        String stripSemi(String s) {
            s = s.trim();
            return s.endsWith(";") ? s.substring(0, s.length()-1).trim() : s;
        }

        String unquote(String s) {
            s = s.trim();
            return (s.startsWith("\"") && s.endsWith("\""))
                ? s.substring(1, s.length()-1) : s;
        }
    }
}
