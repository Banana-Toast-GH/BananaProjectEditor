package com.bpe.ui;

import java.awt.*;

/**
 * BPE Visual Theme - dark industrial with banana-yellow accents.
 * All colors, fonts, and dimensions live here for consistency.
 */
public class BPETheme {

    // Core palette
    public static final Color BG_DEEPEST   = new Color(18, 18, 20);    // darkest - window bg
    public static final Color BG_DEEP      = new Color(24, 24, 27);    // panels
    public static final Color BG_MID       = new Color(32, 32, 36);    // cards, toolbars
    public static final Color BG_RAISED    = new Color(42, 42, 48);    // elevated elements
    public static final Color BG_HOVER     = new Color(52, 52, 60);    // hover states
    public static final Color BG_SELECTED  = new Color(60, 80, 110);   // selected

    // Accent - banana yellow
    public static final Color ACCENT       = new Color(255, 200, 30);   // banana yellow
    public static final Color ACCENT_DIM   = new Color(180, 140, 20);   // dimmed accent
    public static final Color ACCENT_GLOW  = new Color(255, 220, 80);   // bright accent

    // Text
    public static final Color TEXT_PRIMARY = new Color(230, 230, 235);
    public static final Color TEXT_SECONDARY = new Color(150, 150, 160);
    public static final Color TEXT_DIM     = new Color(80, 80, 90);

    // Status colors
    public static final Color GREEN        = new Color(80, 200, 120);
    public static final Color RED          = new Color(220, 70, 70);
    public static final Color ORANGE       = new Color(220, 150, 50);
    public static final Color BLUE         = new Color(80, 160, 240);

    // Borders
    public static final Color BORDER       = new Color(55, 55, 65);
    public static final Color BORDER_LIGHT = new Color(70, 70, 82);

    // Fonts
    public static final Font FONT_MONO_SMALL  = new Font("Consolas", Font.PLAIN, 10);
    public static final Font FONT_MONO        = new Font("Consolas", Font.PLAIN, 12);
    public static final Font FONT_MONO_BOLD   = new Font("Consolas", Font.BOLD, 12);
    public static final Font FONT_MONO_LARGE  = new Font("Consolas", Font.BOLD, 14);
    public static final Font FONT_TITLE       = new Font("Consolas", Font.BOLD, 22);

    // Apply a consistent dark UI look to all Swing components
    public static void apply() {
        javax.swing.UIManager.put("Panel.background", BG_DEEP);
        javax.swing.UIManager.put("OptionPane.background", BG_MID);
        javax.swing.UIManager.put("OptionPane.messageForeground", TEXT_PRIMARY);
        javax.swing.UIManager.put("Button.background", BG_RAISED);
        javax.swing.UIManager.put("Button.foreground", TEXT_PRIMARY);
        javax.swing.UIManager.put("TextField.background", BG_RAISED);
        javax.swing.UIManager.put("TextField.foreground", TEXT_PRIMARY);
        javax.swing.UIManager.put("TextField.caretForeground", ACCENT);
        javax.swing.UIManager.put("TextArea.background", BG_DEEP);
        javax.swing.UIManager.put("TextArea.foreground", TEXT_PRIMARY);
        javax.swing.UIManager.put("ScrollPane.background", BG_DEEP);
        javax.swing.UIManager.put("ScrollBar.background", BG_MID);
        javax.swing.UIManager.put("ScrollBar.thumb", BG_RAISED);
        javax.swing.UIManager.put("TabbedPane.background", BG_MID);
        javax.swing.UIManager.put("TabbedPane.foreground", TEXT_PRIMARY);
        javax.swing.UIManager.put("TabbedPane.selected", BG_RAISED);
        javax.swing.UIManager.put("Menu.background", BG_DEEP);
        javax.swing.UIManager.put("Menu.foreground", TEXT_PRIMARY);
        javax.swing.UIManager.put("MenuItem.background", BG_DEEP);
        javax.swing.UIManager.put("MenuItem.foreground", TEXT_PRIMARY);
        javax.swing.UIManager.put("PopupMenu.background", BG_MID);
        javax.swing.UIManager.put("MenuBar.background", BG_DEEPEST);
        javax.swing.UIManager.put("Tree.background", BG_DEEP);
        javax.swing.UIManager.put("Tree.foreground", TEXT_PRIMARY);
        javax.swing.UIManager.put("SplitPane.background", BG_DEEPEST);
        javax.swing.UIManager.put("SplitPaneDivider.background", BG_DEEPEST);
        javax.swing.UIManager.put("Label.foreground", TEXT_PRIMARY);
    }

    /** Creates a styled primary button with accent color */
    public static javax.swing.JButton primaryButton(String text) {
        javax.swing.JButton btn = new javax.swing.JButton(text);
        btn.setBackground(ACCENT);
        btn.setForeground(new Color(20, 20, 20));
        btn.setFont(FONT_MONO_BOLD);
        btn.setBorder(javax.swing.BorderFactory.createEmptyBorder(7, 16, 7, 16));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    /** Creates a styled secondary button */
    public static javax.swing.JButton secondaryButton(String text) {
        javax.swing.JButton btn = new javax.swing.JButton(text);
        btn.setBackground(BG_RAISED);
        btn.setForeground(TEXT_SECONDARY);
        btn.setFont(FONT_MONO);
        btn.setBorder(javax.swing.BorderFactory.createCompoundBorder(
            javax.swing.BorderFactory.createLineBorder(BORDER),
            javax.swing.BorderFactory.createEmptyBorder(6, 14, 6, 14)
        ));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    /** Styled text field */
    public static javax.swing.JTextField textField(String placeholder) {
        javax.swing.JTextField field = new javax.swing.JTextField(placeholder);
        field.setBackground(BG_RAISED);
        field.setForeground(TEXT_PRIMARY);
        field.setFont(FONT_MONO);
        field.setCaretColor(ACCENT);
        field.setBorder(javax.swing.BorderFactory.createCompoundBorder(
            javax.swing.BorderFactory.createLineBorder(BORDER),
            javax.swing.BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));
        return field;
    }

    /** Banana icon - yellow crescent banana shape on dark bg */
    public static Image createBananaIcon(int size) {
        java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(size, size, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Dark rounded background
        g.setColor(new Color(28, 28, 32));
        g.fillRoundRect(0, 0, size, size, size / 4, size / 4);

        float s = size;
        // Draw banana body as a thick crescent arc
        // Outer arc (the outer edge of the banana)
        int stroke = Math.max(3, size / 6);
        g.setColor(ACCENT);
        g.setStroke(new BasicStroke(stroke, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        // Use a cubic bezier for a realistic banana curve
        java.awt.geom.Path2D path = new java.awt.geom.Path2D.Float();
        float pad = s * 0.12f;
        // Start at bottom-left tip
        path.moveTo(pad, s * 0.78f);
        // Curve up and to the right like a banana
        path.curveTo(
            pad,         s * 0.25f,   // control 1 - pulls left side up
            s * 0.75f,   pad,         // control 2 - pulls top right
            s - pad,     s * 0.35f    // end at right tip
        );
        g.draw(path);

        // Darker inner edge for banana thickness
        g.setColor(ACCENT_DIM);
        g.setStroke(new BasicStroke(stroke * 0.4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        java.awt.geom.Path2D inner = new java.awt.geom.Path2D.Float();
        inner.moveTo(pad + stroke * 0.3f, s * 0.72f);
        inner.curveTo(
            pad + stroke * 0.3f, s * 0.32f,
            s * 0.7f,  pad + stroke * 0.3f,
            s - pad - stroke * 0.3f, s * 0.42f
        );
        g.draw(inner);

        // Banana tips - small rounded nubs
        g.setColor(new Color(160, 110, 10));
        g.setStroke(new BasicStroke(2));
        g.fillOval((int)(pad - 3), (int)(s * 0.73f), 6, 6);
        g.fillOval((int)(s - pad - 3), (int)(s * 0.30f), 6, 6);

        g.dispose();
        return img;
    }
}
