package com.bpe.project;

import java.util.*;

public class ProjectTemplates {

    public static class Template {
        public String id, name, description, icon;
        public List<BPEProject.ProjectObject> objects = new ArrayList<>();
        public Map<String, String> scripts = new HashMap<>();
        public BPEProject.ProjectSettings settings = new BPEProject.ProjectSettings();
    }

    public static List<Template> getAll() {
        return Arrays.asList(emptyProject(), platformer(), topDown(), clicker(), puzzle());
    }

    public static Template getById(String id) {
        for (Template t : getAll()) if (t.id.equals(id)) return t;
        return emptyProject();
    }

    private static BPEProject.ProjectObject obj(String name, String type,
            double x, double y, double w, double h) {
        BPEProject.ProjectObject o = new BPEProject.ProjectObject(name, type);
        o.x = x; o.y = y; o.width = w; o.height = h;
        return o;
    }

    // ── Empty ─────────────────────────────────────────────────────────────────
    private static Template emptyProject() {
        Template t = new Template();
        t.id = "empty"; t.name = "Empty Project";
        t.description = "A blank project. Start from scratch.";
        t.icon = "[  ]";
        return t;
    }

    // ── Platformer ────────────────────────────────────────────────────────────
    private static Template platformer() {
        Template t = new Template();
        t.id = "platformer"; t.name = "2D Platformer";
        t.description = "Side-scroller with player, ground and platforms.";
        t.icon = "[P]";
        t.settings.windowTitle = "My Platformer";
        t.settings.backgroundColor = "#5BA3DC";

        BPEProject.ProjectObject sky      = obj("Sky",       "Part",   0,   0, 800, 600); sky.color = "#5BA3DC";      sky.layer = -10;
        BPEProject.ProjectObject ground   = obj("Ground",    "Part",   0, 520, 800,  80); ground.color = "#6B4C2A";
        BPEProject.ProjectObject platform1= obj("Platform1", "Part", 200, 380, 160,  20); platform1.color = "#8B6342";
        BPEProject.ProjectObject platform2= obj("Platform2", "Part", 500, 280, 160,  20); platform2.color = "#8B6342";
        BPEProject.ProjectObject player   = obj("Player",    "Sprite",100, 440,  40,  60); player.color = "#FF6644";
        BPEProject.ProjectObject ctrl     = obj("GameController","Part",0,0,1,1);          ctrl.visible = false;

        t.objects.addAll(Arrays.asList(sky, ground, platform1, platform2, player, ctrl));

        t.scripts.put("GameController",
            "script.start\n\n" +
            "attach \"Banana Project Editor\";\n" +
            "attach \"GameController\";\n\n" +
            "local velocityY = 0;\n" +
            "local speed = 4;\n" +
            "local jumpForce = 12;\n" +
            "local gravity = 0.6;\n\n" +
            "event:onStart()\n" +
            "    engine.log(\"Platformer ready! WASD or Arrow keys to move, Space to jump.\")]\n" +
            "event.end\n\n" +
            "event:onUpdate()\n" +
            "    -- Gravity\n" +
            "    velocityY = velocityY + gravity;\n\n" +
            "    -- Move player\n" +
            "    attach \"Player\";\n" +
            "    local px, py = object.GetPosition();\n\n" +
            "    if (object.KeyDown(\"A\")) =\n" +
            "        px = px - speed]\n" +
            "    if (object.KeyDown(\"D\")) =\n" +
            "        px = px + speed]\n" +
            "    if (object.KeyDown(\"LEFT\")) =\n" +
            "        px = px - speed]\n" +
            "    if (object.KeyDown(\"RIGHT\")) =\n" +
            "        px = px + speed]\n\n" +
            "    -- Apply gravity\n" +
            "    py = py + velocityY;\n\n" +
            "    -- Ground collision (simple)\n" +
            "    if (py > 460) =\n" +
            "        py = 460;\n" +
            "        velocityY = 0]\n\n" +
            "    -- Jump\n" +
            "    if (object.KeyPressed(\"SPACE\")) =\n" +
            "        velocityY = -jumpForce]\n" +
            "    if (object.KeyPressed(\"W\")) =\n" +
            "        velocityY = -jumpForce]\n" +
            "    if (object.KeyPressed(\"UP\")) =\n" +
            "        velocityY = -jumpForce]\n\n" +
            "    object.SetPosition(px, py);\n" +
            "    deattach;\n" +
            "event.end\n\n" +
            "script.end"
        );

        return t;
    }

    // ── Top-Down ──────────────────────────────────────────────────────────────
    private static Template topDown() {
        Template t = new Template();
        t.id = "topdown"; t.name = "Top-Down Game";
        t.description = "Top-down view. WASD to move.";
        t.icon = "[T]";
        t.settings.windowTitle = "My Top-Down Game";
        t.settings.backgroundColor = "#2D5A27";

        BPEProject.ProjectObject floor = obj("Floor",       "Part",   0,   0, 800, 600); floor.color = "#2D5A27"; floor.layer = -10;
        BPEProject.ProjectObject wT    = obj("WallTop",     "Part",   0,   0, 800,  20); wT.color = "#1A3A17";
        BPEProject.ProjectObject wB    = obj("WallBottom",  "Part",   0, 580, 800,  20); wB.color = "#1A3A17";
        BPEProject.ProjectObject wL    = obj("WallLeft",    "Part",   0,   0,  20, 600); wL.color = "#1A3A17";
        BPEProject.ProjectObject wR    = obj("WallRight",   "Part", 780,   0,  20, 600); wR.color = "#1A3A17";
        BPEProject.ProjectObject player= obj("Player",      "Sprite",380, 280,  40,  40); player.color = "#FF9900";
        BPEProject.ProjectObject ctrl  = obj("GameController","Part",0,0,1,1);            ctrl.visible = false;

        t.objects.addAll(Arrays.asList(floor, wT, wB, wL, wR, player, ctrl));

        t.scripts.put("GameController",
            "script.start\n\n" +
            "attach \"Banana Project Editor\";\n" +
            "attach \"GameController\";\n\n" +
            "local speed = 4;\n\n" +
            "event:onStart()\n" +
            "    engine.log(\"Top-down ready! WASD to move.\")]\n" +
            "event.end\n\n" +
            "event:onUpdate()\n" +
            "    attach \"Player\";\n" +
            "    local px, py = object.GetPosition();\n\n" +
            "    if (object.KeyDown(\"W\")) =\n" +
            "        py = py - speed]\n" +
            "    if (object.KeyDown(\"S\")) =\n" +
            "        py = py + speed]\n" +
            "    if (object.KeyDown(\"A\")) =\n" +
            "        px = px - speed]\n" +
            "    if (object.KeyDown(\"D\")) =\n" +
            "        px = px + speed]\n" +
            "    if (object.KeyDown(\"UP\")) =\n" +
            "        py = py - speed]\n" +
            "    if (object.KeyDown(\"DOWN\")) =\n" +
            "        py = py + speed]\n" +
            "    if (object.KeyDown(\"LEFT\")) =\n" +
            "        px = px - speed]\n" +
            "    if (object.KeyDown(\"RIGHT\")) =\n" +
            "        px = px + speed]\n\n" +
            "    -- Clamp to walls\n" +
            "    px = math.Clamp(px, 25, 735);\n" +
            "    py = math.Clamp(py, 25, 535);\n" +
            "    object.SetPosition(px, py);\n" +
            "    deattach;\n" +
            "event.end\n\n" +
            "script.end"
        );

        return t;
    }

    // ── Clicker ───────────────────────────────────────────────────────────────
    private static Template clicker() {
        Template t = new Template();
        t.id = "clicker"; t.name = "Clicker Game";
        t.description = "Click the button to score points.";
        t.icon = "[C]";
        t.settings.windowTitle = "Clicker — Score: 0";
        t.settings.backgroundColor = "#1A1A2E";

        BPEProject.ProjectObject bg    = obj("Background",  "Part",    0,   0, 800, 600); bg.color = "#1A1A2E"; bg.layer = -10;
        BPEProject.ProjectObject label = obj("ScoreLabel",  "UILabel", 300,  80, 200,  40); label.color = "#FFFFFF";
        BPEProject.ProjectObject btn   = obj("ClickButton", "UIButton",300, 250, 200,  80); btn.color = "#FF9900";

        t.objects.addAll(Arrays.asList(bg, label, btn));

        t.scripts.put("ClickButton",
            "script.start\n\n" +
            "attach \"Banana Project Editor\";\n" +
            "attach \"ClickButton\";\n\n" +
            "local score = 0;\n\n" +
            "event:onStart()\n" +
            "    engine.log(\"Clicker ready! Click the button.\")]\n" +
            "event.end\n\n" +
            "object.event:OnClick()\n" +
            "    score = score + 1;\n" +
            "    window.SetTitle(\"Clicker — Score: \" .. score);\n" +
            "    engine.log(\"Score: \" .. score)]\n" +
            "event.end\n\n" +
            "script.end"
        );

        return t;
    }

    // ── Puzzle ────────────────────────────────────────────────────────────────
    private static Template puzzle() {
        Template t = new Template();
        t.id = "puzzle"; t.name = "Puzzle Game";
        t.description = "Grid-based puzzle starter.";
        t.icon = "[?]";
        t.settings.windowTitle = "My Puzzle";
        t.settings.backgroundColor = "#1C1C2E";

        BPEProject.ProjectObject bg    = obj("Background", "Part", 0, 0, 800, 600); bg.color = "#1C1C2E"; bg.layer = -10;
        BPEProject.ProjectObject board = obj("GameBoard",  "Part", 200, 100, 400, 400); board.color = "#2A2A4A";

        t.objects.add(bg); t.objects.add(board);

        String[] tileColors = {"#E74C3C","#3498DB","#2ECC71","#F39C12"};
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 2; col++) {
                BPEProject.ProjectObject tile = obj(
                    "Tile" + (row*2+col+1), "UIButton",
                    210 + col*195, 110 + row*195, 185, 185);
                tile.color = tileColors[row*2+col];
                t.objects.add(tile);
            }
        }

        t.scripts.put("GameBoard",
            "script.start\n\n" +
            "attach \"Banana Project Editor\";\n" +
            "attach \"GameBoard\";\n\n" +
            "local moves = 0;\n\n" +
            "event:onStart()\n" +
            "    engine.log(\"Puzzle ready! Click tiles to play.\");\n" +
            "    window.SetTitle(\"Puzzle — Moves: 0\")]\n" +
            "event.end\n\n" +
            "script.end"
        );

        return t;
    }
}
