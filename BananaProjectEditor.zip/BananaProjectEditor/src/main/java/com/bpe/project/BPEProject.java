package com.bpe.project;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class BPEProject {

    public String name;
    public String version    = "1.0";
    public String template   = "";
    public String projectPath;
    public List<ProjectObject> objects = new ArrayList<>();
    public Map<String, String> scripts = new HashMap<>();
    public ProjectSettings settings    = new ProjectSettings();

    // ── inner types ───────────────────────────────────────────────────────────

    public static class ProjectSettings {
        public int    windowWidth       = 800;
        public int    windowHeight      = 600;
        public String windowTitle       = "My Game";
        public String backgroundColor   = "#FFFFFF";
    }

    public static class ProjectObject {
        public String  name;
        public String  type;
        public double  x = 0, y = 0;
        public double  width = 60, height = 60;
        public double  rotation = 0;
        public double  opacity  = 1.0;
        public boolean visible  = true;
        public String  parent   = null;
        public String  color    = "#FFFFFF";
        public int     layer    = 0;

        public ProjectObject() {}
        public ProjectObject(String name, String type) {
            this.name = name; this.type = type;
        }

        public java.awt.Color getAwtColor() {
            try   { return java.awt.Color.decode(color); }
            catch (Exception e) { return java.awt.Color.WHITE; }
        }
    }

    // ── constructors ─────────────────────────────────────────────────────────

    public BPEProject() {}

    public BPEProject(String name, String template, String projectPath) {
        this.name        = name;
        this.template    = template;
        this.projectPath = projectPath;
        this.settings.windowTitle = name;
    }

    // ── paths ─────────────────────────────────────────────────────────────────

    public File getBpeFile()       { return new File(projectPath, name + ".bpe"); }
    public File getScriptsFolder() { return new File(projectPath, "scripts"); }
    public File getCostumesFolder(){ return new File(projectPath, "costumes"); }
    public File getSoundsFolder()  { return new File(projectPath, "sounds"); }

    public void createFolderStructure() {
        new File(projectPath).mkdirs();
        getScriptsFolder().mkdirs();
        getCostumesFolder().mkdirs();
        getSoundsFolder().mkdirs();
    }

    // ── save ─────────────────────────────────────────────────────────────────

    public void save() throws IOException {
        createFolderStructure();

        // scripts → individual .bcode files
        for (Map.Entry<String, String> e : scripts.entrySet()) {
            File f = new File(getScriptsFolder(), e.getKey() + ".bcode");
            Files.write(f.toPath(), e.getValue().getBytes("UTF-8"));
        }

        StringBuilder j = new StringBuilder();
        j.append("{\n");
        j.append("  \"name\": \""    ).append(esc(name)           ).append("\",\n");
        j.append("  \"version\": \"" ).append(esc(version)        ).append("\",\n");
        j.append("  \"template\": \"").append(esc(template)       ).append("\",\n");
        j.append("  \"projectPath\": \"").append(esc(projectPath) ).append("\",\n");
        j.append("  \"settings\": {\n");
        j.append("    \"windowWidth\": " ).append(settings.windowWidth ).append(",\n");
        j.append("    \"windowHeight\": ").append(settings.windowHeight).append(",\n");
        j.append("    \"windowTitle\": \"" ).append(esc(settings.windowTitle)     ).append("\",\n");
        j.append("    \"backgroundColor\": \"").append(esc(settings.backgroundColor)).append("\"\n");
        j.append("  },\n");
        j.append("  \"objects\": [\n");
        for (int i = 0; i < objects.size(); i++) {
            ProjectObject o = objects.get(i);
            j.append("    {\n");
            j.append("      \"name\": \""    ).append(esc(o.name)  ).append("\",\n");
            j.append("      \"type\": \""    ).append(esc(o.type)  ).append("\",\n");
            j.append("      \"x\": "         ).append(o.x          ).append(",\n");
            j.append("      \"y\": "         ).append(o.y          ).append(",\n");
            j.append("      \"width\": "     ).append(o.width      ).append(",\n");
            j.append("      \"height\": "    ).append(o.height     ).append(",\n");
            j.append("      \"rotation\": "  ).append(o.rotation   ).append(",\n");
            j.append("      \"opacity\": "   ).append(o.opacity    ).append(",\n");
            j.append("      \"visible\": "   ).append(o.visible    ).append(",\n");
            j.append("      \"color\": \""   ).append(esc(o.color) ).append("\",\n");
            j.append("      \"layer\": "     ).append(o.layer      ).append(",\n");
            j.append("      \"parent\": "    )
              .append(o.parent == null ? "null" : "\"" + esc(o.parent) + "\"").append("\n");
            j.append("    }").append(i < objects.size() - 1 ? "," : "").append("\n");
        }
        j.append("  ]\n}\n");

        Files.write(getBpeFile().toPath(), j.toString().getBytes("UTF-8"));
    }

    // ── load ─────────────────────────────────────────────────────────────────

    public static BPEProject load(File bpeFile) throws IOException {
        String raw = new String(Files.readAllBytes(bpeFile.toPath()), "UTF-8");
        BPEProject p = new BPEProject();
        p.projectPath = bpeFile.getParent();
        p.name        = str(raw, "name");
        p.version     = str(raw, "version");
        p.template    = str(raw, "template");
        p.settings.windowWidth       = num(raw, "windowWidth",  800);
        p.settings.windowHeight      = num(raw, "windowHeight", 600);
        p.settings.windowTitle       = str(raw, "windowTitle");
        p.settings.backgroundColor   = str(raw, "backgroundColor");
        if (p.settings.backgroundColor.isEmpty()) p.settings.backgroundColor = "#FFFFFF";

        // ── parse objects array ───────────────────────────────────────────────
        int arrStart = raw.indexOf("\"objects\"");
        if (arrStart >= 0) {
            int bracket = raw.indexOf('[', arrStart);
            int end     = raw.lastIndexOf(']');
            if (bracket >= 0 && end > bracket) {
                String arr = raw.substring(bracket + 1, end);
                // split on object boundaries
                int depth = 0, objStart = -1;
                for (int i = 0; i < arr.length(); i++) {
                    char c = arr.charAt(i);
                    if (c == '{') { if (depth++ == 0) objStart = i; }
                    else if (c == '}') {
                        if (--depth == 0 && objStart >= 0) {
                            String chunk = arr.substring(objStart, i + 1);
                            ProjectObject o = new ProjectObject();
                            o.name     = str(chunk, "name");
                            o.type     = str(chunk, "type");
                            o.x        = dbl(chunk, "x",        0);
                            o.y        = dbl(chunk, "y",        0);
                            o.width    = dbl(chunk, "width",   60);
                            o.height   = dbl(chunk, "height",  60);
                            o.rotation = dbl(chunk, "rotation", 0);
                            o.opacity  = dbl(chunk, "opacity",  1);
                            o.visible  = bool(chunk, "visible", true);
                            o.color    = str(chunk, "color");
                            if (o.color.isEmpty()) o.color = "#FFFFFF";
                            o.layer    = num(chunk, "layer",    0);
                            String par = str(chunk, "parent");
                            o.parent   = par.isEmpty() ? null : par;
                            if (o.name != null && !o.name.isEmpty()) p.objects.add(o);
                        }
                    }
                }
            }
        }

        // ── load scripts ──────────────────────────────────────────────────────
        File sf = new File(p.projectPath, "scripts");
        if (sf.exists() && sf.isDirectory()) {
            File[] bcode = sf.listFiles((d, n) -> n.endsWith(".bcode"));
            if (bcode != null) for (File f : bcode) {
                String objName = f.getName().replace(".bcode", "");
                p.scripts.put(objName, new String(Files.readAllBytes(f.toPath()), "UTF-8"));
            }
        }
        return p;
    }

    // ── JSON helpers ──────────────────────────────────────────────────────────

    private static String str(String j, String key) {
        String tag = "\"" + key + "\": \"";
        int i = j.indexOf(tag);
        if (i < 0) return "";
        i += tag.length();
        StringBuilder sb = new StringBuilder();
        while (i < j.length()) {
            char c = j.charAt(i);
            if (c == '"') break;
            if (c == '\\' && i + 1 < j.length()) {
                char n = j.charAt(i + 1);
                if (n == 'n') { sb.append('\n'); i += 2; continue; }
                if (n == '"') { sb.append('"');  i += 2; continue; }
                if (n == '\\') { sb.append('\\'); i += 2; continue; }
            }
            sb.append(c); i++;
        }
        return sb.toString();
    }

    private static int num(String j, String key, int def) {
        String tag = "\"" + key + "\": ";
        int i = j.indexOf(tag);
        if (i < 0) return def;
        i += tag.length();
        int end = i;
        while (end < j.length() && (Character.isDigit(j.charAt(end)) || j.charAt(end) == '-')) end++;
        try { return Integer.parseInt(j.substring(i, end)); } catch (Exception e) { return def; }
    }

    private static double dbl(String j, String key, double def) {
        String tag = "\"" + key + "\": ";
        int i = j.indexOf(tag);
        if (i < 0) return def;
        i += tag.length();
        int end = i;
        while (end < j.length() && (Character.isDigit(j.charAt(end)) || j.charAt(end) == '.' || j.charAt(end) == '-' || j.charAt(end) == 'E' || j.charAt(end) == 'e')) end++;
        try { return Double.parseDouble(j.substring(i, end)); } catch (Exception e) { return def; }
    }

    private static boolean bool(String j, String key, boolean def) {
        String tag = "\"" + key + "\": ";
        int i = j.indexOf(tag);
        if (i < 0) return def;
        i += tag.length();
        if (j.startsWith("true", i))  return true;
        if (j.startsWith("false", i)) return false;
        return def;
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
}
