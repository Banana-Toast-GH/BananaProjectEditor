package com.bpe.project;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Manages recent project history stored in AppData.
 */
public class ProjectHistory {

    private static final String APP_NAME = "BananaProjectEditor";
    private static final String HISTORY_FILE = "history.txt";
    private static final int MAX_HISTORY = 10;

    private List<HistoryEntry> entries = new ArrayList<>();

    public static class HistoryEntry {
        public String name;
        public String path;
        public String lastOpened;

        public HistoryEntry(String name, String path, String lastOpened) {
            this.name = name;
            this.path = path;
            this.lastOpened = lastOpened;
        }
    }

    public ProjectHistory() {
        load();
    }

    public List<HistoryEntry> getEntries() {
        return Collections.unmodifiableList(entries);
    }

    public void addEntry(BPEProject project) {
        // Remove existing entry for same path
        entries.removeIf(e -> e.path.equals(project.getBpeFile().getAbsolutePath()));

        // Add to front
        String date = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());
        entries.add(0, new HistoryEntry(project.name, project.getBpeFile().getAbsolutePath(), date));

        // Trim to max
        while (entries.size() > MAX_HISTORY) entries.remove(entries.size() - 1);

        save();
    }

    public void removeEntry(String path) {
        entries.removeIf(e -> e.path.equals(path));
        save();
    }

    private File getHistoryFile() {
        String appData = System.getenv("APPDATA");
        if (appData == null) appData = System.getProperty("user.home");
        File dir = new File(appData, APP_NAME);
        dir.mkdirs();
        return new File(dir, HISTORY_FILE);
    }

    private void load() {
        entries.clear();
        File file = getHistoryFile();
        if (!file.exists()) return;
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|", 3);
                if (parts.length == 3) {
                    entries.add(new HistoryEntry(parts[0], parts[1], parts[2]));
                }
            }
        } catch (IOException ignored) {}
    }

    private void save() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(getHistoryFile()))) {
            for (HistoryEntry entry : entries) {
                writer.println(entry.name + "|" + entry.path + "|" + entry.lastOpened);
            }
        } catch (IOException ignored) {}
    }
}
