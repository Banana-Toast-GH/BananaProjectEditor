package com.bpe.runtime;

import com.bpe.editor.GameWindow;
import com.bpe.project.BPEProject;
import com.bpe.ui.BPETheme;

import javax.swing.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.zip.*;

/**
 * Entry point for exported games.
 * Extracts embedded project from JAR and runs it.
 */
public class GameLauncher {
    public static void main(String[] args) throws Exception {
        // Extract embedded project to temp dir
        Path tmpDir = Files.createTempDirectory("bpe_game_");
        Runtime.getRuntime().addShutdownHook(new Thread(() -> deleteDir(tmpDir.toFile())));

        // Extract project files from JAR
        try (ZipInputStream zip = new ZipInputStream(
                GameLauncher.class.getProtectionDomain().getCodeSource().getLocation().openStream())) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                String name = entry.getName();
                if (name.equals("project.bpe") || name.startsWith("scripts/") || name.startsWith("costumes/")) {
                    Path dest = tmpDir.resolve(name);
                    Files.createDirectories(dest.getParent());
                    if (!entry.isDirectory())
                        Files.copy(zip, dest, StandardCopyOption.REPLACE_EXISTING);
                }
                zip.closeEntry();
            }
        }

        File bpeFile = tmpDir.resolve("project.bpe").toFile();
        if (!bpeFile.exists()) {
            JOptionPane.showMessageDialog(null, "No project data found!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Load project — then immediately override projectPath so scripts/costumes
        // resolve from the temp dir, not the original author's machine path
        BPEProject project = BPEProject.load(bpeFile);
        project.projectPath = tmpDir.toString();

        // Reload scripts from temp dir (they were extracted there but load() used old path)
        project.scripts.clear();
        File scriptsDir = new File(tmpDir.toFile(), "scripts");
        if (scriptsDir.exists()) {
            for (File f : scriptsDir.listFiles((d, n) -> n.endsWith(".bcode"))) {
                String name = f.getName().replace(".bcode", "");
                project.scripts.put(name, new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            }
        }

        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
            BPETheme.apply();
            GameWindow gw = new GameWindow(project,
                msg -> System.out.println("[LOG] " + msg),
                msg -> System.out.println("[WARN] " + msg),
                msg -> System.err.println("[ERROR] " + msg)
            );
            gw.setTitle(project.settings.windowTitle);
            gw.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            gw.setVisible(true);
            gw.start();
        });
    }

    private static void deleteDir(File f) {
        if (f.isDirectory()) for (File c : f.listFiles()) deleteDir(c);
        f.delete();
    }
}
