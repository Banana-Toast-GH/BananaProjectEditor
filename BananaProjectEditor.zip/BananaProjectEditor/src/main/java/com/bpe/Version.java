package com.bpe;

import java.io.*;
import java.nio.file.*;

public class Version {
    public static final String FALLBACK = "v0.3.7";

    public static String get() {
        // Try to read from installed_version.txt next to the JAR
        try {
            String jarDir = new File(Version.class.getProtectionDomain()
                .getCodeSource().getLocation().toURI()).getParent();
            File vf = new File(jarDir, "installed_version.txt");
            if (vf.exists()) {
                String v = new String(Files.readAllBytes(vf.toPath())).trim();
                if (!v.isEmpty()) return v;
            }
        } catch (Exception ignored) {}
        return FALLBACK;
    }
}
