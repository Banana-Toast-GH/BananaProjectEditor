package com.bpe.hierarchy;

import com.bpe.project.BPEProject;
import com.bpe.ui.BPETheme;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.TransferHandler;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;

public class HierarchyPanel extends JPanel {

    private JTree tree;
    private DefaultMutableTreeNode rootTreeNode;
    private HierarchyNode rootNode;
    private BPEProject project;

    // Colors matching the mockup's dark theme
    private static final Color BG = BPETheme.BG_DEEP;
    private static final Color TEXT = BPETheme.TEXT_PRIMARY;
    private static final Color SELECTED = BPETheme.BG_SELECTED;
    private static final Color HEADER_BG = BPETheme.BG_MID;

    // Icon colors per node type
    private static final Color COLOR_ROOT = new Color(180, 80, 200);     // purple
    private static final Color COLOR_WINDOW = new Color(180, 180, 180);  // gray
    private static final Color COLOR_JAVA_DEPS = new Color(220, 160, 40); // orange
    private static final Color COLOR_JAVA_VER = new Color(200, 200, 200); // light gray
    private static final Color COLOR_OBJECT = new Color(100, 180, 220);   // blue
    private static final Color COLOR_SDK = new Color(100, 200, 120);      // green

    private ObjectSelectionListener selectionListener;

    public interface ObjectSelectionListener {
        void onObjectSelected(HierarchyNode node);
    }

    public HierarchyPanel() {
        setLayout(new BorderLayout());
        setBackground(BG);
        setPreferredSize(new Dimension(220, 0));

        // Header with + button
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(HEADER_BG);
        header.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

        JLabel title = new JLabel("  Hierarchy");
        title.setForeground(TEXT);
        title.setFont(new Font("Monospaced", Font.PLAIN, 12));
        header.add(title, BorderLayout.WEST);

        JButton addBtn = new JButton("+");
        addBtn.setFont(new Font("Consolas", Font.BOLD, 16));
        addBtn.setForeground(BPETheme.ACCENT);
        addBtn.setBackground(BPETheme.BG_MID);
        addBtn.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        addBtn.setFocusPainted(false);
        addBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addBtn.setToolTipText("Add Object");
        addBtn.addActionListener(e -> openObjectExplorer());
        header.add(addBtn, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // Build default hierarchy
        rootNode = buildDefaultHierarchy();
        rootTreeNode = buildTreeNode(rootNode);

        tree = new JTree(rootTreeNode);
        tree.setBackground(BG);
        tree.setForeground(TEXT);
        tree.setFont(new Font("Monospaced", Font.PLAIN, 11));
        tree.setRootVisible(true);
        tree.setShowsRootHandles(true);
        tree.setBorder(BorderFactory.createEmptyBorder(4, 0, 4, 0));
        tree.setCellRenderer(new HierarchyCellRenderer());

        // Expand all by default
        for (int i = 0; i < tree.getRowCount(); i++) tree.expandRow(i);

        tree.setDragEnabled(true);
        tree.setDropMode(DropMode.ON_OR_INSERT);
        tree.setTransferHandler(new HierarchyTransferHandler());

        tree.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = tree.getRowForLocation(e.getX(), e.getY());
                if (row == -1) return;
                DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) tree.getPathForRow(row).getLastPathComponent();
                HierarchyNode node = (HierarchyNode) treeNode.getUserObject();
                if (selectionListener != null) selectionListener.onObjectSelected(node);

                // Right click context menu
                if (SwingUtilities.isRightMouseButton(e)) {
                    showContextMenu(e, node, treeNode);
                }
            }
        });

        JScrollPane scroll = new JScrollPane(tree);
        scroll.setBackground(BG);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(BG);
        add(scroll, BorderLayout.CENTER);
    }

    private HierarchyNode buildDefaultHierarchy() {
        HierarchyNode root = new HierarchyNode("Banana Project Editor", HierarchyNode.NodeType.ROOT);
        HierarchyNode window = new HierarchyNode("Window Frame", HierarchyNode.NodeType.WINDOW_FRAME);
        HierarchyNode javaDeps = new HierarchyNode("Java Dependencies", HierarchyNode.NodeType.JAVA_DEPS);
        String javaVersion = System.getProperty("java.version");
        HierarchyNode javaVer = new HierarchyNode("Java v" + javaVersion, HierarchyNode.NodeType.JAVA_VERSION);

        javaDeps.addChild(javaVer);
        root.addChild(window);
        root.addChild(javaDeps);

        return root;
    }

    private DefaultMutableTreeNode buildTreeNode(HierarchyNode node) {
        DefaultMutableTreeNode treeNode = new DefaultMutableTreeNode(node);
        for (HierarchyNode child : node.getChildren()) {
            treeNode.add(buildTreeNode(child));
        }
        return treeNode;
    }

    private void showContextMenu(MouseEvent e, HierarchyNode node, DefaultMutableTreeNode treeNode) {
        JPopupMenu menu = new JPopupMenu();
        menu.setBackground(new Color(55, 55, 55));

        if (node.getType() == HierarchyNode.NodeType.ROOT ||
            node.getType() == HierarchyNode.NodeType.OBJECT) {
            JMenuItem addObj = new JMenuItem("Add Object");
            addObj.setForeground(TEXT);
            addObj.setBackground(new Color(55, 55, 55));
            addObj.addActionListener(ev -> addObject(node, treeNode));
            menu.add(addObj);
        }

        if (node.canDelete()) {
            JMenuItem delete = new JMenuItem("Delete");
            delete.setForeground(new Color(220, 80, 80));
            delete.setBackground(new Color(55, 55, 55));
            delete.addActionListener(ev -> deleteNode(node, treeNode));
            menu.add(delete);
        }

        if (node.canRename()) {
            JMenuItem rename = new JMenuItem("Rename");
            rename.setForeground(TEXT);
            rename.setBackground(new Color(55, 55, 55));
            rename.addActionListener(ev -> renameNode(node, treeNode));
            menu.add(rename);
        }

        if (menu.getComponentCount() > 0)
            menu.show(tree, e.getX(), e.getY());
    }

    private void addObject(HierarchyNode parent, DefaultMutableTreeNode parentTreeNode) {
        String name = JOptionPane.showInputDialog(this, "Object Name:", "New Object", JOptionPane.PLAIN_MESSAGE);
        if (name == null || name.trim().isEmpty()) return;
        HierarchyNode newNode = new HierarchyNode(name.trim(), HierarchyNode.NodeType.OBJECT);
        parent.addChild(newNode);
        DefaultMutableTreeNode newTreeNode = new DefaultMutableTreeNode(newNode);
        parentTreeNode.add(newTreeNode);
        ((DefaultTreeModel) tree.getModel()).reload(parentTreeNode);
        // Expand parent
        tree.expandPath(new javax.swing.tree.TreePath(parentTreeNode.getPath()));
    }

    private void deleteNode(HierarchyNode node, DefaultMutableTreeNode treeNode) {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Delete \"" + node.getName() + "\"?", "Confirm Delete",
            JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;
        node.getParent().removeChild(node);
        ((DefaultTreeModel) tree.getModel()).removeNodeFromParent(treeNode);
    }

    private void renameNode(HierarchyNode node, DefaultMutableTreeNode treeNode) {
        String name = JOptionPane.showInputDialog(this, "New Name:", node.getName());
        if (name == null || name.trim().isEmpty()) return;
        node.setName(name.trim());
        ((DefaultTreeModel) tree.getModel()).nodeChanged(treeNode);
    }

    private void openObjectExplorer() {
        new ObjectExplorerDialog((JFrame) SwingUtilities.getWindowAncestor(this), this).setVisible(true);
    }

    public void setProject(com.bpe.project.BPEProject p) { this.project = p; }

    public void addNewObject(String name, String type) {
        HierarchyNode newNode = new HierarchyNode(name, HierarchyNode.NodeType.OBJECT);
        rootNode.addChild(newNode);
        DefaultMutableTreeNode newTreeNode = new DefaultMutableTreeNode(newNode);
        rootTreeNode.add(newTreeNode);
        ((DefaultTreeModel) tree.getModel()).reload(rootTreeNode);
        tree.expandPath(new javax.swing.tree.TreePath(rootTreeNode.getPath()));

        // Also add to project so it appears on canvas and in game
        if (project != null) {
            com.bpe.project.BPEProject.ProjectObject obj =
                new com.bpe.project.BPEProject.ProjectObject(name, type);
            // Default placement: centre of game bounds
            obj.x = project.settings.windowWidth  / 2 - 25;
            obj.y = project.settings.windowHeight / 2 - 25;
            obj.width  = 50;
            obj.height = 50;
            project.objects.add(obj);
        }
    }

    public boolean nameExists(String name) {
        return nameExistsIn(rootNode, name);
    }

    private boolean nameExistsIn(HierarchyNode node, String name) {
        if (node.getName().equals(name)) return true;
        for (HierarchyNode child : node.getChildren()) {
            if (nameExistsIn(child, name)) return true;
        }
        return false;
    }

    public void addSDK(String sdkName) {
        // Find Java Dependencies node
        HierarchyNode javaDeps = findNodeByType(rootNode, HierarchyNode.NodeType.JAVA_DEPS);
        if (javaDeps == null) return;
        HierarchyNode sdk = new HierarchyNode(sdkName, HierarchyNode.NodeType.SDK);
        javaDeps.addChild(sdk);
        // Rebuild tree
        DefaultMutableTreeNode javaDepsTreeNode = findTreeNode(rootTreeNode, javaDeps);
        if (javaDepsTreeNode != null) {
            javaDepsTreeNode.add(new DefaultMutableTreeNode(sdk));
            ((DefaultTreeModel) tree.getModel()).reload(javaDepsTreeNode);
        }
    }

    private HierarchyNode findNodeByType(HierarchyNode node, HierarchyNode.NodeType type) {
        if (node.getType() == type) return node;
        for (HierarchyNode child : node.getChildren()) {
            HierarchyNode found = findNodeByType(child, type);
            if (found != null) return found;
        }
        return null;
    }

    private DefaultMutableTreeNode findTreeNode(DefaultMutableTreeNode treeNode, HierarchyNode target) {
        if (treeNode.getUserObject() == target) return treeNode;
        for (int i = 0; i < treeNode.getChildCount(); i++) {
            DefaultMutableTreeNode found = findTreeNode((DefaultMutableTreeNode) treeNode.getChildAt(i), target);
            if (found != null) return found;
        }
        return null;
    }

    public void setSelectionListener(ObjectSelectionListener listener) {
        this.selectionListener = listener;
    }

    /** Load objects from a saved project into the hierarchy */
    public void loadProject(com.bpe.project.BPEProject project) {
        for (com.bpe.project.BPEProject.ProjectObject obj : project.objects) {
            if (obj.parent == null) {
                HierarchyNode node = new HierarchyNode(obj.name, HierarchyNode.NodeType.OBJECT);
                rootNode.addChild(node);
                rootTreeNode.add(new DefaultMutableTreeNode(node));
            }
        }
        ((DefaultTreeModel) tree.getModel()).reload(rootTreeNode);
        for (int i = 0; i < tree.getRowCount(); i++) tree.expandRow(i);
    }

    /** Sync current hierarchy objects back to project */
    public void syncObjectsToProject(com.bpe.project.BPEProject project) {
        // Only update parent relationships - DO NOT recreate objects or wipe positions/sizes
        syncParents(rootNode, null, project);
    }

    private void syncParents(HierarchyNode node, String parentName, com.bpe.project.BPEProject project) {
        for (HierarchyNode child : node.getChildren()) {
            if (child.getType() == HierarchyNode.NodeType.OBJECT) {
                // Find existing object and just update its parent field
                for (com.bpe.project.BPEProject.ProjectObject obj : project.objects) {
                    if (obj.name.equals(child.getName())) {
                        obj.parent = parentName;
                        break;
                    }
                }
                syncParents(child, child.getName(), project);
            } else {
                syncParents(child, parentName, project);
            }
        }
    }

    // Custom cell renderer for colored icons and styling
    private class HierarchyCellRenderer extends DefaultTreeCellRenderer {
        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value,
                boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {

            super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);

            DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) value;
            HierarchyNode node = (HierarchyNode) treeNode.getUserObject();

            setForeground(TEXT);
            setBackground(selected ? SELECTED : BG);
            setOpaque(true);
            setFont(new Font("Monospaced", Font.PLAIN, 11));
            setText(node.getName());

            // Colored dot icon per type
            setIcon(createDotIcon(getIconColor(node.getType())));

            return this;
        }

        private Color getIconColor(HierarchyNode.NodeType type) {
            switch (type) {
                case ROOT: return COLOR_ROOT;
                case WINDOW_FRAME: return COLOR_WINDOW;
                case JAVA_DEPS: return COLOR_JAVA_DEPS;
                case JAVA_VERSION: return COLOR_JAVA_VER;
                case SDK: return COLOR_SDK;
                case OBJECT: return COLOR_OBJECT;
                default: return COLOR_OBJECT;
            }
        }

        private Icon createDotIcon(Color color) {
            return new Icon() {
                public void paintIcon(Component c, Graphics g, int x, int y) {
                    g.setColor(color);
                    g.fillOval(x, y + 2, 10, 10);
                }
                public int getIconWidth() { return 12; }
                public int getIconHeight() { return 14; }
            };
        }
    }

    // Drag and drop transfer handler for hierarchy reordering
    private class HierarchyTransferHandler extends TransferHandler {
        private final DataFlavor NODE_FLAVOR = new DataFlavor(DefaultMutableTreeNode.class, "TreeNode");
        private DefaultMutableTreeNode draggedNode = null;

        @Override public int getSourceActions(JComponent c) { return COPY_OR_MOVE; }

        @Override
        protected Transferable createTransferable(JComponent c) {
            TreePath path = tree.getSelectionPath();
            if (path == null) return null;
            draggedNode = (DefaultMutableTreeNode) path.getLastPathComponent();
            HierarchyNode node = (HierarchyNode) draggedNode.getUserObject();
            if (node.getType() != HierarchyNode.NodeType.OBJECT) return null;
            final String nodeName = node.getName();
            return new Transferable() {
                public DataFlavor[] getTransferDataFlavors() {
                    return new DataFlavor[]{NODE_FLAVOR, DataFlavor.stringFlavor};
                }
                public boolean isDataFlavorSupported(DataFlavor f) {
                    return NODE_FLAVOR.equals(f) || DataFlavor.stringFlavor.equals(f);
                }
                public Object getTransferData(DataFlavor f) throws java.awt.datatransfer.UnsupportedFlavorException {
                    if (DataFlavor.stringFlavor.equals(f)) return nodeName;
                    if (NODE_FLAVOR.equals(f)) return draggedNode;
                    throw new java.awt.datatransfer.UnsupportedFlavorException(f);
                }
            };
        }

        @Override
        public boolean canImport(TransferSupport support) {
            if (!support.isDrop()) return false;
            JTree.DropLocation dl = (JTree.DropLocation) support.getDropLocation();
            TreePath path = dl.getPath();
            if (path == null) return false;
            DefaultMutableTreeNode target = (DefaultMutableTreeNode) path.getLastPathComponent();
            HierarchyNode targetNode = (HierarchyNode) target.getUserObject();
            return targetNode.getType() == HierarchyNode.NodeType.ROOT ||
                   targetNode.getType() == HierarchyNode.NodeType.OBJECT;
        }

        @Override
        public boolean importData(TransferSupport support) {
            if (!canImport(support) || draggedNode == null) return false;
            JTree.DropLocation dl = (JTree.DropLocation) support.getDropLocation();
            DefaultMutableTreeNode targetTreeNode = (DefaultMutableTreeNode) dl.getPath().getLastPathComponent();
            HierarchyNode targetNode = (HierarchyNode) targetTreeNode.getUserObject();
            HierarchyNode draggedHNode = (HierarchyNode) draggedNode.getUserObject();
            if (targetTreeNode == draggedNode) return false;

            DefaultMutableTreeNode oldParentTreeNode = (DefaultMutableTreeNode) draggedNode.getParent();
            if (oldParentTreeNode == null) return false;
            HierarchyNode oldParent = (HierarchyNode) oldParentTreeNode.getUserObject();
            oldParent.removeChild(draggedHNode);
            oldParentTreeNode.remove(draggedNode);

            targetNode.addChild(draggedHNode);
            targetTreeNode.add(draggedNode);

            DefaultTreeModel model = (DefaultTreeModel) tree.getModel();
            model.reload(oldParentTreeNode);
            model.reload(targetTreeNode);
            tree.expandPath(dl.getPath());
            return true;
        }
    }
}
