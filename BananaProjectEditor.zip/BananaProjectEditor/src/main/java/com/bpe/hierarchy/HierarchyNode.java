package com.bpe.hierarchy;

import java.util.ArrayList;
import java.util.List;

public class HierarchyNode {

    public enum NodeType {
        ROOT,           // Banana Project Editor
        WINDOW_FRAME,   // Window Frame
        JAVA_DEPS,      // Java Dependencies folder
        JAVA_VERSION,   // Java vX.XX
        SDK,            // User-imported SDK
        OBJECT          // Regular game object
    }

    private String name;
    private NodeType type;
    private HierarchyNode parent;
    private List<HierarchyNode> children = new ArrayList<>();

    // Permissions
    private boolean canDelete;
    private boolean canRename;

    public HierarchyNode(String name, NodeType type) {
        this.name = name;
        this.type = type;

        // Set permissions based on type
        switch (type) {
            case ROOT:
            case WINDOW_FRAME:
            case JAVA_DEPS:
            case JAVA_VERSION:
                this.canDelete = false;
                this.canRename = false;
                break;
            case SDK:
                this.canDelete = true;
                this.canRename = false;
                break;
            case OBJECT:
                this.canDelete = true;
                this.canRename = true;
                break;
        }
    }

    public void addChild(HierarchyNode child) {
        child.parent = this;
        children.add(child);
    }

    public boolean removeChild(HierarchyNode child) {
        if (!child.canDelete) return false;
        return children.remove(child);
    }

    public String getName() { return name; }
    public void setName(String name) { if (canRename) this.name = name; }
    public NodeType getType() { return type; }
    public HierarchyNode getParent() { return parent; }
    public List<HierarchyNode> getChildren() { return children; }
    public boolean canDelete() { return canDelete; }
    public boolean canRename() { return canRename; }
}
