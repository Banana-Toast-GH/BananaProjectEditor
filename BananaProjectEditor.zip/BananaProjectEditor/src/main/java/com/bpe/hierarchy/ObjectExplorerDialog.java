package com.bpe.hierarchy;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class ObjectExplorerDialog extends JDialog {

    private static final Color BG = new Color(40, 40, 40);
    private static final Color BG_DARK = new Color(30, 30, 30);
    private static final Color BG_HEADER = new Color(50, 50, 50);
    private static final Color TEXT = new Color(220, 220, 220);
    private static final Color TEXT_DIM = new Color(140, 140, 140);
    private static final Color ACCENT = new Color(180, 80, 200);
    private static final Color SELECTED = new Color(70, 100, 140);
    private static final Color HOVER = new Color(60, 60, 60);

    private HierarchyPanel hierarchyPanel;
    private JPanel objectGrid;
    private String selectedCategory = "All";
    private ObjectEntry selectedEntry = null;
    private JLabel previewName;
    private JLabel previewDesc;
    private JButton addBtn;

    // Object catalog
    private static final Map<String, java.util.List<ObjectEntry>> CATALOG = new LinkedHashMap<>();

    static {
        CATALOG.put("Visual", Arrays.asList(
            new ObjectEntry("Sprite", "Visual", "A 2D sprite object with costume support", new Color(100, 180, 255)),
            new ObjectEntry("AnimatedSprite", "Visual", "A sprite with multiple animation frames", new Color(100, 180, 255)),
            new ObjectEntry("Part", "Visual", "A basic rectangular part", new Color(100, 180, 255)),
            new ObjectEntry("Label", "Visual", "A text label", new Color(100, 180, 255)),
            new ObjectEntry("Image", "Visual", "A static image object", new Color(100, 180, 255))
        ));
        CATALOG.put("Logic", Arrays.asList(
            new ObjectEntry("Script", "Logic", "A standalone BCode script", new Color(180, 80, 200)),
            new ObjectEntry("Controller", "Logic", "A game controller object", new Color(180, 80, 200)),
            new ObjectEntry("StateMachine", "Logic", "Manages object states", new Color(180, 80, 200)),
            new ObjectEntry("Timer", "Logic", "A countdown or repeating timer", new Color(180, 80, 200))
        ));
        CATALOG.put("Physics", Arrays.asList(
            new ObjectEntry("RigidBody", "Physics", "An object affected by physics", new Color(220, 160, 40)),
            new ObjectEntry("Collider", "Physics", "Defines a collision shape", new Color(220, 160, 40)),
            new ObjectEntry("TriggerZone", "Physics", "A zone that detects overlap", new Color(220, 160, 40))
        ));
        CATALOG.put("Audio", Arrays.asList(
            new ObjectEntry("Sound", "Audio", "Plays a sound effect", new Color(100, 200, 120)),
            new ObjectEntry("Music", "Audio", "Plays background music", new Color(100, 200, 120))
        ));
        CATALOG.put("UI", Arrays.asList(
            new ObjectEntry("UIFrame", "UI", "A UI container frame", new Color(220, 120, 80)),
            new ObjectEntry("UIButton", "UI", "A clickable UI button", new Color(220, 120, 80)),
            new ObjectEntry("UILabel", "UI", "A UI text label", new Color(220, 120, 80)),
            new ObjectEntry("UIImage", "UI", "A UI image element", new Color(220, 120, 80))
        ));
        CATALOG.put("Camera", Arrays.asList(
            new ObjectEntry("Camera2D", "Camera", "A 2D camera that follows objects", new Color(80, 200, 200)),
            new ObjectEntry("Viewport", "Camera", "A screen viewport / render target", new Color(80, 200, 200))
        ));
        CATALOG.put("Effects", Arrays.asList(
            new ObjectEntry("Light2D", "Effects", "A 2D radial light source", new Color(255, 230, 80)),
            new ObjectEntry("ParticleSystem", "Effects", "Emits particles for effects", new Color(255, 150, 50))
        ));
        CATALOG.put("Other", Arrays.asList(
            new ObjectEntry("Folder", "Other", "Organizes objects in the hierarchy", new Color(160, 160, 160)),
            new ObjectEntry("Group", "Other", "Groups multiple objects together", new Color(160, 160, 160))
        ));
    }

    // Track counters per type for default naming
    private static final Map<String, Integer> nameCounters = new HashMap<>();

    public ObjectExplorerDialog(JFrame parent, HierarchyPanel hierarchyPanel) {
        super(parent, "Object Explorer", true);
        this.hierarchyPanel = hierarchyPanel;

        setSize(600, 420);
        setLocationRelativeTo(parent);
        setResizable(false);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());

        add(buildHeader(), BorderLayout.NORTH);
        add(buildContent(), BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);

        refreshGrid("All");
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BG_HEADER);
        header.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));

        JLabel title = new JLabel("Object Explorer");
        title.setForeground(TEXT);
        title.setFont(new Font("Monospaced", Font.BOLD, 13));
        header.add(title, BorderLayout.WEST);

        JLabel sub = new JLabel("Double-click to add  |  Single-click to preview");
        sub.setForeground(TEXT_DIM);
        sub.setFont(new Font("Monospaced", Font.PLAIN, 10));
        header.add(sub, BorderLayout.EAST);

        return header;
    }

    private JSplitPane buildContent() {
        // Left: category list
        JPanel categoryPanel = new JPanel();
        categoryPanel.setLayout(new BoxLayout(categoryPanel, BoxLayout.Y_AXIS));
        categoryPanel.setBackground(BG_DARK);
        categoryPanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));

        String[] categories = {"All", "Visual", "Logic", "Physics", "Audio", "UI", "Camera", "Effects", "Other"};
        for (String cat : categories) {
            JLabel catLabel = new JLabel("  " + cat);
            catLabel.setForeground(TEXT);
            catLabel.setFont(new Font("Monospaced", Font.PLAIN, 11));
            catLabel.setOpaque(true);
            catLabel.setBackground(cat.equals("All") ? SELECTED : BG_DARK);
            catLabel.setBorder(BorderFactory.createEmptyBorder(6, 4, 6, 4));
            catLabel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
            catLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            catLabel.addMouseListener(new MouseAdapter() {
                @Override public void mouseClicked(MouseEvent e) {
                    selectedCategory = cat;
                    // Reset all backgrounds
                    for (Component c : categoryPanel.getComponents()) {
                        if (c instanceof JLabel) {
                            ((JLabel)c).setBackground(BG_DARK);
                        }
                    }
                    catLabel.setBackground(SELECTED);
                    refreshGrid(cat);
                }
                @Override public void mouseEntered(MouseEvent e) {
                    if (!cat.equals(selectedCategory)) catLabel.setBackground(HOVER);
                }
                @Override public void mouseExited(MouseEvent e) {
                    if (!cat.equals(selectedCategory)) catLabel.setBackground(BG_DARK);
                }
            });
            categoryPanel.add(catLabel);
        }

        JScrollPane catScroll = new JScrollPane(categoryPanel);
        catScroll.setBorder(BorderFactory.createEmptyBorder());
        catScroll.setBackground(BG_DARK);
        catScroll.getViewport().setBackground(BG_DARK);
        catScroll.setPreferredSize(new Dimension(120, 0));

        // Right: object grid
        objectGrid = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        objectGrid.setBackground(BG);

        JScrollPane gridScroll = new JScrollPane(objectGrid);
        gridScroll.setBorder(BorderFactory.createEmptyBorder());
        gridScroll.setBackground(BG);
        gridScroll.getViewport().setBackground(BG);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, catScroll, gridScroll);
        split.setDividerLocation(120);
        split.setDividerSize(3);
        split.setBorder(null);

        return split;
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(BG_HEADER);
        footer.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));

        // Preview info
        JPanel previewPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        previewPanel.setBackground(BG_HEADER);
        previewName = new JLabel("Select an object");
        previewName.setForeground(TEXT);
        previewName.setFont(new Font("Monospaced", Font.BOLD, 11));
        previewDesc = new JLabel("");
        previewDesc.setForeground(TEXT_DIM);
        previewDesc.setFont(new Font("Monospaced", Font.PLAIN, 10));
        previewPanel.add(previewName);
        previewPanel.add(previewDesc);
        footer.add(previewPanel, BorderLayout.WEST);

        // Buttons
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        btnPanel.setBackground(BG_HEADER);

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.setFont(new Font("Monospaced", Font.PLAIN, 11));
        cancelBtn.setForeground(TEXT_DIM);
        cancelBtn.setBackground(new Color(55, 55, 55));
        cancelBtn.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));
        cancelBtn.setFocusPainted(false);
        cancelBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        cancelBtn.addActionListener(e -> dispose());

        addBtn = new JButton("Add Object");
        addBtn.setFont(new Font("Monospaced", Font.BOLD, 11));
        addBtn.setForeground(Color.WHITE);
        addBtn.setBackground(ACCENT);
        addBtn.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));
        addBtn.setFocusPainted(false);
        addBtn.setEnabled(false);
        addBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addBtn.addActionListener(e -> addSelectedObject());

        btnPanel.add(cancelBtn);
        btnPanel.add(addBtn);
        footer.add(btnPanel, BorderLayout.EAST);

        return footer;
    }

    private void refreshGrid(String category) {
        objectGrid.removeAll();

        java.util.List<ObjectEntry> entries = new ArrayList<>();
        if (category.equals("All")) {
            for (java.util.List<ObjectEntry> list : CATALOG.values()) entries.addAll(list);
        } else {
            entries = CATALOG.getOrDefault(category, new ArrayList<>());
        }

        for (ObjectEntry entry : entries) {
            objectGrid.add(createObjectCard(entry));
        }

        objectGrid.revalidate();
        objectGrid.repaint();
    }

    private JPanel createObjectCard(ObjectEntry entry) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(new Color(50, 50, 50));
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(70, 70, 70)),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        card.setPreferredSize(new Dimension(110, 80));
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Colored dot
        JLabel dot = new JLabel("  " + entry.name);
        dot.setForeground(entry.color);
        dot.setFont(new Font("Monospaced", Font.BOLD, 11));
        dot.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel type = new JLabel(entry.category);
        type.setForeground(TEXT_DIM);
        type.setFont(new Font("Monospaced", Font.PLAIN, 9));
        type.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(Box.createVerticalGlue());
        card.add(dot);
        card.add(Box.createVerticalStrut(4));
        card.add(type);
        card.add(Box.createVerticalGlue());

        card.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                selectEntry(entry, card);
                if (e.getClickCount() == 2) addSelectedObject();
            }
            @Override public void mouseEntered(MouseEvent e) {
                if (selectedEntry != entry) card.setBackground(HOVER);
            }
            @Override public void mouseExited(MouseEvent e) {
                if (selectedEntry != entry) card.setBackground(new Color(50, 50, 50));
            }
        });

        return card;
    }

    private void selectEntry(ObjectEntry entry, JPanel card) {
        // Deselect all cards
        for (Component c : objectGrid.getComponents()) {
            if (c instanceof JPanel) c.setBackground(new Color(50, 50, 50));
        }
        card.setBackground(SELECTED);
        selectedEntry = entry;
        previewName.setText(entry.name);
        previewDesc.setText("- " + entry.description);
        addBtn.setEnabled(true);
    }

    private void addSelectedObject() {
        if (selectedEntry == null) return;

        // Generate unique default name
        int count = nameCounters.getOrDefault(selectedEntry.name, 0) + 1;
        String defaultName = selectedEntry.name + count;

        // Make sure it's unique
        while (hierarchyPanel.nameExists(defaultName)) {
            count++;
            defaultName = selectedEntry.name + count;
        }
        nameCounters.put(selectedEntry.name, count);

        hierarchyPanel.addNewObject(defaultName, selectedEntry.name);
        dispose();
    }

    // Simple data class for object entries
    static class ObjectEntry {
        String name, category, description;
        Color color;
        ObjectEntry(String name, String category, String description, Color color) {
            this.name = name; this.category = category;
            this.description = description; this.color = color;
        }
    }
}
