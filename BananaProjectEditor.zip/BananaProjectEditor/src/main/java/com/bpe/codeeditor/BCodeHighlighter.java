package com.bpe.codeeditor;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.util.regex.*;

public class BCodeHighlighter extends DefaultStyledDocument {

    // Color scheme
    private static final Color COLOR_KEYWORD    = new Color(200, 120, 220);  // purple - script.start, attach, etc
    private static final Color COLOR_NAMESPACE  = new Color(100, 180, 255);  // blue - engine., window., object.
    private static final Color COLOR_EVENT      = new Color(255, 180, 60);   // orange - event:
    private static final Color COLOR_STRING     = new Color(150, 220, 120);  // green - "strings"
    private static final Color COLOR_COMMENT    = new Color(100, 120, 100);  // dark green - -- comments
    private static final Color COLOR_NUMBER     = new Color(220, 160, 80);   // gold - numbers
    private static final Color COLOR_DEFAULT    = new Color(220, 220, 220);  // white - default text
    private static final Color COLOR_END        = new Color(200, 80, 80);    // red - *.end keywords

    private static final SimpleAttributeSet STYLE_KEYWORD   = makeStyle(COLOR_KEYWORD, true);
    private static final SimpleAttributeSet STYLE_NAMESPACE  = makeStyle(COLOR_NAMESPACE, false);
    private static final SimpleAttributeSet STYLE_EVENT     = makeStyle(COLOR_EVENT, false);
    private static final SimpleAttributeSet STYLE_STRING    = makeStyle(COLOR_STRING, false);
    private static final SimpleAttributeSet STYLE_COMMENT   = makeStyle(COLOR_COMMENT, true);
    private static final SimpleAttributeSet STYLE_NUMBER    = makeStyle(COLOR_NUMBER, false);
    private static final SimpleAttributeSet STYLE_DEFAULT   = makeStyle(COLOR_DEFAULT, false);
    private static final SimpleAttributeSet STYLE_END       = makeStyle(COLOR_END, true);

    private static SimpleAttributeSet makeStyle(Color color, boolean italic) {
        SimpleAttributeSet s = new SimpleAttributeSet();
        StyleConstants.setForeground(s, color);
        StyleConstants.setItalic(s, italic);
        return s;
    }

    public BCodeHighlighter() {
        super();
    }

    @Override
    public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
        super.insertString(offs, str, a);
        highlight();
    }

    @Override
    public void remove(int offs, int len) throws BadLocationException {
        super.remove(offs, len);
        highlight();
    }

    private void highlight() {
        SwingUtilities.invokeLater(() -> {
            try {
                String text = getText(0, getLength());
                setCharacterAttributes(0, text.length(), STYLE_DEFAULT, true);

                // Order matters — later rules override earlier ones

                // Comments: -- ...
                applyPattern(text, Pattern.compile("--[^\n]*"), STYLE_COMMENT);

                // Strings: "..."
                applyPattern(text, Pattern.compile("\"[^\"]*\""), STYLE_STRING);

                // Numbers
                applyPattern(text, Pattern.compile("\\b\\d+(\\.\\d+)?\\b"), STYLE_NUMBER);

                // Namespaces: engine., window., object., input., math., audio., scene.
                applyPattern(text, Pattern.compile("\\b(engine|window|object|input|math|audio|scene)\\."), STYLE_NAMESPACE);

                // Events: event: or object.event:
                applyPattern(text, Pattern.compile("(object\\.)?event:"), STYLE_EVENT);

                // *.end keywords
                applyPattern(text, Pattern.compile("\\b(script|event|func)\\.end\\b"), STYLE_END);

                // Keywords
                applyPattern(text, Pattern.compile(
                    "\\b(script\\.start|attach|deattach|end|if|else|elseif|then|local|return|true|false|nil|and|or|not|for|while|do|repeat|until|break|in)\\b"),
                    STYLE_KEYWORD);

            } catch (BadLocationException ignored) {}
        });
    }

    private void applyPattern(String text, Pattern pattern, SimpleAttributeSet style) {
        Matcher m = pattern.matcher(text);
        while (m.find()) {
            setCharacterAttributes(m.start(), m.end() - m.start(), style, false);
        }
    }
}
