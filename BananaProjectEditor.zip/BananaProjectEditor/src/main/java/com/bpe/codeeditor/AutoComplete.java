package com.bpe.codeeditor;

import com.bpe.ui.BPETheme;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

/**
 * Autocomplete popup for the BCode text editor.
 * Triggers when the user types and shows matching completions.
 * Press Tab/Enter to insert, Escape to dismiss.
 */
public class AutoComplete {

    // ── completion entries ────────────────────────────────────────────────────
    static class Entry {
        String trigger;   // what to match against
        String insert;    // text to insert (replaces the typed prefix)
        String display;   // shown in list
        String doc;       // short description shown on right
        String category;

        Entry(String trigger, String insert, String display, String doc, String category) {
            this.trigger = trigger; this.insert = insert;
            this.display = display; this.doc = doc; this.category = category;
        }
    }

    static final List<Entry> ENTRIES = new ArrayList<>();
    static {
        // object.*
        add("object.SetPosition",  "object.SetPosition(0, 0);",           "SetPosition(x, y)",     "Set object position",           "object");
        add("object.GetPosition",  "local x, y = object.GetPosition();",  "GetPosition() → x, y",  "Get current position",          "object");
        add("object.SetSize",      "object.SetSize(100, 100);",            "SetSize(w, h)",          "Set width and height",          "object");
        add("object.SetRotation",  "object.SetRotation(0);",               "SetRotation(deg)",       "Set rotation in degrees",       "object");
        add("object.Show",         "object.Show(1);",                      "Show(opacity)",          "Show with opacity 0–1",         "object");
        add("object.Hide",         "object.Hide();",                       "Hide()",                 "Make invisible",                "object");
        add("object.SetText",      "object.SetText(\"text\");",            "SetText(text)",          "Set label/button text",         "object");
        add("object.GetText",      "local t = object.GetText();",          "GetText() → string",     "Get current text",              "object");
        add("object.Clone",        "object.Clone();",                      "Clone()",                "Duplicate this object",         "object");
        add("object.Destroy",      "object.Destroy();",                    "Destroy()",              "Remove this object",            "object");
        add("object.KeyDown",      "object.KeyDown(\"W\")",                "KeyDown(key) → bool",    "Is key held down?",             "object");
        add("object.KeyPressed",   "object.KeyPressed(\"Space\")",         "KeyPressed(key) → bool", "Was key just pressed?",         "object");
        add("object.KeyReleased",  "object.KeyReleased(\"W\")",            "KeyReleased(key) → bool","Was key just released?",        "object");
        add("object.MouseDown",    "object.MouseDown()",                   "MouseDown() → bool",     "Is mouse button held?",         "object");
        add("object.MouseClicked", "object.MouseClicked()",                "MouseClicked() → bool",  "Mouse just clicked?",           "object");
        // engine.*
        add("engine.log",          "engine.log(\"\");",                    "log(msg)",               "Print to console",              "engine");
        add("engine.warn",         "engine.warn(\"\");",                   "warn(msg)",              "Print warning",                 "engine");
        add("engine.error",        "engine.error(\"\");",                  "error(msg)",             "Print error",                   "engine");
        add("engine.Quit",         "engine.Quit();",                       "Quit()",                 "Exit the game",                 "engine");
        add("engine.LoadScene",    "engine.LoadScene(\"\");",              "LoadScene(name)",        "Load a scene by name",          "engine");
        add("engine.SceneReload",  "engine.SceneReload();",                "SceneReload()",          "Reload current scene",          "engine");
        // window.*
        add("window.SetTitle",     "window.SetTitle(\"\");",               "SetTitle(text)",         "Set window title",              "window");
        add("window.GetFPS",       "local fps = window.GetFPS();",         "GetFPS() → number",      "Current frames per second",     "window");
        add("window.GetDeltaTime", "local dt = window.GetDeltaTime();",    "GetDeltaTime() → number","Time since last frame",         "window");
        add("window.SetSize",      "window.SetSize(800, 600);",            "SetSize(w, h)",          "Resize the game window",        "window");
        // sound.*
        add("sound.Play",          "sound.Play(\"\");",                    "Play(name)",             "Play a sound by name",          "sound");
        // time.*
        add("time.GetTime",        "local t = time.GetTime();",            "GetTime() → number",     "Seconds since game start",      "time");
        // math.*
        add("math.Sin",            "math.Sin(0)",                          "Sin(deg) → number",      "Sine (degrees)",                "math");
        add("math.Cos",            "math.Cos(0)",                          "Cos(deg) → number",      "Cosine (degrees)",              "math");
        add("math.Abs",            "math.Abs(x)",                          "Abs(x) → number",        "Absolute value",                "math");
        add("math.Floor",          "math.Floor(x)",                        "Floor(x) → number",      "Round down",                    "math");
        add("math.Ceil",           "math.Ceil(x)",                         "Ceil(x) → number",       "Round up",                      "math");
        add("math.Sqrt",           "math.Sqrt(x)",                         "Sqrt(x) → number",       "Square root",                   "math");
        add("math.Pow",            "math.Pow(x, 2)",                       "Pow(x, exp) → number",   "x to the power",                "math");
        add("math.Random",         "math.Random(0, 100)",                  "Random(min, max)",        "Random number in range",        "math");
        add("math.Clamp",          "math.Clamp(x, 0, 1)",                  "Clamp(x, min, max)",     "Clamp between min and max",     "math");
        // events / structure
        add("event:onStart",       "event:onStart()\n    \nevent.end",     "event:onStart()",        "Runs once on game start",       "event");
        add("event:onUpdate",      "event:onUpdate()\n    \nevent.end",    "event:onUpdate()",       "Runs every frame",              "event");
        add("event:onDestroy",     "event:onDestroy()\n    \nevent.end",   "event:onDestroy()",      "Runs when destroyed",           "event");
        add("event:onCollide",     "event:onCollide(other)\n    \nevent.end","event:onCollide(other)","Collision event",             "event");
        add("object.event:OnClick","object.event:OnClick()\n    \nevent.end","object.event:OnClick()","Click event",                "event");
        add("attach",              "attach \"Object\";",                   "attach \"name\"",        "Attach to object",              "script");
        add("deattach",            "deattach;",                            "deattach",               "Detach current object",         "script");
        add("script.start",        "script.start",                        "script.start",           "Script entry point",            "script");
        add("script.end",          "script.end",                          "script.end",             "Script end",                    "script");
        add("local",               "local name = value;",                  "local name = value",     "Declare variable",              "var");
        add("if",                  "if (condition) =\n    ]\n",            "if (condition) = ...]",  "If block",                      "control");
        add("forever",             "forever =\n    ]",                     "forever = ...]",         "Repeat forever (each frame)",   "control");
    }

    private static void add(String t, String ins, String disp, String doc, String cat) {
        ENTRIES.add(new Entry(t, ins, disp, doc, cat));
    }

    // ── category colours ──────────────────────────────────────────────────────
    static Color catColor(String cat) {
        switch (cat) {
            case "object":  return new Color(220, 80, 80);
            case "engine":  return new Color(160, 60, 200);
            case "window":  return new Color(120, 120, 220);
            case "sound":   return new Color(80, 220, 140);
            case "time":    return new Color(80, 200, 220);
            case "math":    return new Color(60, 180, 180);
            case "event":   return new Color(200, 120, 30);
            case "control": return new Color(200, 160, 20);
            case "script":  return new Color(100, 180, 100);
            default:        return BPETheme.TEXT_DIM;
        }
    }

    // ── popup ─────────────────────────────────────────────────────────────────
    private final JTextPane editor;
    private final JWindow   popup;
    private final JList<Entry> list;
    private final DefaultListModel<Entry> model;
    private boolean active = false;

    public AutoComplete(JTextPane editor) {
        this.editor = editor;

        model = new DefaultListModel<>();
        list  = new JList<>(model);
        list.setBackground(BPETheme.BG_RAISED);
        list.setForeground(BPETheme.TEXT_PRIMARY);
        list.setFont(BPETheme.FONT_MONO_SMALL);
        list.setSelectionBackground(BPETheme.BG_SELECTED);
        list.setSelectionForeground(Color.WHITE);
        list.setFixedCellHeight(22);
        list.setCellRenderer(new EntryCellRenderer());

        list.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) insertSelected();
            }
        });

        JScrollPane scroll = new JScrollPane(list);
        scroll.setBorder(BorderFactory.createLineBorder(BPETheme.ACCENT, 1));
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        popup = new JWindow();
        popup.setContentPane(scroll);
        popup.setSize(320, 180);
        popup.setFocusableWindowState(false);

        // Hook into editor
        editor.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { SwingUtilities.invokeLater(() -> trigger()); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { SwingUtilities.invokeLater(() -> trigger()); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) {}
        });

        editor.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (!active) return;
                if (e.getKeyCode() == KeyEvent.VK_ESCAPE) { hide(); e.consume(); }
                else if (e.getKeyCode() == KeyEvent.VK_TAB || e.getKeyCode() == KeyEvent.VK_ENTER) {
                    if (list.getSelectedIndex() >= 0) { insertSelected(); e.consume(); }
                }
                else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    int next = Math.min(list.getSelectedIndex()+1, model.size()-1);
                    list.setSelectedIndex(next); list.ensureIndexIsVisible(next); e.consume();
                }
                else if (e.getKeyCode() == KeyEvent.VK_UP) {
                    int prev = Math.max(list.getSelectedIndex()-1, 0);
                    list.setSelectedIndex(prev); list.ensureIndexIsVisible(prev); e.consume();
                }
            }
        });

        editor.addFocusListener(new FocusAdapter() {
            @Override public void focusLost(FocusEvent e) { hide(); }
        });
    }

    private void trigger() {
        String prefix = getCurrentPrefix();
        if (prefix.length() < 2) { hide(); return; }

        model.clear();
        for (Entry e : ENTRIES)
            if (e.trigger.toLowerCase().startsWith(prefix.toLowerCase())) model.addElement(e);

        if (model.isEmpty()) { hide(); return; }

        list.setSelectedIndex(0);
        positionPopup();
        popup.setVisible(true);
        active = true;
    }

    private String getCurrentPrefix() {
        try {
            int pos = editor.getCaretPosition();
            Document doc = editor.getDocument();
            int lineStart = pos;
            String text = doc.getText(0, pos);
            // Find start of current word (back to whitespace or newline)
            while (lineStart > 0 && !Character.isWhitespace(text.charAt(lineStart-1))) lineStart--;
            return text.substring(lineStart, pos);
        } catch (Exception e) { return ""; }
    }

    private void insertSelected() {
        Entry e = list.getSelectedValue();
        if (e == null) return;
        try {
            String prefix = getCurrentPrefix();
            int pos = editor.getCaretPosition();
            editor.getDocument().remove(pos - prefix.length(), prefix.length());
            editor.getDocument().insertString(editor.getCaretPosition(), e.insert, null);
        } catch (Exception ex) { ex.printStackTrace(); }
        hide();
    }

    private void positionPopup() {
        try {
            Rectangle r = editor.modelToView(editor.getCaretPosition());
            Point p = editor.getLocationOnScreen();
            popup.setLocation(p.x + r.x, p.y + r.y + r.height + 2);
        } catch (Exception ignored) {}
    }

    public void hide() {
        popup.setVisible(false);
        active = false;
    }

    // ── cell renderer ─────────────────────────────────────────────────────────
    class EntryCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value,
                int index, boolean selected, boolean focused) {
            Entry e = (Entry) value;
            JPanel row = new JPanel(new BorderLayout(4, 0));
            row.setBackground(selected ? BPETheme.BG_SELECTED : BPETheme.BG_RAISED);
            row.setBorder(BorderFactory.createEmptyBorder(2, 6, 2, 6));

            // Category badge
            JLabel badge = new JLabel(e.category);
            badge.setFont(new Font("Consolas", Font.BOLD, 8));
            badge.setForeground(catColor(e.category));
            badge.setPreferredSize(new Dimension(44, 16));

            // Display name
            JLabel name = new JLabel(e.display);
            name.setFont(BPETheme.FONT_MONO_SMALL);
            name.setForeground(selected ? Color.WHITE : BPETheme.TEXT_PRIMARY);

            // Doc hint
            JLabel doc = new JLabel(e.doc + "  ");
            doc.setFont(new Font("Consolas", Font.ITALIC, 9));
            doc.setForeground(BPETheme.TEXT_DIM);

            row.add(badge, BorderLayout.WEST);
            row.add(name,  BorderLayout.CENTER);
            row.add(doc,   BorderLayout.EAST);
            return row;
        }
    }
}
