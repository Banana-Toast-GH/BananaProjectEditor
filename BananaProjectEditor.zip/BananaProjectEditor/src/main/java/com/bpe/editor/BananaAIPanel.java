package com.bpe.editor;

import com.bpe.ui.BPETheme;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import javax.sound.sampled.*;

/**
 * BananaAI Panel — Messenger-style UI
 *
 * Features:
 * - Rounded chat bubbles (user = right/gold, AI = left/dark)
 * - Synthesized sound effects (send, receive, error)
 * - Toast popup notifications (top-right layered pane)
 * - Animated typing indicator bubble in chat
 * - Compact pill mode toggle (Ask | Agent)
 * - Token pills in header
 * - Typewriter response effect
 * - Insert BCode button
 */
public class BananaAIPanel extends JPanel {

    // ── Config ────────────────────────────────────────────────────────────────
    private static final String SERVER_URL  = "https://arguments-planets-achieve-educators.trycloudflare.com";
    private static final int SLEEP_START_H  = 20, SLEEP_START_M = 30;
    private static final int SLEEP_END_H    = 5,  SLEEP_END_M   = 20;
    private static final DateTimeFormatter TIMEFMT = DateTimeFormatter.ofPattern("h:mm a");

    // ── Palette ───────────────────────────────────────────────────────────────
    private static final Color BG         = new Color(13, 13, 17);
    private static final Color BG_PANEL   = new Color(20, 20, 26);
    private static final Color BG_INPUT   = new Color(25, 25, 32);
    private static final Color BUBBLE_AI  = new Color(30, 30, 40);
    private static final Color BUBBLE_USR = new Color(160, 115, 0);
    private static final Color BUBBLE_ERR = new Color(55, 15, 15);
    private static final Color BUBBLE_SYS = new Color(18, 38, 18);
    private static final Color ACCENT     = BPETheme.ACCENT;
    private static final Color ACCENT_DIM = new Color(140, 100, 0);
    private static final Color TEXT       = new Color(228, 228, 236);
    private static final Color TEXT_DIM   = new Color(120, 120, 136);
    private static final Color TEXT_MUTED = new Color(65, 65, 80);
    private static final Color GREEN      = new Color(55, 195, 90);
    private static final Color RED        = new Color(215, 60, 60);
    private static final Color ORANGE     = new Color(215, 135, 35);
    private static final Color BORDER     = new Color(38, 38, 50);

    // ── State ─────────────────────────────────────────────────────────────────
    private String  userId      = null;   // PlayFab internal ID (e.g. "A1B2C3D4")
    private String  username    = null;   // display username
    private String  displayName = null;
    private String  sessionKey  = null;
    private String  sessionId   = null;
    private String  lastBCode   = null;
    private String  currentMode = "ask";
    private int     genTokens   = -1;
    private int     crtTokens   = -1;
    private String  userPlan    = "free";
    private String  tokenResetDate = null;
    private boolean isBusy      = false;

    // ── UI ────────────────────────────────────────────────────────────────────
    private JPanel   msgPanel;       // scrollable message container
    private JScrollPane chatScroll;
    private JTextArea   inputArea;
    private JButton     sendBtn;
    private JButton     insertBtn;
    private JLabel      statusDot;
    private JLabel      statusText;
    private JLabel      genPill;
    private JLabel      crtPill;
    private JPanel      typingBubble; // animated "..." bubble
    private JLabel[]    typingDots   = new JLabel[3];
    private Timer       dotTimer;
    private int         dotFrame     = 0;
    private JPanel      tokenWarnBar;
    private JLabel      tokenWarnLbl;
    private JLabel      modeAsk;
    private JLabel      modeAgent;

    private final EditorFrame editorFrame;

    // ═══════════════════════════════════════════════════════════════════════════
    public BananaAIPanel(EditorFrame frame) {
        this.editorFrame = frame;
        setLayout(new BorderLayout());
        setBackground(BG);
        setPreferredSize(new Dimension(0, 270));
        setMinimumSize(new Dimension(0, 190));

        userId      = SplashAuthScreen.getCachedPlayFabId();   // real PlayFab ID
        username    = PlayFabAuthDialog.getCachedUsername();    // human-readable name
        displayName = PlayFabAuthDialog.getCachedDisplayName();
        sessionKey  = PlayFabAuthDialog.getCachedSessionKey();

        // Fallback: if PlayFabId not yet stored (old install), use username
        if (userId == null) userId = username;

        if (userId != null) showMainUI();
        else                showAuthUI();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // AUTH WALL
    // ═══════════════════════════════════════════════════════════════════════════
    private void showAuthUI() {
        removeAll();
        JPanel bg = new JPanel(new GridBagLayout());
        bg.setBackground(BG);

        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_PANEL);
                g2.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.setColor(BORDER);
                g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
                g2.dispose();
            }
        };
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(28, 34, 28, 34));

        JLabel icon = new JLabel(new ImageIcon(makeBananaIcon(40)));
        icon.setAlignmentX(CENTER_ALIGNMENT);

        JLabel title = new JLabel("BananaAI");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(ACCENT);
        title.setAlignmentX(CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Sign in to start chatting");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub.setForeground(TEXT_DIM);
        sub.setAlignmentX(CENTER_ALIGNMENT);

        JButton btn = makePillButton("Sign In / Create Account", ACCENT, new Color(13,13,17));
        btn.setAlignmentX(CENTER_ALIGNMENT);
        btn.addActionListener(e -> {
            Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
            PlayFabAuthDialog dlg = new PlayFabAuthDialog(owner);
            dlg.setVisible(true);
            if (dlg.isSuccess()) {
                userId      = dlg.getCachedPlayFabId();
                if (userId == null) userId = dlg.getResultUsername(); // fallback
                username    = dlg.getResultUsername();
                displayName = dlg.getResultDisplayName();
                sessionKey  = dlg.getResultSessionKey();
                showMainUI();
                revalidate(); repaint();
            }
        });

        card.add(icon);
        card.add(Box.createVerticalStrut(10));
        card.add(title);
        card.add(Box.createVerticalStrut(5));
        card.add(sub);
        card.add(Box.createVerticalStrut(22));
        card.add(btn);

        bg.add(card);
        add(bg, BorderLayout.CENTER);
        revalidate(); repaint();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // MAIN UI
    // ═══════════════════════════════════════════════════════════════════════════
    private void showMainUI() {
        removeAll();
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        root.add(buildHeader(),    BorderLayout.NORTH);
        root.add(buildChatArea(),  BorderLayout.CENTER);
        root.add(buildInputArea(), BorderLayout.SOUTH);
        add(root, BorderLayout.CENTER);
        revalidate(); repaint();

        checkStatus();
        fetchTokens();

        String name = displayName != null ? displayName : (username != null ? username : "there");
        postAIBubble("Hey " + name + "! 👋 I'm BananaAI — ask me anything about BCode, or switch to Agent mode to create and edit scripts in your project.", false);
    }

    // ── Header ────────────────────────────────────────────────────────────────
    private JPanel buildHeader() {
        JPanel h = new JPanel(new BorderLayout());
        h.setBackground(BG_PANEL);
        h.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0,0,1,0, BORDER),
            BorderFactory.createEmptyBorder(7, 12, 7, 12)
        ));

        // LEFT — avatar + name + status
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        left.setOpaque(false);

        JLabel av = new JLabel(new ImageIcon(makeBananaIcon(24)));
        left.add(av);

        JPanel nameCol = new JPanel();
        nameCol.setLayout(new BoxLayout(nameCol, BoxLayout.Y_AXIS));
        nameCol.setOpaque(false);

        JLabel nameLbl = new JLabel("BananaAI");
        nameLbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        nameLbl.setForeground(ACCENT);

        JPanel statusRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
        statusRow.setOpaque(false);
        statusDot  = new JLabel("●");
        statusDot.setFont(new Font("Segoe UI", Font.PLAIN, 8));
        statusDot.setForeground(TEXT_MUTED);
        statusText = new JLabel("connecting...");
        statusText.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        statusText.setForeground(TEXT_MUTED);
        statusRow.add(statusDot);
        statusRow.add(statusText);

        nameCol.add(nameLbl);
        nameCol.add(statusRow);
        left.add(nameCol);

        // RIGHT — token pills + mode toggle + user chip + sign-out
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        right.setOpaque(false);

        genPill = makePill("-- gen", new Color(36,32,10));
        crtPill = makePill("-- crt", new Color(14,24,42));

        JPanel modeToggle = buildModeToggle();

        String uname = displayName != null ? displayName : (username != null ? username : userId);
        JLabel userChip = makePill(uname, new Color(28,28,36));
        userChip.setForeground(TEXT_DIM);

        JLabel signOut = new JLabel("Sign Out");
        signOut.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        signOut.setForeground(TEXT_MUTED);
        signOut.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        signOut.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                PlayFabAuthDialog.clearCache();
                userId = null; username = null; displayName = null; sessionKey = null;
                showAuthUI();
            }
            public void mouseEntered(MouseEvent e) { signOut.setForeground(RED); }
            public void mouseExited(MouseEvent e)  { signOut.setForeground(TEXT_MUTED); }
        });

        right.add(genPill);
        right.add(crtPill);
        right.add(modeToggle);
        right.add(userChip);
        right.add(signOut);

        h.add(left,  BorderLayout.WEST);
        h.add(right, BorderLayout.EAST);
        return h;
    }

    // ── Mode toggle pill ──────────────────────────────────────────────────────
    private JPanel buildModeToggle() {
        JPanel p = new JPanel(new GridLayout(1, 2, 0, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG);
                g2.fillRoundRect(0,0,getWidth()-1,getHeight()-1,999,999);
                g2.setColor(BORDER);
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,999,999);
                g2.dispose();
            }
        };
        p.setOpaque(false);

        modeAsk   = makeModeTab("Ask",   true);
        modeAgent = makeModeTab("Agent", false);

        modeAsk.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { selectMode("ask"); }
        });
        modeAgent.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { selectMode("agent"); }
        });

        p.add(modeAsk);
        p.add(modeAgent);
        return p;
    }

    private JLabel makeModeTab(String text, boolean active) {
        JLabel l = new JLabel(text, SwingConstants.CENTER) {
            @Override protected void paintComponent(Graphics g) {
                boolean sel = currentMode.equals(getText().toLowerCase());
                if (sel) {
                    Graphics2D g2 = (Graphics2D)g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(ACCENT);
                    g2.fillRoundRect(1,1,getWidth()-2,getHeight()-2,999,999);
                    g2.dispose();
                }
                super.paintComponent(g);
            }
        };
        l.setFont(new Font("Segoe UI", Font.BOLD, 10));
        l.setForeground(active ? new Color(13,13,17) : TEXT_DIM);
        l.setBorder(BorderFactory.createEmptyBorder(3, 12, 3, 12));
        l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        l.setOpaque(false);
        return l;
    }

    private void selectMode(String mode) {
        currentMode = mode;
        modeAsk.setForeground(mode.equals("ask")   ? new Color(13,13,17) : TEXT_DIM);
        modeAgent.setForeground(mode.equals("agent") ? new Color(13,13,17) : TEXT_DIM);
        modeAsk.repaint();
        modeAgent.repaint();
        updateTokenWarn();
    }

    // ── Chat scrollable area ──────────────────────────────────────────────────
    private JScrollPane buildChatArea() {
        msgPanel = new JPanel();
        msgPanel.setLayout(new BoxLayout(msgPanel, BoxLayout.Y_AXIS));
        msgPanel.setBackground(BG);
        msgPanel.setBorder(BorderFactory.createEmptyBorder(10, 8, 10, 8));

        // Typing bubble — added/removed dynamically
        typingBubble = buildTypingBubble();
        typingBubble.setVisible(false);

        chatScroll = new JScrollPane(msgPanel);
        chatScroll.setBorder(BorderFactory.createEmptyBorder());
        chatScroll.setBackground(BG);
        chatScroll.getViewport().setBackground(BG);
        chatScroll.getVerticalScrollBar().setUnitIncrement(14);
        return chatScroll;
    }

    // ── Input area ────────────────────────────────────────────────────────────
    private JPanel buildInputArea() {
        JPanel area = new JPanel(new BorderLayout());
        area.setBackground(BG_PANEL);
        area.setBorder(BorderFactory.createMatteBorder(1,0,0,0, BORDER));

        // Token warning bar
        tokenWarnBar = new JPanel(new BorderLayout());
        tokenWarnBar.setBackground(new Color(48,14,14));
        tokenWarnBar.setBorder(BorderFactory.createEmptyBorder(5,12,5,12));
        tokenWarnLbl = new JLabel(" ");
        tokenWarnLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        tokenWarnLbl.setForeground(new Color(255,120,120));
        tokenWarnBar.add(tokenWarnLbl);
        tokenWarnBar.setVisible(false);

        // Insert BCode button
        insertBtn = new JButton("⬆  Insert BCode into Editor") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? new Color(25,55,25) : new Color(18,42,18));
                g2.fillRoundRect(0,0,getWidth()-1,getHeight()-1,8,8);
                g2.setColor(GREEN);
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,8,8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        insertBtn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        insertBtn.setForeground(GREEN);
        insertBtn.setContentAreaFilled(false);
        insertBtn.setBorderPainted(false);
        insertBtn.setFocusPainted(false);
        insertBtn.setOpaque(false);
        insertBtn.setBorder(BorderFactory.createEmptyBorder(4,12,4,12));
        insertBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        insertBtn.setVisible(false);
        insertBtn.addActionListener(e -> insertBCode());

        JPanel insertRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3));
        insertRow.setBackground(BG_PANEL);
        insertRow.add(insertBtn);

        // Text input + send
        JPanel inputRow = new JPanel(new BorderLayout(8, 0));
        inputRow.setBackground(BG_INPUT);
        inputRow.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));

        inputArea = new JTextArea(2, 0);
        inputArea.setBackground(new Color(30,30,40));
        inputArea.setForeground(TEXT);
        inputArea.setCaretColor(ACCENT);
        inputArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        inputArea.setLineWrap(true);
        inputArea.setWrapStyleWord(true);
        inputArea.setBorder(BorderFactory.createCompoundBorder(
            new RoundLineBorder(BORDER, 10),
            BorderFactory.createEmptyBorder(6,10,6,10)
        ));
        inputArea.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && !e.isShiftDown()) {
                    e.consume();
                    sendMessage();
                }
            }
        });

        // Round send button
        sendBtn = new JButton("▶") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color c = !isEnabled() ? TEXT_MUTED
                        : getModel().isRollover() ? ACCENT.brighter() : ACCENT;
                g2.setColor(c);
                g2.fillOval(0,0,getWidth()-1,getHeight()-1);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        sendBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        sendBtn.setForeground(new Color(13,13,17));
        sendBtn.setPreferredSize(new Dimension(36,36));
        sendBtn.setContentAreaFilled(false);
        sendBtn.setBorderPainted(false);
        sendBtn.setFocusPainted(false);
        sendBtn.setOpaque(false);
        sendBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        sendBtn.addActionListener(e -> sendMessage());

        JScrollPane inputScroll = new JScrollPane(inputArea);
        inputScroll.setBorder(BorderFactory.createEmptyBorder());
        inputScroll.setBackground(new Color(30,30,40));
        inputScroll.getViewport().setBackground(new Color(30,30,40));

        inputRow.add(inputScroll, BorderLayout.CENTER);
        inputRow.add(sendBtn,     BorderLayout.EAST);

        area.add(tokenWarnBar, BorderLayout.NORTH);
        area.add(insertRow,    BorderLayout.CENTER);
        area.add(inputRow,     BorderLayout.SOUTH);
        return area;
    }

    // ── Typing bubble ─────────────────────────────────────────────────────────
    private JPanel buildTypingBubble() {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        row.setOpaque(false);
        row.setAlignmentX(LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));

        JLabel av = new JLabel(new ImageIcon(makeBananaIcon(20)));
        row.add(av);

        JPanel bubble = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 7)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BUBBLE_AI);
                g2.fillRoundRect(0,0,getWidth()-1,getHeight()-1,16,16);
                // Square off bottom-left corner
                g2.fillRect(0, getHeight()-9, 8, 9);
                g2.dispose();
            }
        };
        bubble.setOpaque(false);

        for (int i = 0; i < 3; i++) {
            JLabel d = new JLabel("●");
            d.setFont(new Font("Segoe UI", Font.PLAIN, 9));
            d.setForeground(TEXT_MUTED);
            typingDots[i] = d;
            bubble.add(d);
        }

        dotTimer = new Timer(380, e -> {
            dotFrame = (dotFrame + 1) % 3;
            for (int i = 0; i < 3; i++)
                typingDots[i].setForeground(i == dotFrame ? ACCENT : TEXT_MUTED);
        });

        row.add(bubble);
        return row;
    }

    private void showTyping() {
        if (typingBubble.getParent() != msgPanel) msgPanel.add(typingBubble);
        typingBubble.setVisible(true);
        dotTimer.start();
        msgPanel.revalidate(); msgPanel.repaint();
        scrollBottom();
    }

    private void hideTyping() {
        dotTimer.stop();
        typingBubble.setVisible(false);
        msgPanel.remove(typingBubble);
        msgPanel.revalidate(); msgPanel.repaint();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BUBBLE FACTORIES
    // ═══════════════════════════════════════════════════════════════════════════

    /** AI message — left aligned with banana avatar */
    private void postAIBubble(String text, boolean typewriter) {
        String time = LocalTime.now().format(TIMEFMT);

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        row.setOpaque(false);
        row.setAlignmentX(LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        JLabel av = new JLabel(new ImageIcon(makeBananaIcon(22)));
        av.setVerticalAlignment(SwingConstants.BOTTOM);
        av.setAlignmentY(BOTTOM_ALIGNMENT);

        JPanel col = new JPanel();
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        col.setOpaque(false);
        col.setAlignmentY(BOTTOM_ALIGNMENT);

        JLabel nameLbl = new JLabel("BananaAI  " + time);
        nameLbl.setFont(new Font("Segoe UI", Font.BOLD, 10));
        nameLbl.setForeground(ACCENT_DIM);
        nameLbl.setBorder(BorderFactory.createEmptyBorder(0, 4, 2, 0));

        JTextArea ta = makeMsgText(typewriter ? " " : text, TEXT, 400);

        JPanel bubble = new Bubble(BUBBLE_AI, false);
        bubble.add(ta, BorderLayout.CENTER);

        col.add(nameLbl);
        col.add(bubble);

        row.add(av);
        row.add(col);

        addRow(row);

        if (typewriter) {
            // Use StringBuilder to avoid O(n²) string concat on long responses
            StringBuilder built = new StringBuilder();
            char[] chars = text.toCharArray();
            int[] idx = {0};
            Timer[] t = {null};
            t[0] = new Timer(8, e -> {
                try {
                    int batch = Math.min(12, chars.length - idx[0]);
                    built.append(chars, idx[0], batch);
                    idx[0] += batch;
                    ta.setText(built.toString());
                    scrollBottom();
                } catch (Exception ignored) {}

                if (idx[0] >= chars.length) {
                    t[0].stop();
                    isBusy = false;
                    sendBtn.setEnabled(true);
                    inputArea.setEnabled(true);
                    inputArea.requestFocus();
                }
            });
            t[0].start();
        }
    }

    /** User message — right aligned, gold bubble */
    private void postUserBubble(String text) {
        String time = LocalTime.now().format(TIMEFMT);

        JPanel row = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 2));
        row.setOpaque(false);
        row.setAlignmentX(LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        JPanel col = new JPanel();
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        col.setOpaque(false);

        JLabel timeLbl = new JLabel(time);
        timeLbl.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        timeLbl.setForeground(TEXT_MUTED);
        timeLbl.setAlignmentX(RIGHT_ALIGNMENT);
        timeLbl.setBorder(BorderFactory.createEmptyBorder(0,0,2,4));

        JTextArea ta = makeMsgText(text, new Color(13,13,17), 360);
        JPanel bubble = new Bubble(BUBBLE_USR, true);
        bubble.setAlignmentX(RIGHT_ALIGNMENT);
        bubble.add(ta, BorderLayout.CENTER);

        col.add(timeLbl);
        col.add(bubble);

        row.add(col);
        addRow(row);
    }

    /** Small centred system pill */
    private void postSystemPill(String text) {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 3));
        row.setOpaque(false);
        row.setAlignmentX(LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));

        JLabel lbl = new JLabel(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BUBBLE_SYS);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),999,999);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lbl.setForeground(GREEN);
        lbl.setBorder(BorderFactory.createEmptyBorder(3,12,3,12));
        lbl.setOpaque(false);

        row.add(lbl);
        addRow(row);
    }

    /** Error bubble — red, left aligned */
    private void postErrorBubble(String text) {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        row.setOpaque(false);
        row.setAlignmentX(LEFT_ALIGNMENT);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        JTextArea ta = makeMsgText("⚠  " + text, RED, 380);
        JPanel bubble = new Bubble(BUBBLE_ERR, false);
        bubble.add(ta, BorderLayout.CENTER);
        row.add(bubble);
        addRow(row);
        playSoundError();
    }

    private void addRow(JComponent row) {
        // Insert before typing bubble if present
        boolean hadTyping = typingBubble.isVisible();
        if (hadTyping) msgPanel.remove(typingBubble);
        msgPanel.add(row);
        msgPanel.add(Box.createVerticalStrut(3));
        if (hadTyping) msgPanel.add(typingBubble);
        msgPanel.revalidate(); msgPanel.repaint();
        scrollBottom();
    }

    private JTextArea makeMsgText(String text, Color fg, int maxWidth) {
        JTextArea ta = new JTextArea(text);
        ta.setEditable(false);
        ta.setOpaque(false);
        ta.setForeground(fg);
        ta.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setBorder(null);
        ta.setMaximumSize(new Dimension(maxWidth, Integer.MAX_VALUE));
        return ta;
    }

    private void scrollBottom() {
        SwingUtilities.invokeLater(() -> {
            JScrollBar sb = chatScroll.getVerticalScrollBar();
            sb.setValue(sb.getMaximum());
        });
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SEND MESSAGE
    // ═══════════════════════════════════════════════════════════════════════════
    private void sendMessage() {
        if (userId == null) { showAuthUI(); return; }
        String text = inputArea.getText().trim();
        if (text.isEmpty() || isBusy) return;

        if (isAISleeping()) {
            postErrorBubble("BananaAI is in sleep mode right now. Come back after 5:20 AM CST. Error Code: Sleep");
            showToast("😴 BananaAI is sleeping", ORANGE);
            return;
        }
        if (currentMode.equals("ask") && genTokens == 0) { showTokenWarn(); return; }
        if (currentMode.equals("agent") && crtTokens == 0) { showTokenWarn(); return; }

        inputArea.setText("");
        sendBtn.setEnabled(false);
        inputArea.setEnabled(false);
        insertBtn.setVisible(false);
        tokenWarnBar.setVisible(false);
        isBusy = true;

        postUserBubble(text);
        playSoundSend();
        showTyping();

        new Thread(() -> {
            try {
                String ctx = "";
                if (currentMode.equals("agent") && editorFrame != null) {
                    SwingUtilities.invokeLater(() -> showToast("📂 Reading workspace...", ACCENT_DIM));
                    ctx = buildWorkspaceContext();
                    Thread.sleep(400);
                }

                String fullMsg = ctx.isEmpty() ? text : ctx + "\n\nUser request: " + text;
                String payload = buildJson(fullMsg, currentMode);

                HttpURLConnection conn = openConn("/api/chat", 300000);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(payload.getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                InputStream is = code == 200 ? conn.getInputStream() : conn.getErrorStream();
                String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);

                SwingUtilities.invokeLater(() -> {
                    hideTyping();
                    if (code == 200) {
                        String aiText  = extractJson(body, "response");
                        sessionId      = extractJson(body, "session_id");
                        if (aiText != null) {
                            postAIBubble(aiText, true);
                            playSoundReceive();
                            showToast("💬 BananaAI replied", ACCENT_DIM);
                            String bcode = extractBCode(aiText);
                            if (bcode != null) { lastBCode = bcode; insertBtn.setVisible(true); }
                            String cmds = extractJsonArray(body, "commands");
                            if (cmds != null && !cmds.equals("[]")) executeCommands(cmds, body);
                            fetchTokens();
                        }
                    } else if (code == 403) {
                        String errCode = extractJson(body, "code");
                        if ("Authorize".equals(errCode)) {
                            postErrorBubble("Authorization failed. Error Code: Authorize");
                            showToast("🔒 Not authorized", RED);
                        } else {
                            postErrorBubble("Out of tokens. Wait for your next reset.");
                            showToast("🎫 Out of tokens", ORANGE);
                            showTokenWarn();
                        }
                        isBusy = false; sendBtn.setEnabled(true); inputArea.setEnabled(true);
                    } else if (code == 503) {
                        postErrorBubble("Server overloaded — try again. Error Code: Memory");
                        showToast("⚠ Server overloaded", ORANGE);
                        isBusy = false; sendBtn.setEnabled(true); inputArea.setEnabled(true);
                    } else {
                        postErrorBubble("HTTP " + code + " error. Error Code: HTTP");
                        showToast("⚠ Server error " + code, RED);
                        isBusy = false; sendBtn.setEnabled(true); inputArea.setEnabled(true);
                    }
                });

            } catch (ConnectException ex) {
                SwingUtilities.invokeLater(() -> {
                    hideTyping();
                    postErrorBubble("Can't reach BananaAI server. Error Code: Connection");
                    showToast("🔌 Server unreachable", RED);
                    isBusy = false; sendBtn.setEnabled(true); inputArea.setEnabled(true);
                });
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    hideTyping();
                    postErrorBubble("Unexpected error: " + ex.getMessage() + ". Error Code: Unknown");
                    showToast("⚠ Unknown error", RED);
                    isBusy = false; sendBtn.setEnabled(true); inputArea.setEnabled(true);
                });
            }
        }).start();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // TOAST NOTIFICATIONS
    // ═══════════════════════════════════════════════════════════════════════════
    private void showToast(String msg, Color accent) {
        Window win = SwingUtilities.getWindowAncestor(this);
        if (win == null) return;
        JLayeredPane lp = win instanceof JFrame   ? ((JFrame)win).getLayeredPane()
                        : win instanceof JDialog  ? ((JDialog)win).getLayeredPane() : null;
        if (lp == null) return;

        JPanel toast = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(22,22,30));
                g2.fillRoundRect(0,0,getWidth()-1,getHeight()-1,12,12);
                g2.setColor(accent);
                g2.setStroke(new BasicStroke(1.4f));
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,12,12);
                g2.dispose();
            }
        };
        toast.setOpaque(false);

        JLabel dot = new JLabel("●");
        dot.setFont(new Font("Segoe UI", Font.PLAIN, 8));
        dot.setForeground(accent);

        JLabel lbl = new JLabel(msg);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(TEXT);

        toast.add(dot); toast.add(lbl);
        toast.setSize(toast.getPreferredSize());

        // Stack below existing toasts
        int existingToasts = 0;
        for (Component c : lp.getComponentsInLayer(JLayeredPane.POPUP_LAYER))
            if (c != toast) existingToasts++;

        toast.setLocation(lp.getWidth() - toast.getWidth() - 14, 14 + existingToasts * (toast.getHeight() + 6));
        lp.add(toast, JLayeredPane.POPUP_LAYER);
        lp.revalidate(); lp.repaint();

        Timer dismiss = new Timer(2800, e -> {
            lp.remove(toast); lp.revalidate(); lp.repaint();
        });
        dismiss.setRepeats(false);
        dismiss.start();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SOUND EFFECTS (synthesized — no audio files needed)
    // ═══════════════════════════════════════════════════════════════════════════
    private void playSoundSend() {
        new Thread(() -> tone(900, 55, 0.12f)).start();
    }

    private void playSoundReceive() {
        new Thread(() -> {
            tone(660, 70, 0.18f);
            try { Thread.sleep(85); } catch (Exception ignored) {}
            tone(880, 70, 0.18f);
        }).start();
    }

    private void playSoundError() {
        new Thread(() -> {
            tone(280, 110, 0.22f);
            try { Thread.sleep(120); } catch (Exception ignored) {}
            tone(210, 110, 0.22f);
        }).start();
    }

    private void tone(int hz, int ms, float vol) {
        try {
            AudioFormat fmt = new AudioFormat(44100, 16, 1, true, false);
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, fmt);
            if (!AudioSystem.isLineSupported(info)) return;
            SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
            line.open(fmt); line.start();
            int samples = 44100 * ms / 1000;
            byte[] buf = new byte[samples * 2];
            for (int i = 0; i < samples; i++) {
                double angle = 2.0 * Math.PI * i * hz / 44100.0;
                double env = Math.min(1.0, (samples - i) / (double)(samples * 0.25));
                short s = (short)(Math.sin(angle) * env * vol * Short.MAX_VALUE);
                buf[i*2] = (byte)(s & 0xFF);
                buf[i*2+1] = (byte)((s >> 8) & 0xFF);
            }
            line.write(buf, 0, buf.length);
            line.drain(); line.close();
        } catch (Exception ignored) {}
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // TOKEN WARNING
    // ═══════════════════════════════════════════════════════════════════════════
    private void showTokenWarn() {
        String reset  = tokenResetDate != null ? tokenResetDate : "your next reset";
        String upgrade = "";
        if (!userPlan.equals("banana") && !userPlan.equals("owner")) {
            String next = userPlan.equals("free") ? "Prem" : "Banana";
            upgrade = "  Upgrade to " + next + " for more.";
        }
        String which = currentMode.equals("ask") ? "Generative" : "Creation";
        tokenWarnLbl.setText("<html>Out of " + which + " tokens. Resets: " + reset + "." + upgrade + "</html>");
        tokenWarnBar.setVisible(true);
        showToast("🎫 Out of " + which.toLowerCase() + " tokens", ORANGE);
    }

    private void updateTokenWarn() {
        boolean empty = currentMode.equals("ask") ? genTokens == 0 : crtTokens == 0;
        if (empty && genTokens >= 0) showTokenWarn();
        else tokenWarnBar.setVisible(false);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // INSERT BCODE
    // ═══════════════════════════════════════════════════════════════════════════
    private void insertBCode() {
        if (lastBCode == null || editorFrame == null) return;
        try {
            JTextPane editor = editorFrame.getObjectEditorPanel().getCodeEditor();
            Document doc = editor.getDocument();
            doc.remove(0, doc.getLength());
            doc.insertString(0, lastBCode, null);
            postSystemPill("✓ BCode inserted into editor");
            insertBtn.setVisible(false);
            showToast("✓ BCode inserted", GREEN);
        } catch (Exception ex) {
            postErrorBubble("Insert failed: " + ex.getMessage());
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BAI/ COMMANDS
    // ═══════════════════════════════════════════════════════════════════════════
    private void executeCommands(String cmdsJson, String fullBody) {
        String inner = cmdsJson.replaceAll("^\\[|\\]$", "").trim();
        if (inner.isEmpty()) return;
        for (String part : inner.split(",(?=\\s*\")")) {
            String cmd = part.trim().replaceAll("^\"|\"$", "");
            if (cmd.startsWith("bai/createscript")) {
                String n = extractArg(cmd);
                if (n != null) { createScript(n, extractJson(fullBody, "script_content")); postSystemPill("✓ Created: " + n); }
            } else if (cmd.startsWith("bai/editscript")) {
                String n = extractArg(cmd), c = extractJson(fullBody, "script_content");
                if (n != null && c != null) { editScript(n, c); postSystemPill("✓ Edited: " + n); }
            } else if (cmd.startsWith("bai/readscript")) {
                String n = extractArg(cmd);
                if (n != null) { readScript(n); postSystemPill("📖 Read: " + n); }
            } else if (cmd.startsWith("bai/deletescript")) {
                String n = extractArg(cmd);
                if (n != null) {
                    int ok = JOptionPane.showConfirmDialog(this, "BananaAI wants to delete: " + n, "Confirm Delete", JOptionPane.YES_NO_OPTION);
                    if (ok == JOptionPane.YES_OPTION) { deleteScript(n); postSystemPill("🗑 Deleted: " + n); }
                    else postSystemPill("✗ Delete cancelled");
                }
            }
        }
    }

    private void createScript(String name, String content) {
        if (editorFrame == null) return;
        String code = (content != null && !content.isEmpty()) ? content
            : "script.start\n\nattach \"Banana Project Editor\";\nattach \"" + name + "\";\n\n"
            + "event:onStart()\n    engine.log(\"" + name + " ready!\");\nevent.end\n\nscript.end";
        editorFrame.getProject().scripts.put(name, code);
        lastBCode = code; insertBtn.setVisible(true);
    }

    private void editScript(String name, String content) {
        if (editorFrame == null || content == null) return;
        editorFrame.getProject().scripts.put(name, content);
        try {
            JTextPane ed = editorFrame.getObjectEditorPanel().getCodeEditor();
            Document doc = ed.getDocument();
            if (doc.getText(0, doc.getLength()).contains("attach \"" + name + "\"")) {
                doc.remove(0, doc.getLength()); doc.insertString(0, content, null);
            }
        } catch (Exception ignored) {}
        lastBCode = content; insertBtn.setVisible(true);
    }

    private String readScript(String name) {
        return editorFrame != null ? editorFrame.getProject().scripts.get(name) : null;
    }

    private void deleteScript(String name) {
        if (editorFrame != null) editorFrame.getProject().scripts.remove(name);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // WORKSPACE CONTEXT
    // ═══════════════════════════════════════════════════════════════════════════
    private String buildWorkspaceContext() {
        if (editorFrame == null) return "";
        StringBuilder sb = new StringBuilder("[WORKSPACE CONTEXT]\n");
        sb.append("Project: ").append(editorFrame.getProject().name).append("\n");
        sb.append("Template: ").append(editorFrame.getProject().template).append("\n\nObjects:\n");
        for (com.bpe.project.BPEProject.ProjectObject o : editorFrame.getProject().objects)
            sb.append("  - ").append(o.name).append(" (").append(o.type).append(")\n");
        sb.append("\nScripts:\n");
        for (java.util.Map.Entry<String,String> e : editorFrame.getProject().scripts.entrySet())
            sb.append("--- ").append(e.getKey()).append(" ---\n").append(e.getValue()).append("\n\n");
        return sb.toString();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SERVER COMMS
    // ═══════════════════════════════════════════════════════════════════════════
    private void checkStatus() {
        new Thread(() -> {
            try {
                HttpURLConnection c = openConn("/api/health", 5000);
                c.setRequestMethod("GET");
                int code = c.getResponseCode();
                SwingUtilities.invokeLater(() -> {
                    boolean ok = code == 200;
                    statusDot.setForeground(ok ? GREEN : ORANGE);
                    statusText.setText(ok ? "online" : "degraded");
                    statusText.setForeground(ok ? GREEN : ORANGE);
                });
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> {
                    statusDot.setForeground(RED);
                    statusText.setText("offline");
                    statusText.setForeground(RED);
                });
            }
        }).start();
    }

    private void fetchTokens() {
        if (userId == null) return;
        String plan = SplashAuthScreen.getCachedPlan();
        int    gen  = SplashAuthScreen.getCachedGenTokens();
        int    crt  = SplashAuthScreen.getCachedCrtTokens();
        genTokens = gen; crtTokens = crt; userPlan = plan;
        refreshPills();

        new Thread(() -> {
            try {
                HttpURLConnection c = openConn("/api/tokens?user_id=" + userId, 5000);
                c.setRequestMethod("GET");
                if (c.getResponseCode() == 200) {
                    String body = new String(c.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
                    String sGen = extractJson(body, "generative_remaining");
                    String sCrt = extractJson(body, "creation_remaining");
                    String sPlan= extractJson(body, "plan");
                    String sRst = extractJson(body, "last_reset");
                    SwingUtilities.invokeLater(() -> {
                        if (sGen  != null) genTokens = parseIntSafe(sGen);
                        if (sCrt  != null) crtTokens = parseIntSafe(sCrt);
                        if (sPlan != null) userPlan  = sPlan;
                        tokenResetDate = sRst;
                        refreshPills();
                        updateTokenWarn();
                    });
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void refreshPills() {
        if (genPill != null) genPill.setText(genTokens >= 0 ? genTokens + " gen" : "-- gen");
        if (crtPill != null) crtPill.setText(crtTokens >= 0 ? crtTokens + " crt" : "-- crt");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // HELPERS
    // ═══════════════════════════════════════════════════════════════════════════
    private boolean isAISleeping() {
        LocalTime now = LocalTime.now(ZoneId.of("America/Chicago"));
        return now.isAfter(LocalTime.of(SLEEP_START_H, SLEEP_START_M))
            || now.isBefore(LocalTime.of(SLEEP_END_H,   SLEEP_END_M));
    }

    private HttpURLConnection openConn(String path, int timeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(SERVER_URL + path).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(timeout);
        return c;
    }

    private String buildJson(String message, String mode) {
        return "{\"user_id\":\"" + userId + "\","
            + "\"username\":\"" + escapeJson(username != null ? username : userId) + "\","
            + "\"message\":\"" + escapeJson(message) + "\","
            + "\"mode\":\"" + mode + "\""
            + (sessionId != null ? ",\"session_id\":\"" + sessionId + "\"" : "")
            + "}";
    }

    private String extractJson(String json, String key) {
        if (json == null) return null;
        String search = "\"" + key + "\":";
        int i = json.indexOf(search); if (i < 0) return null;
        i += search.length();
        while (i < json.length() && json.charAt(i) == ' ') i++;
        if (i >= json.length()) return null;
        if (json.charAt(i) == '"') {
            int end = i + 1; StringBuilder sb = new StringBuilder();
            while (end < json.length() && json.charAt(end) != '"') {
                if (json.charAt(end) == '\\' && end + 1 < json.length()) {
                    char esc = json.charAt(end+1);
                    if (esc=='n') sb.append('\n'); else if (esc=='t') sb.append('\t');
                    else if (esc=='"') sb.append('"'); else sb.append(esc);
                    end += 2;
                } else sb.append(json.charAt(end++));
            }
            return sb.toString();
        }
        int end = i;
        while (end < json.length() && ",}\n".indexOf(json.charAt(end)) < 0) end++;
        return json.substring(i, end).trim();
    }

    private String extractJsonArray(String json, String key) {
        if (json == null) return null;
        String search = "\"" + key + "\":";
        int i = json.indexOf(search); if (i < 0) return null;
        i += search.length();
        while (i < json.length() && json.charAt(i) == ' ') i++;
        if (i >= json.length() || json.charAt(i) != '[') return null;
        int depth = 0, start = i;
        while (i < json.length()) {
            if (json.charAt(i) == '[') depth++;
            if (json.charAt(i) == ']') { depth--; if (depth == 0) return json.substring(start, i+1); }
            i++;
        }
        return null;
    }

    private String extractBCode(String text) {
        int s = text.indexOf("script.start"), e = text.lastIndexOf("script.end");
        if (s >= 0 && e > s) return text.substring(s, e + "script.end".length()).trim();
        int cb = text.indexOf("```"), ce = text.indexOf("```", cb + 3);
        if (cb >= 0 && ce > cb) {
            String block = text.substring(cb+3, ce).trim();
            if (block.startsWith("bcode\n") || block.startsWith("lua\n"))
                block = block.substring(block.indexOf('\n')+1);
            if (block.contains("script.start")) return block.trim();
        }
        return null;
    }

    private String extractArg(String cmd) {
        int o = cmd.indexOf('('), c = cmd.lastIndexOf(')');
        if (o < 0 || c < 0) return null;
        return cmd.substring(o+1, c).replace("\"","").trim();
    }

    private String escapeJson(String s) {
        return s.replace("\\","\\\\").replace("\"","\\\"")
                .replace("\n","\\n").replace("\r","").replace("\t","\\t");
    }

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return -1; }
    }

    // ── Widget helpers ────────────────────────────────────────────────────────
    private JLabel makePill(String text, Color bg) {
        JLabel l = new JLabel(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),999,999);
                g2.setColor(BORDER);
                g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,999,999);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        l.setFont(new Font("Segoe UI", Font.BOLD, 10));
        l.setForeground(ACCENT);
        l.setBorder(BorderFactory.createEmptyBorder(3,9,3,9));
        l.setOpaque(false);
        return l;
    }

    private JButton makePillButton(String text, Color bg, Color fg) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? bg.brighter() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setForeground(fg);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setOpaque(false);
        b.setBorder(BorderFactory.createEmptyBorder(10,22,10,22));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    // ── Banana icon (Java2D) ──────────────────────────────────────────────────
    public static Image makeBananaIcon(int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        float s = size, pad = s * 0.1f;
        g.setStroke(new BasicStroke(s * 0.18f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(new Color(255, 210, 40));
        Path2D body = new Path2D.Float();
        body.moveTo(pad, s*0.82f); body.curveTo(pad, s*0.22f, s*0.78f, pad, s-pad, s*0.32f);
        g.draw(body);
        g.setColor(new Color(200, 155, 10));
        g.setStroke(new BasicStroke(s*0.07f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        Path2D inner = new Path2D.Float();
        inner.moveTo(pad+s*0.06f, s*0.76f); inner.curveTo(pad+s*0.06f, s*0.30f, s*0.72f, pad+s*0.06f, s-pad-s*0.06f, s*0.38f);
        g.draw(inner);
        g.setColor(new Color(150,100,10));
        g.fillOval((int)(pad-2),(int)(s*0.77f),(int)(s*0.12f),(int)(s*0.12f));
        g.fillOval((int)(s-pad-s*0.10f),(int)(s*0.27f),(int)(s*0.12f),(int)(s*0.12f));
        g.dispose();
        return img;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // INNER CLASSES
    // ═══════════════════════════════════════════════════════════════════════════

    /** Chat message bubble — rounded rectangle with a directional tail */
    private static class Bubble extends JPanel {
        private final Color bg;
        private final boolean isUser; // true = right tail, false = left tail
        Bubble(Color bg, boolean isUser) {
            this.bg = bg; this.isUser = isUser;
            setOpaque(false);
            setLayout(new BorderLayout());
            setBorder(BorderFactory.createEmptyBorder(7, 11, 7, 11));
            setMaximumSize(new Dimension(isUser ? 360 : 400, Integer.MAX_VALUE));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D)g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int arc = 16, w = getWidth()-1, h = getHeight()-1;
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, w, h, arc, arc);
            // Flatten one bottom corner for the "tail" direction
            if (isUser)  g2.fillRect(w-arc/2, h-arc/2, arc/2+1, arc/2+1); // bottom-right
            else         g2.fillRect(0, h-arc/2, arc/2+1, arc/2+1);         // bottom-left
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Simple rounded border for the textarea */
    private static class RoundLineBorder implements Border {
        private final Color c; private final int r;
        RoundLineBorder(Color c, int r) { this.c=c; this.r=r; }
        public void paintBorder(Component comp, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D)g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(c); g2.drawRoundRect(x,y,w-1,h-1,r,r); g2.dispose();
        }
        public Insets getBorderInsets(Component c) { return new Insets(1,1,1,1); }
        public boolean isBorderOpaque() { return false; }
    }
}
