package com.bpe.editor;

import com.bpe.ui.BPETheme;
import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

/**
 * Scratch-style block editor.
 * Left palette of categorised blocks, right canvas to snap them together.
 * Converts block stack to BCode text on request.
 */
public class BlockEditor extends JPanel {

    // ── block definitions ─────────────────────────────────────────────────────
    public enum BlockShape { HAT, COMMAND, REPORTER, CONTROL }

    public static class BlockDef {
        public final String label, category, bcode;
        public final BlockShape shape;
        public final Color color;
        public final List<String> fields; // field names embedded in label as {name}

        public BlockDef(String label, String category, BlockShape shape, Color color, String bcode) {
            this.label    = label;
            this.category = category;
            this.shape    = shape;
            this.color    = color;
            this.bcode    = bcode;
            this.fields   = new ArrayList<>();
            // extract {field} names
            int i = 0;
            while (i < label.length()) {
                int s = label.indexOf('{', i);
                if (s < 0) break;
                int e = label.indexOf('}', s);
                if (e < 0) break;
                fields.add(label.substring(s+1, e));
                i = e+1;
            }
        }
    }

    // live block instance on the canvas
    public static class BlockInstance {
        public BlockDef def;
        public int x, y;
        public Map<String,String> fieldValues = new LinkedHashMap<>();
        public BlockInstance next = null; // next block in stack
        public BlockInstance prev = null;

        public BlockInstance(BlockDef def, int x, int y) {
            this.def = def;
            this.x = x; this.y = y;
            for (String f : def.fields) fieldValues.put(f, "0");
        }
        public int getWidth()  { return 180; }
        public int getHeight() { return def.shape == BlockShape.CONTROL ? 48 : 36; }
    }

    // ── colours per category ──────────────────────────────────────────────────
    static final Color C_EVENTS   = new Color(220, 100,  20);
    static final Color C_MOTION   = new Color( 60, 130, 220);
    static final Color C_CONTROL  = new Color(220, 170,  20);
    static final Color C_INPUT    = new Color(180,  60, 200);
    static final Color C_LOOKS    = new Color( 60, 180, 100);
    static final Color C_SOUND    = new Color(200,  60, 100);
    static final Color C_ENGINE   = new Color(100, 100, 120);
    static final Color C_MATH     = new Color( 60, 180, 180);

    // ── all block definitions ─────────────────────────────────────────────────
    static final List<BlockDef> ALL_BLOCKS = new ArrayList<>();
    static {
        // Events
        ALL_BLOCKS.add(new BlockDef("on Start",            "Events",  BlockShape.HAT,     C_EVENTS,  "event:onStart()"));
        ALL_BLOCKS.add(new BlockDef("on Update",           "Events",  BlockShape.HAT,     C_EVENTS,  "event:onUpdate()"));
        ALL_BLOCKS.add(new BlockDef("on Destroy",          "Events",  BlockShape.HAT,     C_EVENTS,  "event:onDestroy()"));
        ALL_BLOCKS.add(new BlockDef("on Click",            "Events",  BlockShape.HAT,     C_EVENTS,  "object.event:OnClick()"));
        ALL_BLOCKS.add(new BlockDef("on Collide",          "Events",  BlockShape.HAT,     C_EVENTS,  "event:onCollide(other)"));
        // Motion
        ALL_BLOCKS.add(new BlockDef("set position  x {x}  y {y}", "Motion", BlockShape.COMMAND, C_MOTION, "object.SetPosition({x}, {y})"));
        ALL_BLOCKS.add(new BlockDef("set X to {x}",        "Motion",  BlockShape.COMMAND, C_MOTION,  "object.SetPosition({x}, object.GetPosition().y)"));
        ALL_BLOCKS.add(new BlockDef("set Y to {y}",        "Motion",  BlockShape.COMMAND, C_MOTION,  "object.SetPosition(object.GetPosition().x, {y})"));
        ALL_BLOCKS.add(new BlockDef("set rotation {deg}",  "Motion",  BlockShape.COMMAND, C_MOTION,  "object.SetRotation({deg})"));
        ALL_BLOCKS.add(new BlockDef("set size  w {w}  h {h}", "Motion", BlockShape.COMMAND, C_MOTION, "object.SetSize({w}, {h})"));
        // Control
        ALL_BLOCKS.add(new BlockDef("wait {sec} seconds",  "Control", BlockShape.COMMAND, C_CONTROL, "-- wait {sec}s"));
        ALL_BLOCKS.add(new BlockDef("if {cond} =",         "Control", BlockShape.CONTROL, C_CONTROL, "if ({cond}) ="));
        ALL_BLOCKS.add(new BlockDef("forever =",           "Control", BlockShape.CONTROL, C_CONTROL, "forever ="));
        ALL_BLOCKS.add(new BlockDef("repeat {n} times",    "Control", BlockShape.CONTROL, C_CONTROL, "-- repeat {n}"));
        // Input
        ALL_BLOCKS.add(new BlockDef("key {key} down?",     "Input",   BlockShape.REPORTER,C_INPUT,   "object.KeyDown(\"{key}\")"));
        ALL_BLOCKS.add(new BlockDef("key {key} pressed?",  "Input",   BlockShape.REPORTER,C_INPUT,   "object.KeyPressed(\"{key}\")"));
        ALL_BLOCKS.add(new BlockDef("mouse down?",         "Input",   BlockShape.REPORTER,C_INPUT,   "object.MouseDown()"));
        ALL_BLOCKS.add(new BlockDef("mouse clicked?",      "Input",   BlockShape.REPORTER,C_INPUT,   "object.MouseClicked()"));
        // Looks
        ALL_BLOCKS.add(new BlockDef("show",                "Looks",   BlockShape.COMMAND, C_LOOKS,   "object.Show(1)"));
        ALL_BLOCKS.add(new BlockDef("hide",                "Looks",   BlockShape.COMMAND, C_LOOKS,   "object.Hide()"));
        ALL_BLOCKS.add(new BlockDef("set opacity {pct}",   "Looks",   BlockShape.COMMAND, C_LOOKS,   "object.Show({pct})"));
        ALL_BLOCKS.add(new BlockDef("set text {text}",     "Looks",   BlockShape.COMMAND, C_LOOKS,   "object.SetText(\"{text}\")"));
        // Sound
        ALL_BLOCKS.add(new BlockDef("play sound {name}",   "Sound",   BlockShape.COMMAND, C_SOUND,   "sound.Play(\"{name}\")"));
        // Engine
        ALL_BLOCKS.add(new BlockDef("log {msg}",           "Engine",  BlockShape.COMMAND, C_ENGINE,  "engine.log(\"{msg}\")"));
        ALL_BLOCKS.add(new BlockDef("set title {title}",   "Engine",  BlockShape.COMMAND, C_ENGINE,  "window.SetTitle(\"{title}\")"));
        ALL_BLOCKS.add(new BlockDef("load scene {name}",   "Engine",  BlockShape.COMMAND, C_ENGINE,  "engine.LoadScene(\"{name}\")"));
        ALL_BLOCKS.add(new BlockDef("quit",                "Engine",  BlockShape.COMMAND, C_ENGINE,  "engine.Quit()"));
        // Math / vars
        ALL_BLOCKS.add(new BlockDef("set {var} = {val}",   "Math",    BlockShape.COMMAND, C_MATH,    "local {var} = {val}"));
        ALL_BLOCKS.add(new BlockDef("{var} += {val}",      "Math",    BlockShape.COMMAND, C_MATH,    "{var} = {var} + {val}"));
        ALL_BLOCKS.add(new BlockDef("{var} -= {val}",      "Math",    BlockShape.COMMAND, C_MATH,    "{var} = {var} - {val}"));
    }

    static final LinkedHashMap<String, Color> CATEGORIES = new LinkedHashMap<>();
    static {
        CATEGORIES.put("Events",  C_EVENTS);
        CATEGORIES.put("Motion",  C_MOTION);
        CATEGORIES.put("Control", C_CONTROL);
        CATEGORIES.put("Input",   C_INPUT);
        CATEGORIES.put("Looks",   C_LOOKS);
        CATEGORIES.put("Sound",   C_SOUND);
        CATEGORIES.put("Engine",  C_ENGINE);
        CATEGORIES.put("Math",    C_MATH);
    }

    // ── state ─────────────────────────────────────────────────────────────────
    private String activeCategory = "Events";
    private final List<BlockInstance> canvasBlocks = new ArrayList<>();
    private BlockInstance dragging  = null;
    private int dragOx, dragOy;
    private BlockInstance snapTarget = null;
    private final Runnable onChanged; // called when blocks change (to update code)

    public BlockEditor(Runnable onChanged) {
        this.onChanged = onChanged;
        setLayout(new BorderLayout());
        setBackground(BPETheme.BG_DEEPEST);
        add(buildPalette(), BorderLayout.WEST);
        add(buildCanvas(),  BorderLayout.CENTER);
    }

    // ── palette ───────────────────────────────────────────────────────────────
    private JPanel buildPalette() {
        JPanel root = new JPanel(new BorderLayout());
        root.setPreferredSize(new Dimension(170, 0));
        root.setBackground(BPETheme.BG_DEEP);
        root.setBorder(BorderFactory.createMatteBorder(0,0,0,1, BPETheme.BORDER));

        // Category buttons
        JPanel cats = new JPanel();
        cats.setLayout(new BoxLayout(cats, BoxLayout.Y_AXIS));
        cats.setBackground(BPETheme.BG_MID);
        cats.setBorder(BorderFactory.createMatteBorder(0,0,1,0, BPETheme.BORDER));

        JPanel blocksPanel = new JPanel();
        blocksPanel.setLayout(new BoxLayout(blocksPanel, BoxLayout.Y_AXIS));
        blocksPanel.setBackground(BPETheme.BG_DEEP);
        blocksPanel.setBorder(BorderFactory.createEmptyBorder(6,6,6,6));

        for (Map.Entry<String, Color> e : CATEGORIES.entrySet()) {
            String cat = e.getKey();
            Color col  = e.getValue();
            JButton btn = new JButton(cat);
            btn.setFont(BPETheme.FONT_MONO_SMALL);
            btn.setBackground(col.darker().darker());
            btn.setForeground(Color.WHITE);
            btn.setBorder(BorderFactory.createEmptyBorder(4,10,4,10));
            btn.setFocusPainted(false);
            btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            btn.addActionListener(ev -> {
                activeCategory = cat;
                refreshBlockList(blocksPanel);
            });
            cats.add(btn);
        }

        root.add(cats, BorderLayout.NORTH);

        JScrollPane blockScroll = new JScrollPane(blocksPanel);
        blockScroll.setBorder(BorderFactory.createEmptyBorder());
        blockScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        root.add(blockScroll, BorderLayout.CENTER);

        refreshBlockList(blocksPanel);
        return root;
    }

    private void refreshBlockList(JPanel blocksPanel) {
        blocksPanel.removeAll();
        for (BlockDef def : ALL_BLOCKS) {
            if (!def.category.equals(activeCategory)) continue;
            PaletteBlock pb = new PaletteBlock(def);
            blocksPanel.add(pb);
            blocksPanel.add(Box.createVerticalStrut(4));
        }
        blocksPanel.revalidate();
        blocksPanel.repaint();
    }

    // ── canvas ────────────────────────────────────────────────────────────────
    private CanvasPanel canvasPanel;

    private JScrollPane buildCanvas() {
        canvasPanel = new CanvasPanel();
        JScrollPane sc = new JScrollPane(canvasPanel);
        sc.setBorder(BorderFactory.createEmptyBorder());
        sc.getViewport().setBackground(new Color(35,35,42));
        return sc;
    }

    // ── palette block widget ──────────────────────────────────────────────────
    private class PaletteBlock extends JPanel {
        final BlockDef def;
        PaletteBlock(BlockDef d) {
            this.def = d;
            setPreferredSize(new Dimension(150, d.shape == BlockShape.CONTROL ? 44 : 32));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, d.shape == BlockShape.CONTROL ? 44 : 32));
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setToolTipText("Drag onto canvas");

            addMouseListener(new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) {
                    // Spawn a new instance at mouse position on canvas
                    Point cp = SwingUtilities.convertPoint(PaletteBlock.this, e.getPoint(), canvasPanel);
                    BlockInstance inst = new BlockInstance(def, cp.x - 90, cp.y - 18);
                    canvasBlocks.add(inst);
                    dragging = inst;
                    dragOx = 90; dragOy = 18;
                    canvasPanel.repaint();
                }
            });
        }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            drawBlock((Graphics2D)g, def, null, 0, 0, getWidth(), getHeight(), false);
        }
    }

    // ── canvas panel ──────────────────────────────────────────────────────────
    private class CanvasPanel extends JPanel {
        CanvasPanel() {
            setBackground(new Color(35,35,42));
            setPreferredSize(new Dimension(2000, 2000));

            addMouseListener(new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) {
                    // Right-click = delete block
                    if (e.getButton() == MouseEvent.BUTTON3) {
                        for (int i = canvasBlocks.size()-1; i >= 0; i--) {
                            BlockInstance b = canvasBlocks.get(i);
                            if (hits(b, e.getX(), e.getY())) {
                                if (b.prev != null) b.prev.next = null;
                                if (b.next != null) b.next.prev = null;
                                canvasBlocks.remove(b);
                                if (onChanged != null) onChanged.run();
                                repaint(); return;
                            }
                        }
                        return;
                    }
                    // Left-click = drag block
                    for (int i = canvasBlocks.size()-1; i >= 0; i--) {
                        BlockInstance b = canvasBlocks.get(i);
                        if (hits(b, e.getX(), e.getY())) {
                            dragging = b;
                            dragOx = e.getX() - b.x;
                            dragOy = e.getY() - b.y;
                            if (b.prev != null) { b.prev.next = null; b.prev = null; }
                            canvasBlocks.remove(b);
                            canvasBlocks.add(b);
                            repaint(); return;
                        }
                    }
                }
                @Override public void mouseReleased(MouseEvent e) {
                    if (dragging == null) return;
                    // Try to snap to another block
                    snap(dragging);
                    dragging = null;
                    snapTarget = null;
                    if (onChanged != null) onChanged.run();
                    repaint();
                }
            });

            addMouseMotionListener(new MouseMotionAdapter() {
                @Override public void mouseDragged(MouseEvent e) {
                    if (dragging == null) return;
                    dragging.x = e.getX() - dragOx;
                    dragging.y = e.getY() - dragOy;
                    // Find snap candidate
                    snapTarget = null;
                    for (BlockInstance b : canvasBlocks) {
                        if (b == dragging) continue;
                        if (b.next == null && canSnapBelow(b, dragging)) {
                            snapTarget = b;
                            break;
                        }
                    }
                    repaint();
                }
            });

        }

        boolean hits(BlockInstance b, int mx, int my) {
            return mx >= b.x && mx <= b.x+b.getWidth() && my >= b.y && my <= b.y+b.getHeight();
        }

        boolean canSnapBelow(BlockInstance above, BlockInstance below) {
            int ax = above.x, ay = above.y + above.getHeight();
            return Math.abs(below.x - ax) < 40 && Math.abs(below.y - ay) < 28;
        }

        void snap(BlockInstance b) {
            if (snapTarget == null) return;
            b.x = snapTarget.x;
            b.y = snapTarget.y + snapTarget.getHeight();
            snapTarget.next = b;
            b.prev = snapTarget;
            // Restack subsequent blocks
            BlockInstance cur = b.next;
            BlockInstance par = b;
            while (cur != null) {
                cur.x = par.x;
                cur.y = par.y + par.getHeight();
                par = cur; cur = cur.next;
            }
        }

        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Dot grid
            g2.setColor(new Color(50,50,58));
            for (int gx = 0; gx < getWidth(); gx += 24)
                for (int gy = 0; gy < getHeight(); gy += 24)
                    g2.fillOval(gx, gy, 2, 2);

            // Snap highlight
            if (snapTarget != null) {
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(2, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND,
                    1, new float[]{4,4}, 0));
                g2.drawRoundRect(snapTarget.x-2, snapTarget.y-2,
                    snapTarget.getWidth()+4, snapTarget.getHeight()+4, 8, 8);
                g2.setStroke(new BasicStroke(1));
            }

            // Draw blocks (non-dragging first)
            for (BlockInstance b : canvasBlocks) {
                if (b == dragging) continue;
                drawBlock(g2, b.def, b.fieldValues, b.x, b.y, b.getWidth(), b.getHeight(), false);
            }
            // Draw dragging on top
            if (dragging != null)
                drawBlock(g2, dragging.def, dragging.fieldValues, dragging.x, dragging.y,
                    dragging.getWidth(), dragging.getHeight(), true);

            // Hint
            if (canvasBlocks.isEmpty()) {
                g2.setColor(new Color(80,80,90));
                g2.setFont(new Font("Consolas", Font.PLAIN, 13));
                String h = "Drag blocks here from the palette";
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(h, (getWidth()-fm.stringWidth(h))/2, getHeight()/2);
            }
        }
    } // end CanvasPanel

    // ── block drawing ─────────────────────────────────────────────────────────
    private void drawBlock(Graphics2D g2, BlockDef def, Map<String,String> values,
                           int x, int y, int w, int h, boolean ghost) {
        float alpha = ghost ? 0.75f : 1f;
        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, alpha));

        Color base = def.color;
        Color dark = base.darker();

        // Shape
        switch (def.shape) {
            case HAT: {
                // Rounded top + notch bottom
                g2.setColor(base);
                g2.fillRoundRect(x, y, w, h-8, 12, 12);
                g2.fillRect(x, y+h-16, w, 16);
                // Puzzle notch out
                g2.setColor(base.darker());
                g2.fillRoundRect(x+12, y+h-10, 20, 10, 6, 6);
                g2.setColor(base);
                g2.fillRoundRect(x+14, y+h-8, 16, 10, 5, 5);
                // Border
                g2.setColor(dark);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(x, y, w, h-8, 12, 12);
                // Hat curve
                g2.setColor(base.brighter());
                g2.setStroke(new BasicStroke(2));
                g2.drawArc(x, y, w/3, h/2, 0, 180);
                break;
            }
            case CONTROL: {
                g2.setColor(base);
                g2.fillRoundRect(x, y, w, h, 8, 8);
                // C-shape indent
                g2.setColor(base.darker().darker());
                g2.fillRect(x+16, y+20, w-24, h-28);
                g2.setColor(dark);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(x, y, w, h, 8, 8);
                break;
            }
            case REPORTER: {
                // Oval/pill shape
                g2.setColor(base);
                g2.fillRoundRect(x, y+4, w, h-8, h-8, h-8);
                g2.setColor(dark);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(x, y+4, w, h-8, h-8, h-8);
                break;
            }
            default: { // COMMAND
                g2.setColor(base);
                g2.fillRoundRect(x, y, w, h, 8, 8);
                // Puzzle notch top (fits into previous block)
                g2.setColor(base);
                g2.fillRoundRect(x+12, y-4, 20, 10, 5, 5);
                // Notch bottom
                g2.setColor(base.darker());
                g2.fillRoundRect(x+12, y+h-5, 20, 10, 5, 5);
                g2.setColor(base);
                g2.fillRoundRect(x+14, y+h-3, 16, 8, 4, 4);
                g2.setColor(dark);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(x, y, w, h, 8, 8);
                break;
            }
        }

        g2.setStroke(new BasicStroke(1));

        // Label text — render parts, replacing {field} with editable boxes
        g2.setFont(new Font("Consolas", Font.BOLD, 11));
        g2.setColor(Color.WHITE);
        int tx = x + 10;
        int ty = (def.shape == BlockShape.REPORTER) ? y + h/2 + 4 : y + h/2 + 5;
        String lbl = def.label;
        String[] parts = lbl.split("\\{[^}]+\\}");
        List<String> fieldNames = def.fields;
        int fi = 0;
        for (int pi = 0; pi < parts.length; pi++) {
            // draw text part
            g2.setColor(Color.WHITE);
            g2.setFont(new Font("Consolas", Font.BOLD, 11));
            g2.drawString(parts[pi].trim(), tx, ty);
            tx += g2.getFontMetrics().stringWidth(parts[pi].trim()) + 4;
            // draw field box
            if (fi < fieldNames.size()) {
                String fName = fieldNames.get(fi);
                String fVal  = (values != null) ? values.getOrDefault(fName, fName) : fName;
                int fw = Math.max(28, g2.getFontMetrics().stringWidth(fVal) + 10);
                g2.setColor(new Color(255,255,255,60));
                g2.fillRoundRect(tx, ty-13, fw, 16, 4, 4);
                g2.setColor(new Color(255,255,255,120));
                g2.drawRoundRect(tx, ty-13, fw, 16, 4, 4);
                g2.setColor(Color.WHITE);
                g2.drawString(fVal, tx+4, ty);
                tx += fw + 4;
                fi++;
            }
        }

        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
    }

    // ── code generation ───────────────────────────────────────────────────────
    public String generateBCode(String objectName) {
        if (canvasBlocks.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        sb.append("script.start\n\n");
        sb.append("attach \"Banana Project Editor\";\n");
        sb.append("attach \"").append(objectName).append("\";\n\n");

        // Find root blocks (no prev)
        List<BlockInstance> roots = new ArrayList<>();
        for (BlockInstance b : canvasBlocks)
            if (b.prev == null) roots.add(b);

        for (BlockInstance root : roots) {
            // Determine event wrapper
            boolean isHat = root.def.shape == BlockShape.HAT;
            if (isHat) {
                sb.append(fillTemplate(root.def.bcode, root.fieldValues)).append("\n");
                BlockInstance cur = root.next;
                while (cur != null) {
                    sb.append("    ").append(generateStatement(cur)).append("\n");
                    cur = cur.next;
                }
                sb.append("event.end\n\n");
            } else {
                sb.append(generateStatement(root)).append("\n");
            }
        }

        sb.append("script.end");
        return sb.toString();
    }

    private String generateStatement(BlockInstance b) {
        if (b.def.shape == BlockShape.CONTROL) {
            StringBuilder s = new StringBuilder();
            s.append(fillTemplate(b.def.bcode, b.fieldValues)).append("\n");
            BlockInstance child = b.next;
            while (child != null && child.def.shape != BlockShape.HAT) {
                s.append("        ").append(fillTemplate(child.def.bcode, child.fieldValues)).append(";\n");
                child = child.next;
            }
            if (s.charAt(s.length()-1) == '\n')
                s.setCharAt(s.length()-1, ']');
            else s.append("]");
            return s.toString();
        }
        return fillTemplate(b.def.bcode, b.fieldValues) + ";";
    }

    private String fillTemplate(String template, Map<String,String> values) {
        String r = template;
        if (values != null)
            for (Map.Entry<String,String> e : values.entrySet())
                r = r.replace("{" + e.getKey() + "}", e.getValue());
        return r;
    }

    public void clearCanvas() { canvasBlocks.clear(); canvasPanel.repaint(); }
    public List<BlockInstance> getBlocks() { return canvasBlocks; }
}
