package com.bpe.editor;

import com.bpe.bcode.BCodeInterpreter;
import com.bpe.project.BPEProject;
import com.bpe.ui.BPETheme;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.RadialGradientPaint;
import java.util.*;
import java.util.function.Consumer;

public class GameWindow extends JFrame {

    private final BPEProject       project;
    private final BCodeInterpreter interpreter;
    private final GameCanvas       canvas;
    private javax.swing.Timer gameLoop;

    // Input state
    private final Set<String> keysDown     = new HashSet<>();
    private final Set<String> keysPressed  = new HashSet<>();
    private final Set<String> keysReleased = new HashSet<>();
    private boolean mouseDown    = false;
    private boolean mouseClicked = false;

    public GameWindow(BPEProject project,
                      Consumer<String> onLog,
                      Consumer<String> onWarn,
                      Consumer<String> onError) {
        this.project = project;
        setTitle(project.settings.windowTitle);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setIconImage(BPETheme.createBananaIcon(32));
        setResizable(false);

        canvas = new GameCanvas(project);
        setContentPane(canvas);
        pack();
        setLocationRelativeTo(null);

        interpreter = new BCodeInterpreter(project, onLog, onWarn, onError);

        // ── keyboard input ────────────────────────────────────────────────────
        canvas.setFocusable(true);
        canvas.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                String key = keyName(e);
                if (!keysDown.contains(key)) keysPressed.add(key);
                keysDown.add(key);
                keysReleased.remove(key);
            }
            @Override public void keyReleased(KeyEvent e) {
                String key = keyName(e);
                keysDown.remove(key);
                keysReleased.add(key);
            }
        });

        // ── mouse input ───────────────────────────────────────────────────────
        canvas.addMouseListener(new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { mouseDown = true; mouseClicked = true; }
            @Override public void mouseReleased(MouseEvent e) { mouseDown = false; }
        });

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { stop(); dispose(); }
        });
    }

    public void start() {
        setVisible(true);
        canvas.requestFocusInWindow();
        interpreter.runAllScripts();

        gameLoop = new javax.swing.Timer(16, e -> {
            // Push input state to interpreter
            interpreter.setInputState(
                new HashSet<>(keysDown),
                new HashSet<>(keysPressed),
                new HashSet<>(keysReleased),
                mouseDown, mouseClicked
            );
            // Run onUpdate + forever blocks
            interpreter.runUpdateScripts();
            interpreter.runBroadcasts();
            // Clear one-shot states
            keysPressed.clear();
            keysReleased.clear();
            mouseClicked = false;
            canvas.repaint();
        });
        gameLoop.start();
    }

    public void stop() {
        if (gameLoop != null) { gameLoop.stop(); gameLoop = null; }
        interpreter.stop();
    }

    /** Map Java KeyEvent to BCode key name ("W", "Space", "Up", etc.) */
    private String keyName(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_SPACE:     return "SPACE";
            case KeyEvent.VK_UP:        return "UP";
            case KeyEvent.VK_DOWN:      return "DOWN";
            case KeyEvent.VK_LEFT:      return "LEFT";
            case KeyEvent.VK_RIGHT:     return "RIGHT";
            case KeyEvent.VK_ENTER:     return "ENTER";
            case KeyEvent.VK_ESCAPE:    return "ESCAPE";
            case KeyEvent.VK_SHIFT:     return "SHIFT";
            case KeyEvent.VK_CONTROL:   return "CTRL";
            case KeyEvent.VK_ALT:       return "ALT";
            case KeyEvent.VK_BACK_SPACE:return "BACKSPACE";
            case KeyEvent.VK_TAB:       return "TAB";
            case KeyEvent.VK_DELETE:    return "DELETE";
            default:
                // Letters / numbers — single char uppercase
                String s = KeyEvent.getKeyText(e.getKeyCode());
                return s.length() == 1 ? s.toUpperCase() : s.toUpperCase();
        }
    }

    // ── game canvas ───────────────────────────────────────────────────────────

    static class GameCanvas extends JPanel {
        private final BPEProject project;

        GameCanvas(BPEProject p) {
            this.project = p;
            setPreferredSize(new Dimension(p.settings.windowWidth, p.settings.windowHeight));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,      RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING,         RenderingHints.VALUE_RENDER_QUALITY);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            // Background
            Color bg = Color.WHITE;
            try { bg = Color.decode(project.settings.backgroundColor); } catch (Exception ignored) {}
            g2.setColor(bg);
            g2.fillRect(0, 0, getWidth(), getHeight());

            // Sort by layer
            java.util.List<BPEProject.ProjectObject> sorted = new java.util.ArrayList<>(project.objects);
            sorted.sort((a, b) -> Integer.compare(a.layer, b.layer));

            for (BPEProject.ProjectObject obj : sorted) {
                if (!obj.visible) continue;
                int   x = (int) obj.x, y = (int) obj.y;
                int   w = Math.max(2, (int) obj.width), h = Math.max(2, (int) obj.height);
                float a = (float) Math.max(0, Math.min(1, obj.opacity));

                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, a));
                Color tint = obj.getAwtColor();
                Color fill = blend(baseColor(obj.type), tint);

                // Apply rotation
                java.awt.geom.AffineTransform savedTx = g2.getTransform();
                if (obj.rotation != 0) {
                    g2.rotate(Math.toRadians(obj.rotation), x + w/2.0, y + h/2.0);
                }

                switch (obj.type) {
                    case "Sprite": case "AnimatedSprite": case "Image": {
                        java.awt.image.BufferedImage img = loadCostumeImage(obj);
                        if (img != null) {
                            g2.drawImage(img, x, y, w, h, null);
                        } else {
                            drawCheckerboard(g2, x, y, w, h);
                            if (!tint.equals(Color.WHITE)) {
                                g2.setColor(new Color(tint.getRed(), tint.getGreen(), tint.getBlue(), 120));
                                g2.fillRect(x, y, w, h);
                            }
                            g2.setColor(fill.darker());
                            g2.setStroke(new BasicStroke(1.5f));
                            g2.drawRect(x, y, w, h);
                        }
                        break;
                    }
                    case "UIButton": {
                        GradientPaint gp = new GradientPaint(x, y, fill.brighter(), x, y+h, fill);
                        g2.setPaint(gp);
                        g2.fillRoundRect(x, y, w, h, 10, 10);
                        g2.setColor(fill.darker());
                        g2.setStroke(new BasicStroke(1.5f));
                        g2.drawRoundRect(x, y, w, h, 10, 10);
                        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                        g2.setColor(brightness(fill) > 128 ? new Color(40,40,40) : Color.WHITE);
                        g2.setFont(new Font("Consolas", Font.BOLD, Math.max(10, h/3)));
                        FontMetrics fm = g2.getFontMetrics();
                        g2.drawString(obj.name, x+(w-fm.stringWidth(obj.name))/2,
                                                y+(h+fm.getAscent()-fm.getDescent())/2);
                        break;
                    }
                    case "UILabel": case "Label": {
                        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                        g2.setColor(tint.equals(Color.WHITE) ? Color.BLACK : tint);
                        g2.setFont(new Font("Consolas", Font.PLAIN, 16));
                        g2.drawString(obj.name, x, y+16);
                        break;
                    }
                    case "UIFrame": {
                        g2.setColor(new Color(fill.getRed(), fill.getGreen(), fill.getBlue(), 80));
                        g2.fillRoundRect(x, y, w, h, 8, 8);
                        g2.setColor(fill.darker());
                        g2.setStroke(new BasicStroke(1.5f));
                        g2.drawRoundRect(x, y, w, h, 8, 8);
                        break;
                    }
                    case "Light2D": {
                        int r = Math.max(w, h) / 2;
                        Color lc = tint.equals(Color.WHITE) ? new Color(255,240,120) : tint;
                        RadialGradientPaint rgp = new RadialGradientPaint(
                            x+w/2f, y+h/2f, r,
                            new float[]{0f, 0.6f, 1f},
                            new Color[]{
                                new Color(lc.getRed(), lc.getGreen(), lc.getBlue(), 200),
                                new Color(lc.getRed(), lc.getGreen(), lc.getBlue(), 80),
                                new Color(lc.getRed(), lc.getGreen(), lc.getBlue(), 0)
                            });
                        g2.setPaint(rgp);
                        g2.fillOval(x, y, w, h);
                        break;
                    }
                    case "ParticleSystem": {
                        long t = System.currentTimeMillis();
                        for (int i = 0; i < 16; i++) {
                            double angle = i * Math.PI * 2 / 16 + t * 0.001;
                            double dist  = (Math.sin(t*0.003+i)*0.5+0.5) * Math.min(w,h)*0.45;
                            int px = x+w/2+(int)(Math.cos(angle)*dist);
                            int py = y+h/2+(int)(Math.sin(angle)*dist);
                            int ps = 2+(i%4);
                            float fa = (float)(Math.sin(t*0.005+i*0.7)*0.4+0.6);
                            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, fa*a));
                            g2.setColor(fill.brighter());
                            g2.fillOval(px-ps/2, py-ps/2, ps, ps);
                        }
                        break;
                    }
                    case "Camera2D": case "Viewport": break; // invisible at runtime
                    default: {
                        g2.setColor(fill);
                        g2.fillRect(x, y, w, h);
                        g2.setColor(fill.darker());
                        g2.setStroke(new BasicStroke(1f));
                        g2.drawRect(x, y, w, h);
                    }
                }
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                g2.setStroke(new BasicStroke(1f));
                g2.setTransform(savedTx); // restore after rotation
            }
        }

        private Color baseColor(String type) {
            switch (type) {
                case "Sprite": case "AnimatedSprite": case "Image": return new Color(130,190,255);
                case "Part":         return new Color(160,165,175);
                case "UIButton":     return new Color(220,120, 80);
                case "UILabel": case "Label": return new Color(240,220,60);
                case "UIFrame":      return new Color(180,180,220);
                case "RigidBody":    return new Color(240,160, 40);
                case "Collider":     return new Color(240,200, 40);
                case "TriggerZone":  return new Color(180,240, 80);
                case "ParticleSystem":return new Color(255,130,50);
                case "Sound": case "Music": return new Color(80,220,140);
                case "Light2D":      return new Color(255,240,100);
                default:             return new Color(180,180,195);
            }
        }

        private Color blend(Color base, Color tint) {
            if (tint == null || tint.equals(Color.WHITE)) return base;
            return new Color(
                Math.min(255, base.getRed()   * tint.getRed()   / 255),
                Math.min(255, base.getGreen() * tint.getGreen() / 255),
                Math.min(255, base.getBlue()  * tint.getBlue()  / 255));
        }

        private java.awt.image.BufferedImage loadCostumeImage(BPEProject.ProjectObject obj) {
            try {
                java.io.File dir = project.getCostumesFolder();
                java.io.File f = new java.io.File(dir, obj.name + "_frame" + obj.currentCostume + ".png");
                if (!f.exists()) f = new java.io.File(dir, obj.name + "_frame0.png");
                if (f.exists()) return javax.imageio.ImageIO.read(f);
            } catch (Exception ignored) {}
            return null;
        }

        private void drawCheckerboard(Graphics2D g2, int x, int y, int w, int h) {
            int cs = 10;
            for (int ty = 0; ty < h; ty += cs)
                for (int tx = 0; tx < w; tx += cs) {
                    g2.setColor(((tx/cs+ty/cs)%2==0) ? new Color(220,220,220) : new Color(190,190,190));
                    g2.fillRect(x+tx, y+ty, Math.min(cs,w-tx), Math.min(cs,h-ty));
                }
        }

        private int brightness(Color c) {
            return (c.getRed()*299 + c.getGreen()*587 + c.getBlue()*114) / 1000;
        }
    }
}
