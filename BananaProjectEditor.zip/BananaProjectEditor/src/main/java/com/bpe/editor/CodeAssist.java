package com.bpe.editor;

import com.bpe.ui.BPETheme;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

/**
 * Autocomplete popup for the BCode text editor.
 * Triggers after typing 2+ chars. Tab/Enter inserts, Escape dismisses.
 */
public class CodeAssist {

    // ── completion entries ────────────────────────────────────────────────────
    public static class Entry {
        public final String insert, display, detail;
        public Entry(String insert, String display, String detail) {
            this.insert = insert; this.display = display; this.detail = detail;
        }
    }

    private static final List<Entry> ALL = new ArrayList<>();
    static {
        // object.*
        add("object.SetPosition(", "object.SetPosition(x, y)", "Sets object position");
        add("object.GetPosition()", "object.GetPosition()", "Returns (x, y)");
        add("object.SetSize(",      "object.SetSize(w, h)",    "Sets object size");
        add("object.SetRotation(",  "object.SetRotation(deg)", "Sets rotation in degrees");
        add("object.Show(",         "object.Show(opacity)",    "Shows object (0-1)");
        add("object.Hide()",        "object.Hide()",           "Hides object");
        add("object.SetText(",      "object.SetText(text)",    "Sets label/button text");
        add("object.GetText()",     "object.GetText()",        "Gets label/button text");
        add("object.Clone()",       "object.Clone()",          "Duplicates this object");
        add("object.Destroy()",     "object.Destroy()",        "Removes this object");
        add("object.KeyDown(\"",    "object.KeyDown(\"Key\")", "Is key held down?");
        add("object.KeyPressed(\"", "object.KeyPressed(\"Key\")", "Was key just pressed?");
        add("object.KeyReleased(\"","object.KeyReleased(\"Key\")", "Was key just released?");
        add("object.MouseDown()",   "object.MouseDown()",      "Is mouse button held?");
        add("object.MouseClicked()","object.MouseClicked()",   "Was mouse just clicked?");
        // engine.*
        add("engine.log(",         "engine.log(msg)",          "Print to console");
        add("engine.warn(",        "engine.warn(msg)",         "Print warning");
        add("engine.error(",       "engine.error(msg)",        "Print error");
        add("engine.LoadScene(",   "engine.LoadScene(name)",   "Load a scene");
        add("engine.Quit()",       "engine.Quit()",            "Quit the game");
        add("engine.SceneReload()","engine.SceneReload()",     "Reload current scene");
        // window.*
        add("window.SetTitle(",    "window.SetTitle(text)",    "Set window title");
        add("window.SetSize(",     "window.SetSize(w, h)",     "Set window size");
        add("window.GetFPS()",     "window.GetFPS()",          "Returns current FPS");
        add("window.GetDeltaTime()","window.GetDeltaTime()",   "Returns delta time");
        // sound.*
        add("sound.Play(",         "sound.Play(name)",         "Play a sound");
        // time.*
        add("time.GetTime()",      "time.GetTime()",           "Seconds since start");
        // math.*
        add("math.Sin(",  "math.Sin(x)",         "Sine (degrees)");
        add("math.Cos(",  "math.Cos(x)",         "Cosine (degrees)");
        add("math.Abs(",  "math.Abs(x)",         "Absolute value");
        add("math.Floor(","math.Floor(x)",       "Round down");
        add("math.Ceil(", "math.Ceil(x)",        "Round up");
        add("math.Sqrt(", "math.Sqrt(x)",        "Square root");
        add("math.Pow(",  "math.Pow(x, y)",      "Power");
        add("math.Random(","math.Random(min, max)","Random number");
        add("math.Clamp(","math.Clamp(v, min, max)","Clamp value");
        // events
        add("event:onStart()",   "event:onStart()",   "Runs once on launch");
        add("event:onUpdate()",  "event:onUpdate()",  "Runs every frame");
        add("event:onDestroy()", "event:onDestroy()", "Runs on destruction");
        add("event:onCollide(",  "event:onCollide(other)", "Collision event");
        add("object.event:OnClick()", "object.event:OnClick()", "Object clicked");
        // keywords
        add("script.start", "script.start", "Script start marker");
        add("script.end",   "script.end",   "Script end marker");
        add("event.end",    "event.end",    "Event block end");
        add("attach \"",    "attach \"Name\"", "Attach to object");
        add("deattach;",    "deattach;",    "Detach current object");
        add("local ",       "local var = value", "Declare local variable");
        add("if (",         "if (condition) =", "Conditional block");
        add("else =",       "else =",       "Else block");
        add("forever =",    "forever =",    "Repeat every frame");
    }
    private static void add(String i, String d, String detail) { ALL.add(new Entry(i,d,detail)); }

    // ── popup UI ──────────────────────────────────────────────────────────────
    private final JTextPane editor;
    private JWindow         popup;
    private JList<Entry>    list;
    private DefaultListModel<Entry> model;
    private String          currentPrefix = "";

    public CodeAssist(JTextPane editor) {
        this.editor = editor;
        buildPopup();
        attachListeners();
    }

    private void buildPopup() {
        popup = new JWindow(SwingUtilities.getWindowAncestor(editor));
        popup.setFocusableWindowState(false);

        model = new DefaultListModel<>();
        list  = new JList<>(model);
        list.setBackground(BPETheme.BG_MID);
        list.setForeground(BPETheme.TEXT_PRIMARY);
        list.setFont(BPETheme.FONT_MONO_SMALL);
        list.setSelectionBackground(BPETheme.BG_SELECTED);
        list.setSelectionForeground(BPETheme.ACCENT);
        list.setFixedCellHeight(22);
        list.setCellRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(
                    JList<?> l, Object v, int i, boolean sel, boolean foc) {
                Entry e = (Entry) v;
                JPanel row = new JPanel(new BorderLayout(8, 0));
                row.setBackground(sel ? BPETheme.BG_SELECTED : BPETheme.BG_MID);
                row.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
                JLabel main = new JLabel(e.display);
                main.setFont(BPETheme.FONT_MONO_SMALL);
                main.setForeground(sel ? BPETheme.ACCENT : BPETheme.TEXT_PRIMARY);
                JLabel det = new JLabel(e.detail);
                det.setFont(new Font("Consolas", Font.PLAIN, 9));
                det.setForeground(BPETheme.TEXT_DIM);
                row.add(main, BorderLayout.CENTER);
                row.add(det,  BorderLayout.EAST);
                return row;
            }
        });
        list.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) insertSelected();
            }
        });

        JScrollPane sc = new JScrollPane(list);
        sc.setBorder(BorderFactory.createLineBorder(BPETheme.ACCENT, 1));
        sc.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        popup.setContentPane(sc);
    }

    private void attachListeners() {
        editor.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (!popup.isVisible()) return;
                int c = e.getKeyCode();
                if (c == KeyEvent.VK_DOWN) {
                    int i = Math.min(list.getSelectedIndex()+1, model.getSize()-1);
                    list.setSelectedIndex(i); list.ensureIndexIsVisible(i);
                    e.consume();
                } else if (c == KeyEvent.VK_UP) {
                    int i = Math.max(list.getSelectedIndex()-1, 0);
                    list.setSelectedIndex(i); list.ensureIndexIsVisible(i);
                    e.consume();
                } else if (c == KeyEvent.VK_TAB || c == KeyEvent.VK_ENTER) {
                    insertSelected(); e.consume();
                } else if (c == KeyEvent.VK_ESCAPE) {
                    hide();
                }
            }
        });

        editor.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { SwingUtilities.invokeLater(() -> trigger()); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { SwingUtilities.invokeLater(() -> trigger()); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) {}
        });
    }

    private void trigger() {
        try {
            int pos   = editor.getCaretPosition();
            String txt = editor.getDocument().getText(0, pos);
            // Get current word (last token)
            int lineStart = txt.lastIndexOf('\n') + 1;
            String line   = txt.substring(lineStart);
            // Find last word boundary
            int wordStart = line.length();
            while (wordStart > 0 && (Character.isLetterOrDigit(line.charAt(wordStart-1))
                || line.charAt(wordStart-1) == '.' || line.charAt(wordStart-1) == ':')) {
                wordStart--;
            }
            currentPrefix = line.substring(wordStart);
            if (currentPrefix.length() < 2) { hide(); return; }

            List<Entry> matches = new ArrayList<>();
            String lp = currentPrefix.toLowerCase();
            for (Entry e : ALL)
                if (e.insert.toLowerCase().startsWith(lp) || e.display.toLowerCase().contains(lp))
                    matches.add(e);

            if (matches.isEmpty()) { hide(); return; }

            model.clear();
            for (Entry e : matches) model.addElement(e);
            list.setSelectedIndex(0);

            // Position popup below caret
            Rectangle rect = editor.modelToView(pos);
            Point pt = SwingUtilities.convertPoint(editor, rect.x, rect.y + rect.height, null);
            SwingUtilities.convertPointToScreen(pt, editor.getRootPane());
            popup.setLocation(pt);
            int popH = Math.min(matches.size(), 8) * 22 + 4;
            popup.setSize(400, popH);
            popup.setVisible(true);
        } catch (Exception ignored) { hide(); }
    }

    private void insertSelected() {
        Entry e = list.getSelectedValue();
        if (e == null) { hide(); return; }
        try {
            int pos  = editor.getCaretPosition();
            String txt = editor.getDocument().getText(0, pos);
            int lineStart = txt.lastIndexOf('\n') + 1;
            String line   = txt.substring(lineStart);
            int wordStart = line.length();
            while (wordStart > 0 && (Character.isLetterOrDigit(line.charAt(wordStart-1))
                || line.charAt(wordStart-1) == '.' || line.charAt(wordStart-1) == ':')) {
                wordStart--;
            }
            int replaceStart = lineStart + wordStart;
            editor.getDocument().remove(replaceStart, pos - replaceStart);
            editor.getDocument().insertString(replaceStart, e.insert, null);
        } catch (Exception ignored) {}
        hide();
    }

    public void hide() { popup.setVisible(false); }
}
