package com.bpe.editor;

import com.bpe.project.BPEProject;
import javax.swing.*;
import java.awt.*;

/**
 * Container for the scene canvas in the editor.
 * Shows SceneCanvas in edit mode and switches to run info when running.
 */
public class GameDisplayPanel extends JPanel {

    private BPEProject project;
    private SceneCanvas sceneCanvas;
    private boolean running = false;

    public GameDisplayPanel(BPEProject project) {
        this.project = project;
        setLayout(new BorderLayout());
        setBackground(new Color(30, 30, 30));

        sceneCanvas = new SceneCanvas(project);
        add(sceneCanvas, BorderLayout.CENTER);
    }

    public void startRunning() {
        running = true;
        // GameWindow is spawned by EditorFrame - just show indicator here
        sceneCanvas.repaint();
    }

    public void stopRunning() {
        running = false;
        sceneCanvas.repaint();
    }

    public SceneCanvas getSceneCanvas() { return sceneCanvas; }
}
