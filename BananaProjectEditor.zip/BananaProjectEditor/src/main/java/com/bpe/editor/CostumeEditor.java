package com.bpe.editor;

import com.bpe.ui.BPETheme;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * Costume editor with:
 *  - Resizable drawing canvas that fills available space
 *  - Multi-frame support with frame switcher sidebar
 *  - Pencil, Eraser, Fill, Line tools
 *  - Import / Export per frame
 */
public class CostumeEditor extends JPanel {

    // Logical canvas resolution (the actual image data size)
    private static final int CW = 64, CH = 64;

    // ── frames ────────────────────────────────────────────────────────────────
    private final List<BufferedImage> frames = new ArrayList<>();
    private int currentFrame = 0;

    // ── project linkage ───────────────────────────────────────────────────────
    private com.bpe.project.BPEProject linkedProject;
    private String linkedObjectName;

    /** Called when the user selects an object — loads its saved frames */
    public void loadObject(com.bpe.project.BPEProject project, String objectName) {
        this.linkedProject    = project;
        this.linkedObjectName = objectName;
        frames.clear();
        currentFrame = 0;
        // Load saved frames: {costumes}/{objectName}_frame0.png, _frame1.png ...
        if (project != null && objectName != null) {
            File costDir = project.getCostumesFolder();
            for (int i = 0; i < 100; i++) {
                File f = new File(costDir, objectName + "_frame" + i + ".png");
                if (!f.exists()) break;
                try { frames.add(ImageIO.read(f)); } catch (Exception ignored) {}
            }
        }
        if (frames.isEmpty()) frames.add(blankFrame());
        if (drawPanel != null) drawPanel.repaint();
        refreshSidebar();
    }

    /** Returns the first frame image for rendering (or null) */
    public BufferedImage getFrame(int index) {
        if (index >= 0 && index < frames.size()) return frames.get(index);
        return frames.isEmpty() ? null : frames.get(0);
    }

    /** Auto-save all frames to project costumes folder */
    private void saveFrames() {
        if (linkedProject == null || linkedObjectName == null) return;
        File costDir = linkedProject.getCostumesFolder();
        costDir.mkdirs();
        for (int i = 0; i < frames.size(); i++) {
            try {
                ImageIO.write(frames.get(i), "PNG",
                    new File(costDir, linkedObjectName + "_frame" + i + ".png"));
            } catch (Exception ignored) {}
        }
    }

    // ── drawing state ─────────────────────────────────────────────────────────
    private Color  color   = Color.BLACK;
    private int    brush   = 3;
    private Tool   tool    = Tool.PENCIL;
    private int    lastX = -1, lastY = -1;
    private int    lineX0, lineY0;
    private BufferedImage lineSnap;

    // ── UI refs ───────────────────────────────────────────────────────────────
    private DrawPanel     drawPanel;
    private JPanel        frameSidebar;
    private JLabel        activeSwatch;
    private JLabel        frameSizeLabel;

    enum Tool { PENCIL, ERASER, FILL, LINE }

    public CostumeEditor() {
        setLayout(new BorderLayout());
        setBackground(BPETheme.BG_DEEP);

        // Start with one blank frame
        frames.add(blankFrame());

        add(buildToolbar(),  BorderLayout.NORTH);
        add(buildMain(),     BorderLayout.CENTER);
        add(buildColorBar(), BorderLayout.SOUTH);
    }

    // ── blank frame ───────────────────────────────────────────────────────────
    private BufferedImage blankFrame() {
        BufferedImage img = new BufferedImage(CW, CH, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, CW, CH);
        g.dispose();
        return img;
    }

    private BufferedImage currentCanvas() { return frames.get(currentFrame); }

    private Graphics2D currentG() {
        Graphics2D g = currentCanvas().createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        return g;
    }

    // ── toolbar ───────────────────────────────────────────────────────────────
    private JPanel buildToolbar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 4));
        bar.setBackground(BPETheme.BG_MID);
        bar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BPETheme.BORDER));

        ButtonGroup grp = new ButtonGroup();
        for (Tool t : Tool.values()) {
            JToggleButton b = toolBtn(capitalize(t.name()), t, grp);
            bar.add(b);
        }

        bar.add(sep());

        JLabel sl = label("Size:");
        JSpinner sz = new JSpinner(new SpinnerNumberModel(brush, 1, 30, 1));
        sz.setPreferredSize(new Dimension(52, 22));
        sz.setFont(BPETheme.FONT_MONO_SMALL);
        sz.addChangeListener(e -> brush = (Integer) sz.getValue());
        bar.add(sl); bar.add(sz);

        bar.add(sep());

        JButton clear = BPETheme.secondaryButton("Clear");
        clear.setFont(BPETheme.FONT_MONO_SMALL);
        clear.addActionListener(e -> { clearFrame(currentFrame); drawPanel.repaint(); refreshSidebar(); });
        bar.add(clear);

        JButton imp = BPETheme.secondaryButton("Import…");
        imp.setFont(BPETheme.FONT_MONO_SMALL);
        imp.addActionListener(e -> importImage());
        bar.add(imp);

        JButton exp = BPETheme.secondaryButton("Export…");
        exp.setFont(BPETheme.FONT_MONO_SMALL);
        exp.addActionListener(e -> exportImage());
        bar.add(exp);

        bar.add(sep());

        frameSizeLabel = new JLabel(CW + "×" + CH + "px");
        frameSizeLabel.setForeground(BPETheme.TEXT_DIM);
        frameSizeLabel.setFont(BPETheme.FONT_MONO_SMALL);
        bar.add(frameSizeLabel);

        return bar;
    }

    private JToggleButton toolBtn(String label, Tool t, ButtonGroup grp) {
        JToggleButton b = new JToggleButton(label);
        b.setFont(BPETheme.FONT_MONO_SMALL);
        b.setBackground(BPETheme.BG_RAISED);
        b.setForeground(t == Tool.PENCIL ? BPETheme.ACCENT : BPETheme.TEXT_SECONDARY);
        b.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BPETheme.BORDER),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)));
        b.setFocusPainted(false);
        b.setSelected(t == Tool.PENCIL);
        b.addActionListener(e -> { tool = t; b.setForeground(BPETheme.ACCENT); });
        b.addItemListener(e -> { if (e.getStateChange() == ItemEvent.DESELECTED) b.setForeground(BPETheme.TEXT_SECONDARY); });
        grp.add(b);
        return b;
    }

    // ── main area: sidebar + canvas ───────────────────────────────────────────
    private JPanel buildMain() {
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(BPETheme.BG_DEEPEST);

        // Frame sidebar (left)
        frameSidebar = new JPanel();
        frameSidebar.setLayout(new BoxLayout(frameSidebar, BoxLayout.Y_AXIS));
        frameSidebar.setBackground(BPETheme.BG_DEEP);
        frameSidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, BPETheme.BORDER));
        frameSidebar.setPreferredSize(new Dimension(90, 0));

        JScrollPane sideScroll = new JScrollPane(frameSidebar);
        sideScroll.setBorder(BorderFactory.createEmptyBorder());
        sideScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sideScroll.setPreferredSize(new Dimension(90, 0));
        main.add(sideScroll, BorderLayout.WEST);

        // Drawing canvas (centre) — fills all remaining space
        drawPanel = new DrawPanel();
        main.add(drawPanel, BorderLayout.CENTER);

        refreshSidebar();
        return main;
    }

    // ── colour bar ────────────────────────────────────────────────────────────
    private JPanel buildColorBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        bar.setBackground(BPETheme.BG_MID);
        bar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BPETheme.BORDER));
        bar.add(label("Color:"));

        Color[] presets = {
            Color.BLACK, Color.WHITE,
            new Color(220,60,60),  new Color(60,180,60),  new Color(60,100,220),
            new Color(255,200,30), new Color(255,130,0),  new Color(200,60,200),
            new Color(0,200,220),  new Color(140,90,40),  new Color(140,140,140)
        };
        for (Color c : presets) bar.add(swatch(c));

        JButton pick = new JButton("…");
        pick.setFont(BPETheme.FONT_MONO_SMALL);
        pick.setPreferredSize(new Dimension(26, 20));
        pick.setBackground(BPETheme.BG_RAISED);
        pick.setForeground(BPETheme.TEXT_DIM);
        pick.setBorder(BorderFactory.createLineBorder(BPETheme.BORDER));
        pick.setFocusPainted(false);
        pick.addActionListener(e -> {
            Color c = JColorChooser.showDialog(this, "Pick Color", color);
            if (c != null) { color = c; refreshSwatch(); }
        });
        bar.add(pick);

        bar.add(Box.createHorizontalStrut(8));
        bar.add(label("Active:"));
        activeSwatch = new JLabel("  ");
        activeSwatch.setOpaque(true);
        activeSwatch.setBackground(color);
        activeSwatch.setPreferredSize(new Dimension(22, 20));
        activeSwatch.setBorder(BorderFactory.createLineBorder(BPETheme.BORDER));
        bar.add(activeSwatch);

        return bar;
    }

    // ── frame sidebar ─────────────────────────────────────────────────────────
    private void refreshSidebar() {
        frameSidebar.removeAll();

        // Header row
        JPanel header = new JPanel(new BorderLayout(2, 0));
        header.setBackground(BPETheme.BG_MID);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, BPETheme.BORDER),
            BorderFactory.createEmptyBorder(4, 6, 4, 4)));
        JLabel lbl = new JLabel("Frames");
        lbl.setForeground(BPETheme.TEXT_PRIMARY);
        lbl.setFont(BPETheme.FONT_MONO_BOLD);
        JButton addBtn = new JButton("+");
        addBtn.setFont(BPETheme.FONT_MONO_BOLD);
        addBtn.setForeground(BPETheme.ACCENT);
        addBtn.setBackground(BPETheme.BG_RAISED);
        addBtn.setBorder(BorderFactory.createLineBorder(BPETheme.BORDER));
        addBtn.setPreferredSize(new Dimension(22, 18));
        addBtn.setFocusPainted(false);
        addBtn.setToolTipText("Add frame");
        addBtn.addActionListener(e -> {
            frames.add(blankFrame());
            currentFrame = frames.size() - 1;
            refreshSidebar();
            drawPanel.repaint();
        });
        header.add(lbl, BorderLayout.CENTER);
        header.add(addBtn, BorderLayout.EAST);
        frameSidebar.add(header);

        // One thumbnail per frame
        for (int i = 0; i < frames.size(); i++) {
            final int idx = i;
            JPanel card = buildFrameCard(idx);
            frameSidebar.add(card);
        }

        frameSidebar.add(Box.createVerticalGlue());
        frameSidebar.revalidate();
        frameSidebar.repaint();
    }

    private JPanel buildFrameCard(int idx) {
        boolean selected = idx == currentFrame;

        JPanel card = new JPanel(new BorderLayout(0, 2));
        card.setBackground(selected ? BPETheme.BG_SELECTED : BPETheme.BG_DEEP);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, selected ? 3 : 0, 1, 0,
                selected ? BPETheme.ACCENT : BPETheme.BORDER),
            BorderFactory.createEmptyBorder(4, 6, 4, 6)));
        card.setMaximumSize(new Dimension(90, 80));
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Thumbnail
        JLabel thumb = new JLabel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Checkerboard
                int tw = getWidth(), th = getHeight(), ts = 4;
                for (int ty = 0; ty < th; ty += ts)
                    for (int tx = 0; tx < tw; tx += ts) {
                        g.setColor(((tx/ts + ty/ts) % 2 == 0) ? new Color(200,200,200) : new Color(230,230,230));
                        g.fillRect(tx, ty, ts, ts);
                    }
                g.drawImage(frames.get(idx), 0, 0, tw, th, null);
                if (selected) {
                    g.setColor(BPETheme.ACCENT);
                    ((Graphics2D)g).setStroke(new BasicStroke(2));
                    g.drawRect(1, 1, tw-2, th-2);
                }
            }
        };
        thumb.setPreferredSize(new Dimension(64, 52));
        thumb.setOpaque(false);

        // Label + delete button
        JPanel bottom = new JPanel(new BorderLayout(2, 0));
        bottom.setOpaque(false);
        JLabel numLbl = new JLabel("F" + (idx+1));
        numLbl.setForeground(selected ? BPETheme.ACCENT : BPETheme.TEXT_DIM);
        numLbl.setFont(BPETheme.FONT_MONO_SMALL);

        JButton del = new JButton("×");
        del.setFont(new Font("Consolas", Font.BOLD, 10));
        del.setForeground(BPETheme.TEXT_DIM);
        del.setBackground(BPETheme.BG_RAISED);
        del.setBorder(BorderFactory.createEmptyBorder(0, 3, 0, 3));
        del.setFocusPainted(false);
        del.setToolTipText("Delete frame");
        del.addActionListener(e -> {
            if (frames.size() <= 1) return; // keep at least 1
            frames.remove(idx);
            if (currentFrame >= frames.size()) currentFrame = frames.size() - 1;
            refreshSidebar();
            drawPanel.repaint();
        });

        bottom.add(numLbl, BorderLayout.CENTER);
        bottom.add(del,    BorderLayout.EAST);
        card.add(thumb,  BorderLayout.CENTER);
        card.add(bottom, BorderLayout.SOUTH);

        // Click to switch frame
        MouseAdapter click = new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                currentFrame = idx;
                refreshSidebar();
                drawPanel.repaint();
            }
        };
        card.addMouseListener(click);
        thumb.addMouseListener(click);

        return card;
    }

    // ── drawing ops ───────────────────────────────────────────────────────────
    private void clearFrame(int idx) {
        Graphics2D g = frames.get(idx).createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, CW, CH);
        g.dispose();
    }

    private void floodFill(int x, int y) {
        BufferedImage img = currentCanvas();
        if (x < 0 || x >= CW || y < 0 || y >= CH) return;
        int target = img.getRGB(x, y), fill = color.getRGB();
        if (target == fill) return;
        Queue<Point> q = new LinkedList<>();
        q.add(new Point(x, y));
        while (!q.isEmpty()) {
            Point p = q.poll();
            if (p.x < 0 || p.x >= CW || p.y < 0 || p.y >= CH) continue;
            if (img.getRGB(p.x, p.y) != target) continue;
            img.setRGB(p.x, p.y, fill);
            q.add(new Point(p.x+1,p.y)); q.add(new Point(p.x-1,p.y));
            q.add(new Point(p.x,p.y+1)); q.add(new Point(p.x,p.y-1));
        }
    }

    private void stroke(int x1, int y1, int x2, int y2) {
        Graphics2D g = currentG();
        g.setStroke(new BasicStroke(brush, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.setColor(tool == Tool.ERASER ? Color.WHITE : color);
        if (x1 < 0) { x1 = x2; y1 = y2; }
        g.drawLine(x1, y1, x2, y2);
        g.dispose();
    }

    private void importImage() {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Images","png","jpg","jpeg","bmp"));
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try {
            BufferedImage src = ImageIO.read(fc.getSelectedFile());
            Graphics2D g = currentG();
            g.drawImage(src, 0, 0, CW, CH, null);
            g.dispose();
            drawPanel.repaint();
            refreshSidebar();
        } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage()); }
    }

    private void exportImage() {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("frame" + (currentFrame+1) + ".png"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try {
            File f = fc.getSelectedFile();
            if (!f.getName().endsWith(".png")) f = new File(f.getAbsolutePath() + ".png");
            ImageIO.write(currentCanvas(), "PNG", f);
            JOptionPane.showMessageDialog(this, "Saved: " + f.getName());
        } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage()); }
    }

    public BufferedImage getImage() { return currentCanvas(); }
    public List<BufferedImage> getFrames() { return frames; }

    // ── helpers ───────────────────────────────────────────────────────────────
    private void refreshSwatch() {
        if (activeSwatch != null) { activeSwatch.setBackground(color); activeSwatch.repaint(); }
    }

    private JButton swatch(Color c) {
        JButton b = new JButton();
        b.setBackground(c);
        b.setPreferredSize(new Dimension(20, 20));
        b.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e -> { color = c; refreshSwatch(); });
        return b;
    }

    private JLabel label(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(BPETheme.TEXT_SECONDARY);
        l.setFont(BPETheme.FONT_MONO_SMALL);
        return l;
    }

    private Component sep() { return Box.createHorizontalStrut(6); }

    private String capitalize(String s) {
        return s.isEmpty() ? s : s.charAt(0) + s.substring(1).toLowerCase();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Draw panel — stretches to fill all available space, scales canvas to fit
    // ═════════════════════════════════════════════════════════════════════════
    private class DrawPanel extends JPanel {
        DrawPanel() {
            setBackground(BPETheme.BG_DEEPEST);
            setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));

            addMouseListener(new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) {
                    int cx = toCanvasX(e.getX()), cy = toCanvasY(e.getY());
                    if (tool == Tool.FILL) {
                        floodFill(cx, cy);
                    } else if (tool == Tool.LINE) {
                        lineX0 = cx; lineY0 = cy;
                        lineSnap = copyFrame(currentCanvas());
                    } else {
                        stroke(cx, cy, cx, cy);
                    }
                    lastX = cx; lastY = cy;
                    repaint(); refreshSidebar();
                }
                @Override public void mouseReleased(MouseEvent e) {
                    lastX = -1; lastY = -1; lineSnap = null;
                    refreshSidebar();
                    saveFrames(); // auto-save to project costumes folder
                }
            });

            addMouseMotionListener(new MouseMotionAdapter() {
                @Override public void mouseDragged(MouseEvent e) {
                    int cx = toCanvasX(e.getX()), cy = toCanvasY(e.getY());
                    if (tool == Tool.LINE && lineSnap != null) {
                        // Restore snapshot, draw preview line
                        Graphics2D g = currentG();
                        g.drawImage(lineSnap, 0, 0, null);
                        g.setStroke(new BasicStroke(brush, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                        g.setColor(color);
                        g.drawLine(lineX0, lineY0, cx, cy);
                        g.dispose();
                    } else if (tool != Tool.FILL) {
                        stroke(lastX, lastY, cx, cy);
                    }
                    lastX = cx; lastY = cy;
                    repaint();
                }
            });
        }

        // Scale factor: fit the canvas inside the panel with some padding
        private int scale() {
            int pw = getWidth()  - 20;
            int ph = getHeight() - 20;
            if (pw <= 0 || ph <= 0) return 4;
            return Math.max(1, Math.min(pw / CW, ph / CH));
        }

        // Canvas top-left offset (to centre it)
        private int ox() { return (getWidth()  - CW * scale()) / 2; }
        private int oy() { return (getHeight() - CH * scale()) / 2; }

        // Screen → canvas pixel
        private int toCanvasX(int sx) { return Math.max(0, Math.min(CW-1, (sx - ox()) / scale())); }
        private int toCanvasY(int sy) { return Math.max(0, Math.min(CH-1, (sy - oy()) / scale())); }

        private BufferedImage copyFrame(BufferedImage src) {
            BufferedImage copy = new BufferedImage(CW, CH, BufferedImage.TYPE_INT_ARGB);
            copy.createGraphics().drawImage(src, 0, 0, null);
            return copy;
        }

        @Override
        protected void paintComponent(Graphics g) {
            // Dark surround
            g.setColor(BPETheme.BG_DEEPEST);
            g.fillRect(0, 0, getWidth(), getHeight());

            int sc = scale();
            int ox = ox(), oy = oy();
            int dw = CW * sc, dh = CH * sc;

            // Checkerboard (transparency bg)
            int ts = Math.max(4, sc);
            for (int ty = 0; ty < dh; ty += ts)
                for (int tx = 0; tx < dw; tx += ts) {
                    g.setColor(((tx/ts + ty/ts) % 2 == 0) ? new Color(205,205,205) : new Color(245,245,245));
                    g.fillRect(ox+tx, oy+ty, Math.min(ts, dw-tx), Math.min(ts, dh-ty));
                }

            // Canvas image scaled up
            g.drawImage(currentCanvas(), ox, oy, dw, dh, null);

            // Pixel grid (only when scale is large enough to be readable)
            if (sc >= 6) {
                g.setColor(new Color(0, 0, 0, 30));
                for (int tx = 0; tx <= CW; tx++) g.drawLine(ox + tx*sc, oy, ox + tx*sc, oy+dh);
                for (int ty = 0; ty <= CH; ty++) g.drawLine(ox, oy + ty*sc, ox+dw, oy + ty*sc);
            }

            // Canvas border
            g.setColor(new Color(80, 80, 90));
            ((Graphics2D)g).setStroke(new BasicStroke(1.5f));
            g.drawRect(ox-1, oy-1, dw+2, dh+2);
        }
    }
}
