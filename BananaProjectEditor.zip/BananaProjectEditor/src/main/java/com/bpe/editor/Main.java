package com.bpe.editor;

import com.bpe.ui.BPETheme;
import com.bpe.ui.ProjectExplorer;
import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) {}
            BPETheme.apply();

            // Show splash/auth gate — editor only launches on success
            SplashAuthScreen splash = new SplashAuthScreen(() -> {
                SwingUtilities.invokeLater(() -> {
                    ProjectExplorer explorer = new ProjectExplorer();
                    try { explorer.setIconImage(BPETheme.createBananaIcon(32)); }
                    catch (Exception ignored) {}
                    explorer.setVisible(true);
                });
            });

            // Try auto-login with cached session
            splash.setVisible(true);
            splash.checkCachedSession();
        });
    }
}
