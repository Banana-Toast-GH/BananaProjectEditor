package com.bpe.editor;

import com.bpe.ui.BPETheme;
import com.bpe.ui.ProjectExplorer;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}
            BPETheme.apply();
            ProjectExplorer explorer = new ProjectExplorer();
            explorer.setIconImage(BPETheme.createBananaIcon(32));
            explorer.setVisible(true);
        });
    }
}
