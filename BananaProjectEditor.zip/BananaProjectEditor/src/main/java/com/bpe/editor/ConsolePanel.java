package com.bpe.editor;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;

public class ConsolePanel extends JPanel {

    private static final Color BG = new Color(25, 25, 25);
    private static final Color TEXT = new Color(200, 200, 200);
    private static final Color WARN = new Color(220, 180, 60);
    private static final Color ERROR = new Color(220, 80, 80);
    private static final Color INFO = new Color(100, 180, 255);
    private static final Color HEADER_BG = new Color(35, 35, 35);

    private JTextPane console;

    public ConsolePanel() {
        setLayout(new BorderLayout());
        setBackground(BG);
        setPreferredSize(new Dimension(0, 140));

        // Header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(HEADER_BG);
        header.setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));

        JLabel title = new JLabel("Console");
        title.setForeground(new Color(160, 160, 160));
        title.setFont(new Font("Monospaced", Font.PLAIN, 11));
        header.add(title, BorderLayout.WEST);

        JButton clearBtn = new JButton("Clear");
        clearBtn.setFont(new Font("Monospaced", Font.PLAIN, 10));
        clearBtn.setForeground(new Color(140, 140, 140));
        clearBtn.setBackground(HEADER_BG);
        clearBtn.setBorder(BorderFactory.createEmptyBorder(1, 6, 1, 6));
        clearBtn.setFocusPainted(false);
        clearBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        clearBtn.addActionListener(e -> clear());
        header.add(clearBtn, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // Console output
        console = new JTextPane();
        console.setEditable(false);
        console.setBackground(BG);
        console.setForeground(TEXT);
        console.setFont(new Font("Monospaced", Font.PLAIN, 11));
        console.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));

        JScrollPane scroll = new JScrollPane(console);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setBackground(BG);
        scroll.getViewport().setBackground(BG);
        add(scroll, BorderLayout.CENTER);

        log("Banana Project Editor ready.");
        log("BPE " + com.bpe.Version.get() + " | LuaJ runtime loaded.");
    }

    public void log(String message) {
        appendStyled("[INFO] " + message + "\n", INFO);
    }

    public void warn(String message) {
        appendStyled("[WARN] " + message + "\n", WARN);
    }

    public void error(String message) {
        appendStyled("[ERROR] " + message + "\n", ERROR);
    }

    public void print(String message) {
        appendStyled(message + "\n", TEXT);
    }

    private void appendStyled(String text, Color color) {
        StyledDocument doc = console.getStyledDocument();
        SimpleAttributeSet style = new SimpleAttributeSet();
        StyleConstants.setForeground(style, color);
        try {
            doc.insertString(doc.getLength(), text, style);
            console.setCaretPosition(doc.getLength());
        } catch (BadLocationException ignored) {}
    }

    public void clear() {
        console.setText("");
    }
}
