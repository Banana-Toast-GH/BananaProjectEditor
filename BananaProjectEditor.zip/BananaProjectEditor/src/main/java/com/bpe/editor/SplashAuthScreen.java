package com.bpe.editor;

import com.bpe.ui.BPETheme;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.prefs.Preferences;

/**
 * Full-screen splash that gates ALL of BPE behind a PlayFab account.
 * - Shows animated banana logo + version
 * - Login tab: username + auto-login if session cached
 * - Register tab: username + email
 * - On success: syncs PlayFab User Data (tokens, plan, password hash)
 * - Records a login event to PlayFab
 * - Calls onSuccess.run() to launch the editor
 */
public class SplashAuthScreen extends JFrame {

    // ── PlayFab ───────────────────────────────────────────────────────────────
    private static final String TITLE_ID    = "120204";
    private static final String PLAYFAB_URL = "https://" + TITLE_ID + ".playfabapi.com";

    // Prefs keys
    private static final String PREF_USERNAME = "bpe_pf_user";
    private static final String PREF_SESSION  = "bpe_pf_session";
    private static final String PREF_DISPLAY  = "bpe_pf_display";
    private static final String PREF_GENPASS  = "bpe_pf_gp";
    private static final String PREF_PFID     = "bpe_pf_id";  // actual PlayFab ID (e.g. "A1B2C3D4")

    // ── Colors ────────────────────────────────────────────────────────────────
    private static final Color BG       = new Color(12, 12, 15);
    private static final Color BG_CARD  = new Color(20, 20, 26);
    private static final Color BG_INPUT = new Color(28, 28, 36);
    private static final Color ACCENT   = new Color(255, 200, 30);
    private static final Color TEXT     = new Color(225, 225, 232);
    private static final Color DIM      = new Color(110, 110, 125);
    private static final Color MUTED    = new Color(55, 55, 68);
    private static final Color RED      = new Color(220, 65, 65);
    private static final Color GREEN    = new Color(60, 200, 100);
    private static final Color BORDER   = new Color(35, 35, 46);

    // ── State ─────────────────────────────────────────────────────────────────
    private final Runnable onSuccess;
    private boolean loginMode = true;

    // UI refs
    private JTextField    usernameField;
    private JPasswordField passwordField;
    private JLabel        passwordLabel;
    private JTextField    emailField;
    private JLabel        emailLabel;
    private JLabel        statusLabel;
    private JButton       actionBtn;
    private JButton       switchBtn;
    private JLabel        switchQuestion;
    private JPanel        cardPanel;
    private JLabel        loadingLabel;
    private Timer         pulseTimer;
    private float         pulseAlpha = 0f;
    private boolean       pulseDir   = true;

    public SplashAuthScreen(Runnable onSuccess) {
        this.onSuccess = onSuccess;
        setUndecorated(true);
        setSize(520, 620);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setBackground(BG);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());

        add(buildLeft(),   BorderLayout.WEST);
        add(buildRight(),  BorderLayout.CENTER);

        // Close button top-right
        JButton close = new JButton("✕");
        close.setBackground(BG);
        close.setForeground(MUTED);
        close.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        close.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        close.setFocusPainted(false);
        close.setContentAreaFilled(false);
        close.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        close.addActionListener(e -> System.exit(0));
        close.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { close.setForeground(RED); }
            public void mouseExited(MouseEvent e)  { close.setForeground(MUTED); }
        });
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        topBar.add(close, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // Drag to move
        Point[] dragStart = {null};
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e)  { dragStart[0] = e.getPoint(); }
            public void mouseReleased(MouseEvent e) { dragStart[0] = null; }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                if (dragStart[0] != null) {
                    Point loc = getLocation();
                    setLocation(loc.x + e.getX() - dragStart[0].x,
                                loc.y + e.getY() - dragStart[0].y);
                }
            }
        });
    }

    // ── Left panel — branding ─────────────────────────────────────────────────
    private JPanel buildLeft() {
        JPanel p = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // Gradient bg
                GradientPaint gp = new GradientPaint(0, 0, new Color(22, 18, 5),
                    0, getHeight(), new Color(12, 12, 15));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                // Subtle vertical line on right
                g2.setColor(BORDER);
                g2.drawLine(getWidth() - 1, 0, getWidth() - 1, getHeight());
            }
        };
        p.setPreferredSize(new Dimension(190, 0));
        p.setLayout(new GridBagLayout());

        JPanel inner = new JPanel();
        inner.setOpaque(false);
        inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));

        // Big banana icon
        JLabel bananaIcon = new JLabel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image img = BananaAIPanel.makeBananaIcon(72);
                g.drawImage(img, 0, 0, this);
            }
        };
        bananaIcon.setPreferredSize(new Dimension(72, 72));
        bananaIcon.setMinimumSize(new Dimension(72, 72));
        bananaIcon.setMaximumSize(new Dimension(72, 72));
        bananaIcon.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("BPE");
        title.setFont(new Font("Segoe UI", Font.BOLD, 32));
        title.setForeground(ACCENT);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Banana Project");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub.setForeground(DIM);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub2 = new JLabel("Editor");
        sub2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub2.setForeground(DIM);
        sub2.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel ver = new JLabel("v0.4.5");
        ver.setFont(new Font("Consolas", Font.PLAIN, 11));
        ver.setForeground(MUTED);
        ver.setAlignmentX(Component.CENTER_ALIGNMENT);

        inner.add(Box.createVerticalGlue());
        inner.add(bananaIcon);
        inner.add(Box.createVerticalStrut(14));
        inner.add(title);
        inner.add(Box.createVerticalStrut(4));
        inner.add(sub);
        inner.add(sub2);
        inner.add(Box.createVerticalStrut(10));
        inner.add(ver);
        inner.add(Box.createVerticalGlue());

        p.add(inner);
        return p;
    }

    // ── Right panel — auth form ───────────────────────────────────────────────
    private JPanel buildRight() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(BG);

        cardPanel = new JPanel();
        cardPanel.setBackground(BG_CARD);
        cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS));
        cardPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER, 1, true),
            BorderFactory.createEmptyBorder(28, 28, 28, 28)
        ));

        // Title
        JLabel formTitle = new JLabel("Sign In");
        formTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        formTitle.setForeground(TEXT);
        formTitle.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel formSub = new JLabel("Access Banana Project Editor");
        formSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        formSub.setForeground(DIM);
        formSub.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Username
        JLabel userLbl = fieldLabel("Username");
        usernameField  = styledField();

        // Password (optional — only needed if local credentials lost)
        passwordLabel = fieldLabel("Password  (only needed if you've lost your local credentials)");
        passwordField = new JPasswordField();
        passwordField.setBackground(BG_INPUT);
        passwordField.setForeground(TEXT);
        passwordField.setCaretColor(ACCENT);
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER, 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        passwordField.addActionListener(e -> doAction());

        // Email (register only)
        emailLabel = fieldLabel("Email");
        emailField = styledField();
        emailLabel.setVisible(false);
        emailField.setVisible(false);

        // Status
        statusLabel = new JLabel(" ");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        statusLabel.setForeground(RED);
        statusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Action button
        actionBtn = accentBtn("Sign In");
        actionBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        actionBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        actionBtn.addActionListener(e -> doAction());

        // Switch row
        JPanel switchRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        switchRow.setOpaque(false);
        switchRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        switchQuestion = new JLabel("Don't have an account? ");
        switchQuestion.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        switchQuestion.setForeground(DIM);
        switchBtn = linkBtn("Create one");
        switchBtn.addActionListener(e -> toggleMode(formTitle));
        switchRow.add(switchQuestion);
        switchRow.add(switchBtn);

        // Loading label
        loadingLabel = new JLabel(" ");
        loadingLabel.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        loadingLabel.setForeground(DIM);
        loadingLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        cardPanel.add(formTitle);
        cardPanel.add(Box.createVerticalStrut(4));
        cardPanel.add(formSub);
        cardPanel.add(Box.createVerticalStrut(22));
        cardPanel.add(userLbl);
        cardPanel.add(Box.createVerticalStrut(5));
        cardPanel.add(usernameField);
        cardPanel.add(Box.createVerticalStrut(14));
        cardPanel.add(passwordLabel);
        cardPanel.add(Box.createVerticalStrut(5));
        cardPanel.add(passwordField);
        cardPanel.add(Box.createVerticalStrut(14));
        cardPanel.add(emailLabel);
        cardPanel.add(Box.createVerticalStrut(5));
        cardPanel.add(emailField);
        cardPanel.add(Box.createVerticalStrut(14));
        cardPanel.add(statusLabel);
        cardPanel.add(Box.createVerticalStrut(10));
        cardPanel.add(actionBtn);
        cardPanel.add(Box.createVerticalStrut(8));
        cardPanel.add(loadingLabel);
        cardPanel.add(Box.createVerticalStrut(16));
        cardPanel.add(switchRow);

        p.add(cardPanel);
        return p;
    }

    private void toggleMode(JLabel formTitle) {
        loginMode = !loginMode;
        formTitle.setText(loginMode ? "Sign In" : "Create Account");
        emailLabel.setVisible(!loginMode);
        emailField.setVisible(!loginMode);
        // Password field only shown in login mode (hidden in register since password is auto-generated)
        passwordLabel.setVisible(loginMode);
        passwordField.setVisible(loginMode);
        actionBtn.setText(loginMode ? "Sign In" : "Create Account");
        switchQuestion.setText(loginMode ? "Don't have an account? " : "Already have one? ");
        switchBtn.setText(loginMode ? "Create one" : "Sign in");
        statusLabel.setText(" ");
        cardPanel.revalidate();
        cardPanel.repaint();
    }

    // ── Auth logic ────────────────────────────────────────────────────────────
    public void checkCachedSession() {
        String cached = prefs().get(PREF_USERNAME, "");
        String session = prefs().get(PREF_SESSION, "");
        if (cached.isEmpty() || session.isEmpty()) return;

        // Auto-login with cached session
        setLoading("Signing in as " + cached + "...");
        new Thread(() -> {
            try {
                // Validate session with a lightweight call
                String resp = postWithSession("/Client/GetPlayerCombinedInfo", "{\"InfoRequestParameters\":{\"GetUserAccountInfo\":true}}", session);
                if (resp.contains("\"AccountInfo\"")) {
                    syncUserDataAndLaunch(cached, session, prefs().get(PREF_DISPLAY, cached));
                } else {
                    // Session expired — clear and show form
                    SwingUtilities.invokeLater(() -> {
                        clearPrefs();
                        setLoading(" ");
                        statusLabel.setText("Session expired. Please sign in again.");
                    });
                }
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> setLoading(" "));
            }
        }).start();
    }

    private void doAction() {
        String username = usernameField.getText().trim();
        if (username.isEmpty()) { statusLabel.setText("Username is required."); statusLabel.setForeground(RED); return; }

        actionBtn.setEnabled(false);
        statusLabel.setText(" ");

        if (loginMode) {
            setLoading("Signing in...");
            new Thread(() -> doLogin(username)).start();
        } else {
            String email = emailField.getText().trim();
            if (email.isEmpty()) {
                SwingUtilities.invokeLater(() -> { statusLabel.setText("Email is required."); statusLabel.setForeground(RED); actionBtn.setEnabled(true); setLoading(" "); });
                return;
            }
            setLoading("Creating account...");
            new Thread(() -> doRegister(username, email)).start();
        }
    }

    private void doLogin(String username) {
        try {
            String storedPass = prefs().get(PREF_GENPASS, "");
            // If no stored password, use whatever was typed in the password field
            String typedPass  = new String(passwordField.getPassword()).trim();
            String passToUse  = !storedPass.isEmpty() ? storedPass : typedPass;

            if (passToUse.isEmpty()) {
                SwingUtilities.invokeLater(() -> {
                    setLoading(" ");
                    statusLabel.setText("Enter your password to sign in.");
                    statusLabel.setForeground(RED);
                    actionBtn.setEnabled(true);
                });
                return;
            }

            String resp = post("/Client/LoginWithPlayFab",
                "{\"Username\":\"" + esc(username) + "\","
                + "\"Password\":\"" + esc(passToUse) + "\","
                + "\"TitleId\":\"" + TITLE_ID + "\"}");

            if (resp.contains("\"SessionTicket\"")) {
                String session  = extractJson(resp, "SessionTicket");
                String pfId     = extractJson(resp, "PlayFabId");
                prefs().put(PREF_USERNAME, username);
                prefs().put(PREF_SESSION,  session != null ? session : "");
                prefs().put(PREF_DISPLAY,  username);
                // If login succeeded with a typed password, save it for future use
                if (storedPass.isEmpty() && !typedPass.isEmpty()) {
                    prefs().put(PREF_GENPASS, typedPass);
                }
                if (pfId != null) prefs().put(PREF_PFID, pfId);
                syncUserDataAndLaunch(username, session, username);
            } else {
                handleAuthError(resp);
            }
        } catch (Exception ex) {
            SwingUtilities.invokeLater(() -> { setLoading(" "); showError("Connection error: " + ex.getMessage()); actionBtn.setEnabled(true); });
        }
    }

    private void doRegister(String username, String email) {
        try {
            // Generate internal password
            String genPass = java.util.UUID.randomUUID().toString().replace("-","") + "Bpe!1";
            String passHash = sha256(genPass);

            String resp = post("/Client/RegisterPlayFabUser",
                "{\"Username\":\"" + esc(username) + "\","
                + "\"Password\":\"" + esc(genPass) + "\","
                + "\"Email\":\"" + esc(email) + "\","
                + "\"TitleId\":\"" + TITLE_ID + "\","
                + "\"RequireBothUsernameAndEmail\":true}");

            if (resp.contains("\"SessionTicket\"")) {
                String session = extractJson(resp, "SessionTicket");
                String pfId    = extractJson(resp, "PlayFabId");

                // Store locally
                prefs().put(PREF_USERNAME, username);
                prefs().put(PREF_SESSION,  session != null ? session : "");
                prefs().put(PREF_DISPLAY,  username);
                prefs().put(PREF_GENPASS,  genPass);
                if (pfId != null) prefs().put(PREF_PFID, pfId);

                // Write initial User Data to PlayFab
                setLoading("Setting up your account...");
                writeInitialUserData(session, username, passHash);

                syncUserDataAndLaunch(username, session, username);
            } else {
                handleAuthError(resp);
            }
        } catch (Exception ex) {
            SwingUtilities.invokeLater(() -> { setLoading(" "); showError("Error: " + ex.getMessage()); actionBtn.setEnabled(true); });
        }
    }

    // ── PlayFab User Data ─────────────────────────────────────────────────────

    /** Write initial User Data on first registration */
    private void writeInitialUserData(String session, String username, String passHash) throws Exception {
        String payload = "{"
            + "\"Data\":{"
            + "\"plan\":\"free\","
            + "\"generative_tokens\":\"5000\","
            + "\"creation_tokens\":\"2500\","
            + "\"password_hash\":\"" + passHash + "\","
            + "\"registered_at\":\"" + System.currentTimeMillis() + "\","
            + "\"login_count\":\"0\""
            + "}}";
        postWithSession("/Client/UpdateUserData", payload, session);
    }

    /** Sync User Data on login — reads plan/tokens, increments login count, records login time */
    private void syncUserDataAndLaunch(String username, String session, String display) {
        try {
            setLoading("Loading your account...");

            // Resolve PlayFab ID if not yet stored (needed for server-side API calls)
            String pfId = prefs().get(PREF_PFID, "");
            if (pfId.isEmpty()) {
                // Use GetPlayerCombinedInfo to get the PlayFabId
                String infoResp = postWithSession("/Client/GetPlayerCombinedInfo",
                    "{\"InfoRequestParameters\":{\"GetUserAccountInfo\":true}}", session);
                String resolved = extractJson(infoResp, "PlayFabId");
                if (resolved != null && !resolved.isEmpty()) {
                    pfId = resolved;
                    prefs().put(PREF_PFID, pfId);
                } else {
                    pfId = username; // last resort fallback
                }
            }
            prefs().put(PREF_PFID, pfId);

            // Read User Data
            String resp = postWithSession("/Client/GetUserData",
                "{\"Keys\":[\"plan\",\"generative_tokens\",\"creation_tokens\",\"login_count\",\"banned\"]}",
                session);

            // Check banned flag
            if (extractUserDataValue(resp, "banned") != null &&
                extractUserDataValue(resp, "banned").equals("true")) {
                SwingUtilities.invokeLater(() -> {
                    clearPrefs();
                    JOptionPane.showMessageDialog(this,
                        "<html><b>Your account has been banned.</b><br>You cannot use Banana Project Editor.</html>",
                        "Banned", JOptionPane.ERROR_MESSAGE);
                    System.exit(0);
                });
                return;
            }

            // Parse values
            String plan   = extractUserDataValue(resp, "plan");
            String genTok = extractUserDataValue(resp, "generative_tokens");
            String crtTok = extractUserDataValue(resp, "creation_tokens");
            String loginCount = extractUserDataValue(resp, "login_count");
            int newCount = 1;
            try { newCount = Integer.parseInt(loginCount) + 1; } catch (Exception ignored) {}

            // If no user data yet (old account), write defaults
            if (plan == null) {
                writeInitialUserData(session, username, "");
                plan   = "free";
                genTok = "5000";
                crtTok = "2500";
            }

            // Record this login
            final int loginNum = newCount;
            new Thread(() -> {
                try {
                    postWithSession("/Client/UpdateUserData",
                        "{\"Data\":{"
                        + "\"login_count\":\"" + loginNum + "\","
                        + "\"last_login\":\"" + System.currentTimeMillis() + "\""
                        + "}}",
                        session);
                } catch (Exception ignored) {}
            }).start();

            // Cache values in prefs for offline/quick access
            final String fPlan = plan != null ? plan : "free";
            final String fGen  = genTok != null ? genTok : "5000";
            final String fCrt  = crtTok != null ? crtTok : "2500";
            final String fUser = username;
            final String fSess = session;
            final String fDisp = display;

            prefs().put("bpe_plan",   fPlan);
            prefs().put("bpe_gen",    fGen);
            prefs().put("bpe_crt",    fCrt);

            SwingUtilities.invokeLater(() -> {
                setLoading("Welcome back, " + fUser + "!");
                // Brief pause then launch
                Timer t = new Timer(700, e -> {
                    dispose();
                    onSuccess.run();
                });
                t.setRepeats(false);
                t.start();
            });

        } catch (Exception ex) {
            // Network down — allow offline launch with cached data
            SwingUtilities.invokeLater(() -> {
                setLoading("Offline mode — using cached account.");
                Timer t = new Timer(1200, e -> { dispose(); onSuccess.run(); });
                t.setRepeats(false);
                t.start();
            });
        }
    }

    private void handleAuthError(String resp) {
        String err = extractJson(resp, "errorMessage");
        if (err == null) err = extractJson(resp, "error");
        boolean banned = err != null && err.toLowerCase().contains("ban");
        final String msg = err != null ? err : "Authentication failed.";
        final boolean isBanned = banned;
        SwingUtilities.invokeLater(() -> {
            setLoading(" ");
            actionBtn.setEnabled(true);
            if (isBanned) {
                clearPrefs();
                JOptionPane.showMessageDialog(this,
                    "<html><b>Your account has been banned.</b><br>You cannot use BPE.</html>",
                    "Banned", JOptionPane.ERROR_MESSAGE);
                System.exit(0);
            } else {
                showError(msg);
            }
        });
    }

    // ── HTTP ─────────────────────────────────────────────────────────────────
    private String post(String endpoint, String payload) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(PLAYFAB_URL + endpoint).openConnection();
        c.setRequestMethod("POST");
        c.setRequestProperty("Content-Type", "application/json");
        c.setDoOutput(true);
        c.setConnectTimeout(12000);
        c.setReadTimeout(12000);
        c.getOutputStream().write(payload.getBytes(StandardCharsets.UTF_8));
        InputStream is = (c.getResponseCode() < 400) ? c.getInputStream() : c.getErrorStream();
        return new String(is.readAllBytes(), StandardCharsets.UTF_8);
    }

    private String postWithSession(String endpoint, String payload, String session) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(PLAYFAB_URL + endpoint).openConnection();
        c.setRequestMethod("POST");
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("X-Authorization", session);
        c.setDoOutput(true);
        c.setConnectTimeout(12000);
        c.setReadTimeout(12000);
        c.getOutputStream().write(payload.getBytes(StandardCharsets.UTF_8));
        InputStream is = (c.getResponseCode() < 400) ? c.getInputStream() : c.getErrorStream();
        return new String(is.readAllBytes(), StandardCharsets.UTF_8);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private String extractJson(String json, String key) {
        if (json == null) return null;
        String s = "\"" + key + "\":";
        int i = json.indexOf(s);
        if (i < 0) return null;
        i += s.length();
        while (i < json.length() && json.charAt(i) == ' ') i++;
        if (i >= json.length()) return null;
        if (json.charAt(i) == '"') {
            StringBuilder sb = new StringBuilder();
            int end = i + 1;
            while (end < json.length() && json.charAt(end) != '"') {
                if (json.charAt(end) == '\\' && end + 1 < json.length()) end += 2;
                else sb.append(json.charAt(end++));
            }
            return sb.toString();
        }
        int end = i;
        while (end < json.length() && ",}\n".indexOf(json.charAt(end)) < 0) end++;
        return json.substring(i, end).trim();
    }

    /**
     * Extract value from PlayFab GetUserData response.
     * Structure: "Data":{"key":{"Value":"..."}}
     */
    private String extractUserDataValue(String json, String key) {
        if (json == null) return null;
        String s = "\"" + key + "\":{\"Value\":\"";
        int i = json.indexOf(s);
        if (i < 0) return null;
        i += s.length();
        int end = json.indexOf("\"", i);
        if (end < 0) return null;
        return json.substring(i, end);
    }

    private String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return input; }
    }

    private void setLoading(String msg) {
        loadingLabel.setText(msg);
    }

    private void showError(String msg) {
        statusLabel.setText(msg);
        statusLabel.setForeground(RED);
    }

    private static Preferences prefs() {
        return Preferences.userNodeForPackage(SplashAuthScreen.class);
    }

    private static void clearPrefs() {
        Preferences p = prefs();
        p.remove(PREF_USERNAME);
        p.remove(PREF_SESSION);
        p.remove(PREF_DISPLAY);
        p.remove(PREF_GENPASS);
        p.remove(PREF_PFID);
    }

    // ── Static helpers for rest of app ────────────────────────────────────────
    public static String getCachedUsername()   { return nullIfEmpty(prefs().get(PREF_USERNAME, "")); }
    public static String getCachedSession()    { return nullIfEmpty(prefs().get(PREF_SESSION,  "")); }
    public static String getCachedDisplayName(){ return nullIfEmpty(prefs().get(PREF_DISPLAY,  "")); }
    public static String getCachedPlayFabId()  { return nullIfEmpty(prefs().get(PREF_PFID,     "")); }
    public static String getCachedPlan()       { return prefs().get("bpe_plan", "free"); }
    public static int    getCachedGenTokens()  { try { return Integer.parseInt(prefs().get("bpe_gen","5000")); } catch(Exception e){return 5000;} }
    public static int    getCachedCrtTokens()  { try { return Integer.parseInt(prefs().get("bpe_crt","2500")); } catch(Exception e){return 2500;} }

    private static String nullIfEmpty(String s) { return (s == null || s.isEmpty()) ? null : s; }

    // ── UI factories ──────────────────────────────────────────────────────────
    private JLabel fieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        l.setForeground(DIM);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private JTextField styledField() {
        JTextField f = new JTextField();
        f.setBackground(BG_INPUT);
        f.setForeground(TEXT);
        f.setCaretColor(ACCENT);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER, 1),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        f.setAlignmentX(Component.LEFT_ALIGNMENT);
        f.addActionListener(e -> doAction());
        // Focus glow effect
        f.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) { f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(ACCENT.getRed(), ACCENT.getGreen(), ACCENT.getBlue(), 160), 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10))); }
            public void focusLost(FocusEvent e) { f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                BorderFactory.createEmptyBorder(8, 10, 8, 10))); }
        });
        return f;
    }

    private JButton accentBtn(String text) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) g2.setColor(ACCENT.darker());
                else if (getModel().isRollover()) g2.setColor(ACCENT.brighter());
                else g2.setColor(ACCENT);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                g2.setColor(new Color(15, 15, 18));
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                int tx = (getWidth() - fm.stringWidth(getText())) / 2;
                int ty = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g2.drawString(getText(), tx, ty);
            }
        };
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setContentAreaFilled(false);
        b.setOpaque(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private JButton linkBtn(String text) {
        JButton b = new JButton(text);
        b.setBackground(null);
        b.setForeground(ACCENT);
        b.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setContentAreaFilled(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
}
