package com.bpe.editor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.prefs.Preferences;

/**
 * Lightweight PlayFab auth dialog used by BananaAIPanel.
 * Delegates entirely to the credentials already stored by SplashAuthScreen.
 * If there's no cached session, sends the user back to restart BPE.
 *
 * Login: username + stored generated password (LoginWithPlayFab)
 * Register: username + email (same flow as SplashAuthScreen)
 */
public class PlayFabAuthDialog extends JDialog {

    private static final String TITLE_ID    = "120204";
    private static final String PLAYFAB_URL = "https://" + TITLE_ID + ".playfabapi.com";

    // Share the same prefs keys as SplashAuthScreen so credentials are unified
    private static final String PREF_USERNAME = "bpe_pf_user";
    private static final String PREF_SESSION  = "bpe_pf_session";
    private static final String PREF_DISPLAY  = "bpe_pf_display";
    private static final String PREF_GENPASS  = "bpe_pf_gp";
    private static final String PREF_PFID     = "bpe_pf_id";

    private static final Color BG      = new Color(15, 15, 18);
    private static final Color BG_MID  = new Color(22, 22, 28);
    private static final Color ACCENT  = new Color(255, 200, 30);
    private static final Color TEXT    = new Color(225, 225, 232);
    private static final Color DIM     = new Color(115, 115, 130);
    private static final Color RED     = new Color(220, 65, 65);
    private static final Color GREEN   = new Color(60, 200, 100);
    private static final Color BORDER  = new Color(38, 38, 50);

    private boolean success       = false;
    private String  resultUser    = null;
    private String  resultSession = null;
    private String  resultDisplay = null;

    private JTextField  usernameField;
    private JPasswordField passwordField;
    private JLabel      passwordLabel;
    private JTextField  emailField;
    private JLabel      emailLabel;
    private JLabel      statusLabel;
    private JButton     actionBtn;
    private JButton     switchBtn;
    private JLabel      questionLabel;
    private JPasswordField sessionDisplay;
    private boolean     isRegisterMode = false;

    public PlayFabAuthDialog(Frame owner) {
        super(owner, "BananaAI — Sign In", true);
        setSize(400, 460);
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());
        add(buildHeader(), BorderLayout.NORTH);
        add(buildBody(),   BorderLayout.CENTER);
        add(buildFooter(), BorderLayout.SOUTH);
    }

    private JPanel buildHeader() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 16));
        p.setBackground(BG_MID);
        p.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER));
        JLabel icon = new JLabel(new ImageIcon(BananaAIPanel.makeBananaIcon(28)));
        JLabel title = new JLabel("BananaAI");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(ACCENT);
        JLabel sub = new JLabel("Sign in to continue");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sub.setForeground(DIM);
        JPanel txt = new JPanel();
        txt.setOpaque(false);
        txt.setLayout(new BoxLayout(txt, BoxLayout.Y_AXIS));
        txt.add(title);
        txt.add(sub);
        p.add(icon);
        p.add(txt);
        return p;
    }

    private JPanel buildBody() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(BG);
        outer.setBorder(BorderFactory.createEmptyBorder(18, 24, 10, 24));

        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        form.add(lbl("Username"));
        form.add(Box.createVerticalStrut(4));
        usernameField = field();
        form.add(usernameField);
        form.add(Box.createVerticalStrut(12));

        passwordLabel = lbl("Password  (leave blank if credentials are saved)");
        form.add(passwordLabel);
        form.add(Box.createVerticalStrut(4));
        passwordField = new JPasswordField();
        passwordField.setBackground(new Color(25, 25, 32));
        passwordField.setForeground(TEXT);
        passwordField.setCaretColor(ACCENT);
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        passwordField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        passwordField.setAlignmentX(Component.LEFT_ALIGNMENT);
        passwordField.addActionListener(e -> doAction());
        form.add(passwordField);
        form.add(Box.createVerticalStrut(12));

        emailLabel = lbl("Email");
        emailLabel.setVisible(false);
        form.add(emailLabel);
        form.add(Box.createVerticalStrut(4));
        emailField = field();
        emailField.setVisible(false);
        form.add(emailField);
        form.add(Box.createVerticalStrut(12));

        // Read-only session key display
        form.add(lbl("Session Key (read-only)"));
        form.add(Box.createVerticalStrut(4));
        sessionDisplay = new JPasswordField(getCachedSession() != null ? "●●●●●●●●●●●●●●●●" : "No session yet");
        sessionDisplay.setEchoChar((char)0);
        sessionDisplay.setEditable(false);
        sessionDisplay.setBackground(new Color(20, 20, 26));
        sessionDisplay.setForeground(getCachedSession() != null ? GREEN : DIM);
        sessionDisplay.setFont(new Font("Consolas", Font.PLAIN, 11));
        sessionDisplay.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)));
        sessionDisplay.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        sessionDisplay.setAlignmentX(Component.LEFT_ALIGNMENT);
        form.add(sessionDisplay);
        form.add(Box.createVerticalStrut(14));

        statusLabel = new JLabel(" ");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        statusLabel.setForeground(RED);
        statusLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        form.add(statusLabel);
        form.add(Box.createVerticalStrut(10));

        actionBtn = accentButton("Sign In");
        actionBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        actionBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        actionBtn.addActionListener(e -> doAction());
        form.add(actionBtn);

        outer.add(form, BorderLayout.NORTH);
        return outer;
    }

    private JPanel buildFooter() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 8));
        p.setBackground(BG);
        p.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER));
        questionLabel = new JLabel("Don't have an account?");
        questionLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        questionLabel.setForeground(DIM);
        switchBtn = new JButton("Create one");
        switchBtn.setBackground(null);
        switchBtn.setForeground(ACCENT);
        switchBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        switchBtn.setBorderPainted(false);
        switchBtn.setFocusPainted(false);
        switchBtn.setContentAreaFilled(false);
        switchBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        switchBtn.addActionListener(e -> toggleMode());
        p.add(questionLabel);
        p.add(switchBtn);
        return p;
    }

    private void toggleMode() {
        isRegisterMode = !isRegisterMode;
        emailLabel.setVisible(isRegisterMode);
        emailField.setVisible(isRegisterMode);
        // Password only shown in login (register uses auto-generated password)
        passwordLabel.setVisible(!isRegisterMode);
        passwordField.setVisible(!isRegisterMode);
        actionBtn.setText(isRegisterMode ? "Create Account" : "Sign In");
        setTitle(isRegisterMode ? "BananaAI — Create Account" : "BananaAI — Sign In");
        questionLabel.setText(isRegisterMode ? "Already have an account? " : "Don't have an account?");
        switchBtn.setText(isRegisterMode ? "Sign in" : "Create one");
        statusLabel.setText(" ");
        pack();
        setSize(400, isRegisterMode ? 480 : 500);
    }

    private void doAction() {
        String username = usernameField.getText().trim();
        if (username.isEmpty()) { setStatus("Username is required.", false); return; }

        actionBtn.setEnabled(false);
        actionBtn.setText(isRegisterMode ? "Creating..." : "Signing in...");
        setStatus("Connecting...", null);

        new Thread(() -> {
            try {
                if (isRegisterMode) {
                    String email = emailField.getText().trim();
                    if (email.isEmpty()) {
                        SwingUtilities.invokeLater(() -> { setStatus("Email is required.", false); resetBtn(); });
                        return;
                    }
                    doRegister(username, email);
                } else {
                    doLogin(username);
                }
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> { setStatus("Error: " + ex.getMessage(), false); resetBtn(); });
            }
        }).start();
    }

    private void doLogin(String username) throws Exception {
        String storedPass = prefs().get(PREF_GENPASS, "");
        String typedPass  = new String(passwordField.getPassword()).trim();
        String passToUse  = !storedPass.isEmpty() ? storedPass : typedPass;

        if (passToUse.isEmpty()) {
            SwingUtilities.invokeLater(() -> {
                setStatus("Enter your password to sign in.", false);
                resetBtn();
            });
            return;
        }

        String resp = post("/Client/LoginWithPlayFab",
            "{\"Username\":\"" + esc(username) + "\","
            + "\"Password\":\"" + esc(passToUse) + "\","
            + "\"TitleId\":\"" + TITLE_ID + "\"}");

        if (resp.contains("\"SessionTicket\"")) {
            String session = extractJson(resp, "SessionTicket");
            String pfId    = extractJson(resp, "PlayFabId");
            prefs().put(PREF_USERNAME, username);
            prefs().put(PREF_SESSION,  session != null ? session : "");
            prefs().put(PREF_DISPLAY,  username);
            // Save the working password for future use
            if (storedPass.isEmpty() && !typedPass.isEmpty()) {
                prefs().put(PREF_GENPASS, typedPass);
            }
            if (pfId != null) prefs().put(PREF_PFID, pfId);
            succeed(username, session, username);
        } else {
            String err = extractJson(resp, "errorMessage");
            if (err == null) err = "Login failed. Check your username and password.";
            final String msg = err;
            SwingUtilities.invokeLater(() -> { setStatus(msg, false); resetBtn(); });
        }
    }

    private void doRegister(String username, String email) throws Exception {
        // Generate internal password — same approach as SplashAuthScreen
        String genPass = java.util.UUID.randomUUID().toString().replace("-","") + "Bpe!1";

        String resp = post("/Client/RegisterPlayFabUser",
            "{\"Username\":\"" + esc(username) + "\","
            + "\"Password\":\"" + esc(genPass) + "\","
            + "\"Email\":\"" + esc(email) + "\","
            + "\"TitleId\":\"" + TITLE_ID + "\","
            + "\"RequireBothUsernameAndEmail\":true}");

        if (resp.contains("\"SessionTicket\"")) {
            String session = extractJson(resp, "SessionTicket");
            String pfId    = extractJson(resp, "PlayFabId");
            prefs().put(PREF_USERNAME, username);
            prefs().put(PREF_SESSION,  session != null ? session : "");
            prefs().put(PREF_DISPLAY,  username);
            prefs().put(PREF_GENPASS,  genPass);
            if (pfId != null) prefs().put(PREF_PFID, pfId);
            succeed(username, session, username);
        } else {
            String err = extractJson(resp, "errorMessage");
            if (err == null) err = "Registration failed.";
            final String msg = err;
            SwingUtilities.invokeLater(() -> { setStatus(msg, false); resetBtn(); });
        }
    }

    private void succeed(String username, String session, String display) {
        resultUser    = username;
        resultSession = session;
        resultDisplay = display;
        success       = true;
        SwingUtilities.invokeLater(() -> {
            setStatus("Welcome, " + display + "!", true);
            sessionDisplay.setText("●●●●●●●●●●●●●●●●");
            sessionDisplay.setForeground(GREEN);
            Timer t = new Timer(700, e -> dispose());
            t.setRepeats(false);
            t.start();
        });
    }

    // ── HTTP ─────────────────────────────────────────────────────────────────
    private String post(String endpoint, String payload) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(PLAYFAB_URL + endpoint).openConnection();
        c.setRequestMethod("POST");
        c.setRequestProperty("Content-Type", "application/json");
        c.setDoOutput(true);
        c.setConnectTimeout(10000);
        c.setReadTimeout(15000);
        c.getOutputStream().write(payload.getBytes(StandardCharsets.UTF_8));
        InputStream is = (c.getResponseCode() < 400) ? c.getInputStream() : c.getErrorStream();
        return new String(is.readAllBytes(), StandardCharsets.UTF_8);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private void setStatus(String msg, Boolean ok) {
        statusLabel.setText(msg);
        statusLabel.setForeground(ok == null ? DIM : ok ? GREEN : RED);
    }

    private void resetBtn() {
        actionBtn.setEnabled(true);
        actionBtn.setText(isRegisterMode ? "Create Account" : "Sign In");
    }

    private JLabel lbl(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(DIM);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private JTextField field() {
        JTextField f = new JTextField();
        f.setBackground(new Color(25, 25, 32));
        f.setForeground(TEXT);
        f.setCaretColor(ACCENT);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(6, 8, 6, 8)));
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        f.setAlignmentX(Component.LEFT_ALIGNMENT);
        f.addActionListener(e -> doAction());
        return f;
    }

    private JButton accentButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(ACCENT);
        b.setForeground(new Color(15, 15, 18));
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    private String extractJson(String json, String key) {
        if (json == null) return null;
        String s = "\"" + key + "\":";
        int i = json.indexOf(s); if (i < 0) return null;
        i += s.length();
        while (i < json.length() && json.charAt(i) == ' ') i++;
        if (i >= json.length()) return null;
        if (json.charAt(i) == '"') {
            StringBuilder sb = new StringBuilder();
            int e = i + 1;
            while (e < json.length() && json.charAt(e) != '"') {
                if (json.charAt(e) == '\\' && e+1 < json.length()) e += 2;
                else sb.append(json.charAt(e++));
            }
            return sb.toString();
        }
        int e = i;
        while (e < json.length() && ",}\n".indexOf(json.charAt(e)) < 0) e++;
        return json.substring(i, e).trim();
    }

    private String esc(String s) {
        return s.replace("\\","\\\\").replace("\"","\\\"");
    }

    private static Preferences prefs() {
        // Use same node as SplashAuthScreen so credentials are shared
        return Preferences.userNodeForPackage(SplashAuthScreen.class);
    }

    // ── Static accessors (shared prefs with SplashAuthScreen) ─────────────────
    public static String getCachedUsername()    { return nullIfEmpty(prefs().get(PREF_USERNAME, "")); }
    public static String getCachedSession()     { return nullIfEmpty(prefs().get(PREF_SESSION,  "")); }
    public static String getCachedSessionKey()  { return getCachedSession(); }
    public static String getCachedDisplayName() { return nullIfEmpty(prefs().get(PREF_DISPLAY,  "")); }
    public static String getCachedPlayFabId()   { return nullIfEmpty(prefs().get(PREF_PFID,     "")); }

    public static void clearCache() {
        Preferences p = prefs();
        p.remove(PREF_USERNAME);
        p.remove(PREF_SESSION);
        p.remove(PREF_DISPLAY);
        p.remove(PREF_GENPASS);
        p.remove(PREF_PFID);
    }

    public static String showAndGetUsername(Frame owner) {
        String cached = getCachedUsername();
        if (cached != null) return cached;
        PlayFabAuthDialog d = new PlayFabAuthDialog(owner);
        d.setVisible(true);
        return d.success ? d.resultUser : null;
    }

    private static String nullIfEmpty(String s) { return (s == null || s.isEmpty()) ? null : s; }

    public boolean isSuccess()            { return success; }
    public String  getResultUsername()    { return resultUser; }
    public String  getResultSessionKey()  { return resultSession; }
    public String  getResultDisplayName() { return resultDisplay; }

    // Startup ban check (called from EditorFrame)
    public static void checkBanOnStartup(Frame owner) {
        // Handled by SplashAuthScreen now — no-op here
    }
}
