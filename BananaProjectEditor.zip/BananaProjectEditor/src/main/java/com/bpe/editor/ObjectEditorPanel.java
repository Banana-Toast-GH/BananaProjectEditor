package com.bpe.editor;

import com.bpe.codeeditor.BCodeHighlighter;
import com.bpe.hierarchy.HierarchyNode;
import com.bpe.project.BPEProject;
import com.bpe.ui.BPETheme;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

public class ObjectEditorPanel extends JPanel {

    private static final Color BG        = BPETheme.BG_DEEP;
    private static final Color BG_DARK   = BPETheme.BG_DEEPEST;
    private static final Color BG_HEADER = BPETheme.BG_MID;
    private static final Color TEXT      = BPETheme.TEXT_PRIMARY;

    private HierarchyNode              currentNode;
    private BPEProject.ProjectObject   currentObject;
    private JLabel                     objectNameLabel;
    private JTextPane                  codeEditor;
    private JLabel                     fileTabLabel;
    private boolean                    isBlockMode = false;
    private JPanel                     codeContentPanel;
    private EditorFrame                editorFrame;
    private PropertiesPanel            propertiesPanel;
    private CostumeEditor              costumeEditor;
    private JTabbedPane                tabs;
    private BlockEditor                blockEditor;
    private CodeAssist                 codeAssist;

    public ObjectEditorPanel(EditorFrame editorFrame) {
        this.editorFrame = editorFrame;
        setLayout(new BorderLayout());
        setBackground(BG);
        setPreferredSize(new Dimension(340, 0));

        add(buildHeader(), BorderLayout.NORTH);
        tabs = buildTabs();
        add(tabs, BorderLayout.CENTER);
    }

    public ObjectEditorPanel() { this(null); }

    // ── header ────────────────────────────────────────────────────────────────
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BG_HEADER);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0,0,1,0, BPETheme.BORDER),
            BorderFactory.createEmptyBorder(6,10,6,10)));

        JLabel title = new JLabel("Object Editor");
        title.setForeground(TEXT);
        title.setFont(BPETheme.FONT_MONO_BOLD);
        header.add(title, BorderLayout.WEST);

        objectNameLabel = new JLabel("—");
        objectNameLabel.setForeground(BPETheme.TEXT_DIM);
        objectNameLabel.setFont(BPETheme.FONT_MONO_SMALL);
        header.add(objectNameLabel, BorderLayout.EAST);
        return header;
    }

    // ── tabs ──────────────────────────────────────────────────────────────────
    private JTabbedPane buildTabs() {
        JTabbedPane tp = new JTabbedPane();
        tp.setBackground(BG);
        tp.setForeground(TEXT);
        tp.setFont(BPETheme.FONT_MONO_SMALL);

        propertiesPanel = new PropertiesPanel(editorFrame);
        costumeEditor   = new CostumeEditor();

        tp.addTab("Properties", propertiesPanel);
        tp.addTab("Code",       buildCodePanel());
        tp.addTab("Costumes",   costumeEditor);
        tp.addTab("Sounds",     buildSoundsPanel());
        return tp;
    }

    // ── code panel ────────────────────────────────────────────────────────────
    private JPanel buildCodePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BG);

        // Mode toggle toolbar
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        toolbar.setBackground(BG_HEADER);
        toolbar.setBorder(BorderFactory.createMatteBorder(0,0,1,0, BPETheme.BORDER));

        JButton blockBtn = toolbarBtn("[B] Blocks");
        JButton textBtn  = toolbarBtn("[>_] BCode");
        textBtn.setForeground(BPETheme.ACCENT);

        fileTabLabel = new JLabel("  —");
        fileTabLabel.setForeground(BPETheme.TEXT_DIM);
        fileTabLabel.setFont(BPETheme.FONT_MONO_SMALL);
        fileTabLabel.setBackground(BPETheme.BG_DEEPEST);
        fileTabLabel.setOpaque(true);
        fileTabLabel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BPETheme.BORDER),
            BorderFactory.createEmptyBorder(2,8,2,8)));

        toolbar.add(blockBtn);
        toolbar.add(textBtn);
        toolbar.add(Box.createHorizontalStrut(4));
        toolbar.add(fileTabLabel);
        panel.add(toolbar, BorderLayout.NORTH);

        // Card layout: text / blocks
        codeContentPanel = new JPanel(new CardLayout());
        codeContentPanel.setBackground(BG_DARK);
        codeContentPanel.add(buildTextEditor(), "text");
        codeContentPanel.add(buildBlockEditor(), "block");
        panel.add(codeContentPanel, BorderLayout.CENTER);

        blockBtn.addActionListener(e -> {
            isBlockMode = true;
            ((CardLayout)codeContentPanel.getLayout()).show(codeContentPanel, "block");
            blockBtn.setForeground(BPETheme.ACCENT);
            textBtn.setForeground(BPETheme.TEXT_DIM);
        });
        textBtn.addActionListener(e -> {
            isBlockMode = false;
            ((CardLayout)codeContentPanel.getLayout()).show(codeContentPanel, "text");
            textBtn.setForeground(BPETheme.ACCENT);
            blockBtn.setForeground(BPETheme.TEXT_DIM);
            // Sync blocks → text when switching to text view
            if (currentNode != null && !blockEditor.getBlocks().isEmpty()) {
                String generated = blockEditor.generateBCode(currentNode.getName());
                try {
                    codeEditor.getStyledDocument().remove(0, codeEditor.getDocument().getLength());
                    codeEditor.getStyledDocument().insertString(0, generated, null);
                } catch (Exception ex) { /* ignore */ }
            }
        });

        return panel;
    }

    private JPanel buildTextEditor() {
        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setBackground(BG_DARK);

        codeEditor = new JTextPane();
        codeEditor.setBackground(BG_DARK);
        codeEditor.setForeground(TEXT);
        codeEditor.setCaretColor(BPETheme.ACCENT);
        codeEditor.setFont(new java.awt.Font("Consolas", java.awt.Font.PLAIN, 14));
        codeEditor.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
        codeEditor.setStyledDocument(new BCodeHighlighter());

        // Syntax error bar
        JLabel syntaxBar = new JLabel(" ");
        syntaxBar.setFont(new java.awt.Font("Consolas", java.awt.Font.PLAIN, 11));
        syntaxBar.setOpaque(true);
        syntaxBar.setBackground(BG_DARK);
        syntaxBar.setForeground(new Color(255,100,100));
        syntaxBar.setBorder(BorderFactory.createEmptyBorder(2,8,2,8));

        // Mark unsaved on edit + syntax check
        codeEditor.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { check(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { check(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) {}
            void check() {
                if (editorFrame != null) editorFrame.markUnsaved();
                javax.swing.SwingUtilities.invokeLater(() -> {
                    String err = checkSyntax(getCode());
                    syntaxBar.setText(err == null ? " ✓ No errors" : " ✗ " + err);
                    syntaxBar.setForeground(err == null ? new Color(100,220,100) : new Color(255,100,100));
                });
            }
        });

        // Line numbers
        JPanel lineNumbers = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(BPETheme.TEXT_DIM);
                g.setFont(BPETheme.FONT_MONO_SMALL);
                FontMetrics fm = g.getFontMetrics();
                int lh = fm.getHeight();
                String text = "";
                try { text = codeEditor.getDocument().getText(0, codeEditor.getDocument().getLength()); }
                catch (Exception e) { return; }
                int lines = text.split("\n", -1).length;
                for (int i = 1; i <= Math.max(lines, 20); i++)
                    g.drawString(String.valueOf(i), 4, i * lh - 2);
            }
        };
        lineNumbers.setPreferredSize(new Dimension(32, 0));
        lineNumbers.setBackground(BPETheme.BG_MID);
        codeEditor.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { lineNumbers.repaint(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { lineNumbers.repaint(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) {}
        });

        JScrollPane codeScroll = new JScrollPane(codeEditor);
        codeScroll.setBorder(BorderFactory.createEmptyBorder());
        codeScroll.getViewport().setBackground(BG_DARK);
        codeScroll.setRowHeaderView(lineNumbers);
        textPanel.add(codeScroll, BorderLayout.CENTER);
        textPanel.add(syntaxBar, BorderLayout.SOUTH);

        // Wire up autocomplete — deferred so window ancestor is available
        SwingUtilities.invokeLater(() -> {
            codeAssist = new CodeAssist(codeEditor);
            // Wire undo manager
            if (editorFrame != null) {
                codeEditor.getDocument().addUndoableEditListener(
                    e -> editorFrame.getUndoManager().addEdit(e.getEdit()));
            }
        });

        // Hide autocomplete when switching away from Code tab
        // (deferred so tabs field is assigned first)
        SwingUtilities.invokeLater(() -> {
            if (tabs != null) tabs.addChangeListener(e -> {
                if (codeAssist != null) codeAssist.hide();
            });
        });

        return textPanel;
    }

    private JPanel buildBlockEditor() {
        blockEditor = new BlockEditor(() -> {
            // When blocks change, mark unsaved
            if (editorFrame != null) editorFrame.markUnsaved();
        });
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.add(blockEditor, BorderLayout.CENTER);
        return wrap;
    }

    // ── sounds panel ──────────────────────────────────────────────────────────
    private DefaultListModel<String> soundListModel = new DefaultListModel<>();

    private JPanel buildSoundsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BG_DARK);

        JPanel header = new JPanel(new BorderLayout(6,0));
        header.setBackground(BG_HEADER);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0,0,1,0, BPETheme.BORDER),
            BorderFactory.createEmptyBorder(6,10,6,10)));
        JLabel lbl = new JLabel("Sounds");
        lbl.setForeground(TEXT); lbl.setFont(BPETheme.FONT_MONO_BOLD);
        JButton importBtn = BPETheme.secondaryButton("+ Import");
        importBtn.setFont(BPETheme.FONT_MONO_SMALL);
        importBtn.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            fc.setMultiSelectionEnabled(true);
            fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                "Audio (mp3, wav, ogg)", "mp3", "wav", "ogg"));
            if (fc.showOpenDialog(panel) == JFileChooser.APPROVE_OPTION)
                for (java.io.File f : fc.getSelectedFiles())
                    if (!soundListModel.contains(f.getName())) soundListModel.addElement(f.getName());
        });
        header.add(lbl, BorderLayout.WEST);
        header.add(importBtn, BorderLayout.EAST);
        panel.add(header, BorderLayout.NORTH);

        JList<String> soundList = new JList<>(soundListModel);
        soundList.setBackground(BG_DARK);
        soundList.setForeground(TEXT);
        soundList.setFont(BPETheme.FONT_MONO_SMALL);
        soundList.setCellRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(
                    JList<?> l, Object v, int i, boolean sel, boolean foc) {
                JLabel c = (JLabel) super.getListCellRendererComponent(l,v,i,sel,foc);
                c.setBorder(BorderFactory.createEmptyBorder(4,10,4,10));
                c.setIcon(new javax.swing.Icon(){
                    public void paintIcon(Component comp, Graphics g, int x, int y){
                        g.setColor(BPETheme.GREEN); g.fillOval(x,y+2,8,8); }
                    public int getIconWidth(){return 12;}
                    public int getIconHeight(){return 12;}
                });
                c.setBackground(sel ? BPETheme.BG_SELECTED : BG_DARK);
                c.setForeground(TEXT);
                return c;
            }
        });
        soundList.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_DELETE) {
                    int idx = soundList.getSelectedIndex();
                    if (idx >= 0) soundListModel.remove(idx);
                }
            }
        });
        JScrollPane scroll = new JScrollPane(soundList);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        panel.add(scroll, BorderLayout.CENTER);

        JLabel hint = new JLabel("  Del to remove  |  mp3, wav, ogg");
        hint.setForeground(BPETheme.TEXT_DIM);
        hint.setFont(BPETheme.FONT_MONO_SMALL);
        hint.setBorder(BorderFactory.createEmptyBorder(4,6,4,6));
        panel.add(hint, BorderLayout.SOUTH);
        return panel;
    }

    // ── load object ───────────────────────────────────────────────────────────
    public void loadObject(HierarchyNode node) {
        this.currentNode = node;
        objectNameLabel.setText(node.getName());
        fileTabLabel.setText("  " + node.getName() +
            (node.getType() == HierarchyNode.NodeType.OBJECT ? ".BCode" : ""));

        // Find matching project object
        currentObject = null;
        if (editorFrame != null && node.getType() == HierarchyNode.NodeType.OBJECT) {
            for (BPEProject.ProjectObject obj : editorFrame.getProject().objects)
                if (obj.name.equals(node.getName())) { currentObject = obj; break; }
        }

        // ── PROPERTIES: load the actual object data ───────────────────────────
        propertiesPanel.loadObject(currentObject);

        // ── COSTUMES: load saved frames for this object ───────────────────────
        if (editorFrame != null && currentObject != null)
            costumeEditor.loadObject(editorFrame.getProject(), currentObject.name);

        // ── CODE: load script ─────────────────────────────────────────────────
        if (node.getType() == HierarchyNode.NodeType.OBJECT) {
            String script = "";
            if (editorFrame != null && editorFrame.getProject().scripts.containsKey(node.getName()))
                script = editorFrame.getProject().scripts.get(node.getName());
            if (script.isEmpty())
                script = "script.start\n\n"
                    + "attach \"Banana Project Editor\";\n"
                    + "attach \"" + node.getName() + "\";\n\n"
                    + "event:onStart()\n"
                    + "    -- use var x = 5 to declare variables\n"    + "    -- write your code here\n"
                    + "event.end\n\n"
                    + "script.end";

            final String fs = script;
            try {
                codeEditor.getStyledDocument().remove(0, codeEditor.getDocument().getLength());
                codeEditor.getStyledDocument().insertString(0, fs, null);
            } catch (Exception ignored) {}
        }
    }

    public void syncScriptsToProject(BPEProject project) {
        if (currentNode != null && currentNode.getType() == HierarchyNode.NodeType.OBJECT)
            project.scripts.put(currentNode.getName(), getCode());
    }

    public JTextPane getCodeEditor() { return codeEditor; }

    /** Basic BCode syntax checker - returns error string or null if ok */
    private String checkSyntax(String code) {
        if (code == null || code.trim().isEmpty()) return null;
        String[] lines = code.split("\n");
        boolean inScript = false;
        int eventDepth = 0;
        int lineNum = 0;
        for (String raw : lines) {
            lineNum++;
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("--")) continue;
            if (line.equals("script.start")) { inScript = true; continue; }
            if (line.equals("script.end"))   { inScript = false; continue; }
            if (!inScript) continue;
            if (line.startsWith("event:") || line.startsWith("object.event:")) {
                if (eventDepth > 0) return "Line " + lineNum + ": nested event not allowed";
                eventDepth++; continue;
            }
            if (line.equals("event.end")) {
                if (eventDepth == 0) return "Line " + lineNum + ": event.end without event";
                eventDepth--; continue;
            }
            // Check for unclosed strings
            int quotes = 0;
            for (char c : line.toCharArray()) if (c == '"') quotes++;
            if (quotes % 2 != 0) return "Line " + lineNum + ": unclosed string";
            // Check for unmatched parens
            int parens = 0;
            for (char c : line.toCharArray()) {
                if (c == '(') parens++;
                if (c == ')') parens--;
            }
            if (parens != 0) return "Line " + lineNum + ": unmatched parentheses";
        }
        if (inScript) return "Missing script.end";
        if (eventDepth > 0) return "Missing event.end";
        return null;
    }

    public String getCode() {
        try { return codeEditor.getDocument().getText(0, codeEditor.getDocument().getLength()); }
        catch (Exception e) { return ""; }
    }

    // ── helpers ───────────────────────────────────────────────────────────────
    private JButton toolbarBtn(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(BG_HEADER);
        btn.setForeground(BPETheme.TEXT_DIM);
        btn.setFont(BPETheme.FONT_MONO_SMALL);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BPETheme.BORDER),
            BorderFactory.createEmptyBorder(3,8,3,8)));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
