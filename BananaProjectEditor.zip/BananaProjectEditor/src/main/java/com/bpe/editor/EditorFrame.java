package com.bpe.editor;

import com.bpe.hierarchy.HierarchyPanel;
import com.bpe.project.BPEProject;
import com.bpe.ui.BPETheme;
import com.bpe.ui.ProjectExplorer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EditorFrame extends JFrame {

    private static final Color BG = BPETheme.BG_DEEP;
    private static final Color TOPBAR_BG = BPETheme.BG_DEEPEST;
    private static final Color TEXT = BPETheme.TEXT_PRIMARY;
    private static final Color ACCENT = BPETheme.ACCENT;

    private HierarchyPanel hierarchyPanel;
    private ObjectEditorPanel objectEditorPanel;
    private GameDisplayPanel gameDisplayPanel;
    private ConsolePanel consolePanel;
    private BPEProject project;
    private JLabel statusRight;
    private boolean unsavedChanges = false;
    private javax.swing.undo.UndoManager undoManager = new javax.swing.undo.UndoManager();

    public EditorFrame(BPEProject project) {
        this.project = project;

        setTitle(project.name + " - Banana Project Editor");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setSize(1280, 720);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);
        setIconImage(BPETheme.createBananaIcon(32));
        getContentPane().setBackground(BG);
        setLayout(new BorderLayout());

        // Build components
        hierarchyPanel = new HierarchyPanel();
        objectEditorPanel = new ObjectEditorPanel(this);
        gameDisplayPanel = new GameDisplayPanel(project);
        consolePanel = new ConsolePanel();

        // Wire up hierarchy -> object editor
        hierarchyPanel.setSelectionListener(node -> objectEditorPanel.loadObject(node));

        // Give hierarchy access to project so new objects appear on canvas
        hierarchyPanel.setProject(project);

        // Load project objects into hierarchy
        hierarchyPanel.loadProject(project);

        // Topbar menu
        add(buildTopBar(), BorderLayout.NORTH);
        add(buildMainContent(), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);

        // Ctrl+S to save
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
            .put(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK), "save");
        getRootPane().getActionMap().put("save", new AbstractAction() {
            public void actionPerformed(ActionEvent e) { saveProject(); }
        });

        // Warn on close if unsaved
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                if (unsavedChanges) {
                    int result = JOptionPane.showConfirmDialog(EditorFrame.this,
                        "You have unsaved changes. Save before closing?",
                        "Unsaved Changes", JOptionPane.YES_NO_CANCEL_OPTION);
                    if (result == JOptionPane.YES_OPTION) { saveProject(); dispose(); }
                    else if (result == JOptionPane.NO_OPTION) { dispose(); }
                } else { dispose(); }
            }
        });

        consolePanel.log("Project \"" + project.name + "\" loaded.");
        consolePanel.log("Template: " + project.template);
    }

    public void repaintCanvas() {
        if (gameDisplayPanel != null) gameDisplayPanel.repaint();
    }

    public void markUnsaved() {
        unsavedChanges = true;
        setTitle("* " + project.name + " - Banana Project Editor");
        if (statusRight != null) {
            statusRight.setText("Unsaved changes");
            statusRight.setForeground(new Color(220, 160, 40));
        }
    }

    private JMenuBar buildTopBar() {
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(TOPBAR_BG);
        menuBar.setBorder(BorderFactory.createEmptyBorder(2, 4, 2, 4));

        String[] menus = {"File", "Edit", "View", "SDK", "Java", "Lua", "BCode", "Run"};
        for (String menuName : menus) {
            JMenu menu = new JMenu(menuName);
            menu.setForeground(TEXT);
            menu.setFont(new Font("Monospaced", Font.PLAIN, 12));
            menu.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
            styleMenu(menu, menuName);
            menuBar.add(menu);
        }

        return menuBar;
    }

    private void styleMenu(JMenu menu, String name) {
        switch (name) {
            case "File":
                JMenuItem newProj = addMenuItem(menu, "New Project", KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK);
                newProj.addActionListener(e -> { dispose(); new ProjectExplorer().setVisible(true); });
                JMenuItem openProj = addMenuItem(menu, "Open Project", KeyEvent.VK_O, InputEvent.CTRL_DOWN_MASK);
                openProj.addActionListener(e -> { dispose(); new ProjectExplorer().setVisible(true); });
                menu.addSeparator();
                JMenuItem save = addMenuItem(menu, "Save  Ctrl+S", 0, 0);
                save.addActionListener(e -> saveProject());
                JMenuItem saveAs = addMenuItem(menu, "Save As...", 0, 0);
                saveAs.addActionListener(e -> saveProjectAs());
                menu.addSeparator();
                JMenuItem exportJar = addMenuItem(menu, "Export as .jar", 0, 0);
                exportJar.addActionListener(e -> exportAsJar());
                menu.addSeparator();
                JMenuItem exit = addMenuItem(menu, "Exit", 0, 0);
                exit.addActionListener(e -> dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING)));
                break;
            case "Edit":
                JMenuItem undo = addMenuItem(menu, "Undo  Ctrl+Z", KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK);
                undo.addActionListener(e -> { if (undoManager.canUndo()) { undoManager.undo(); } });
                JMenuItem redo = addMenuItem(menu, "Redo  Ctrl+Y", KeyEvent.VK_Y, InputEvent.CTRL_DOWN_MASK);
                redo.addActionListener(e -> { if (undoManager.canRedo()) { undoManager.redo(); } });
                break;
            case "View":
                JMenuItem toggleConsole = addMenuItem(menu, "Toggle Console", 0, 0);
                toggleConsole.addActionListener(e -> consolePanel.setVisible(!consolePanel.isVisible()));
                JMenuItem toggleHierarchy = addMenuItem(menu, "Toggle Hierarchy", 0, 0);
                toggleHierarchy.addActionListener(e -> hierarchyPanel.setVisible(!hierarchyPanel.isVisible()));
                menu.addSeparator();
                JMenuItem lightModeItem = addMenuItem(menu, "Toggle Light / Dark Mode", 0, 0);
                lightModeItem.addActionListener(e -> {
                    SceneCanvas.lightMode = !SceneCanvas.lightMode;
                    getContentPane().repaint();
                });
                break;
            case "SDK":
                JMenuItem importSDK = addMenuItem(menu, "Import SDK...", 0, 0); importSDK.setEnabled(false);
                JMenuItem browseSDK = addMenuItem(menu, "Browse SDK Library", 0, 0); browseSDK.setEnabled(false);
                menu.addSeparator();
                JMenuItem manageSDK = addMenuItem(menu, "Manage SDKs", 0, 0); manageSDK.setEnabled(false);
                break;
            case "Java":
                JMenuItem javaInfo = addMenuItem(menu, "Java Version Info", 0, 0);
                javaInfo.addActionListener(e -> JOptionPane.showMessageDialog(this,
                    "Java Version: " + System.getProperty("java.version") + "\n" +
                    "Vendor: " + System.getProperty("java.vendor") + "\n" +
                    "Runtime: " + System.getProperty("java.runtime.name"),
                    "Java Info", JOptionPane.INFORMATION_MESSAGE));
                JMenuItem javaConsole = addMenuItem(menu, "Open Java Console", 0, 0); javaConsole.setEnabled(false);
                break;
            case "Lua":
                JMenuItem luaView = addMenuItem(menu, "View Compiled Lua", 0, 0); luaView.setEnabled(false);
                JMenuItem luaDocs = addMenuItem(menu, "Lua Documentation", 0, 0); luaDocs.setEnabled(false);
                break;
            case "BCode":
                JMenuItem bcodeDocs = addMenuItem(menu, "BCode Documentation", 0, 0);
                bcodeDocs.addActionListener(e -> showBCodeDocs());
                JMenuItem bcodeRef = addMenuItem(menu, "BCode Reference", 0, 0);
                bcodeRef.addActionListener(e -> showBCodeDocs());
                menu.addSeparator();
                JMenuItem formatScript = addMenuItem(menu, "Format Script", 0, 0);
                formatScript.addActionListener(e -> formatScript());
                break;
            case "Run":
                JMenuItem runItem = new JMenuItem("[>] Run  F5");
                runItem.setForeground(BPETheme.ACCENT);
                runItem.setFont(BPETheme.FONT_MONO_BOLD);
                runItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
                runItem.addActionListener(e -> runProject());
                menu.add(runItem);
                JMenuItem stopItem = new JMenuItem("[x] Stop  Shift+F5");
                stopItem.setForeground(BPETheme.RED);
                stopItem.setFont(BPETheme.FONT_MONO_BOLD);
                stopItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, InputEvent.SHIFT_DOWN_MASK));
                stopItem.addActionListener(e -> stopProject());
                menu.add(stopItem);
                menu.addSeparator();
                JMenuItem buildProj = addMenuItem(menu, "Build Project", 0, 0); buildProj.setEnabled(false);
                break;
        }
    }

    private JMenuItem addMenuItem(JMenu menu, String text, int key, int modifiers) {
        JMenuItem item = new JMenuItem(text);
        item.setForeground(TEXT);
        item.setBackground(TOPBAR_BG);
        item.setFont(new Font("Monospaced", Font.PLAIN, 11));
        if (key != 0) item.setAccelerator(KeyStroke.getKeyStroke(key, modifiers));
        menu.add(item);
        return item;
    }

    private JSplitPane buildMainContent() {
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(BG);
        centerPanel.add(gameDisplayPanel, BorderLayout.CENTER);
        centerPanel.add(consolePanel, BorderLayout.SOUTH);

        JSplitPane leftSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, objectEditorPanel, centerPanel);
        leftSplit.setDividerLocation(330);
        leftSplit.setDividerSize(4);
        leftSplit.setBackground(BG);
        leftSplit.setBorder(null);

        JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftSplit, hierarchyPanel);
        mainSplit.setDividerLocation(1060);
        mainSplit.setResizeWeight(1.0);
        mainSplit.setDividerSize(4);
        mainSplit.setBackground(BG);
        mainSplit.setBorder(null);

        return mainSplit;
    }

    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(BPETheme.BG_DEEPEST);
        bar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, BPETheme.BORDER),
            BorderFactory.createEmptyBorder(3, 10, 3, 10)
        ));
        bar.setPreferredSize(new Dimension(0, 24));

        JLabel left = new JLabel(project.name + "  |  BCode v1.0  |  " + project.projectPath);
        left.setForeground(BPETheme.TEXT_DIM);
        left.setFont(BPETheme.FONT_MONO_SMALL);

        statusRight = new JLabel("Ready");
        statusRight.setForeground(BPETheme.GREEN);
        statusRight.setFont(BPETheme.FONT_MONO_SMALL);

        bar.add(left, BorderLayout.WEST);
        bar.add(statusRight, BorderLayout.EAST);
        return bar;
    }

    private void exportAsJar() {
        // Save first
        saveProject();

        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new java.io.File(project.name + ".jar"));
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("JAR files", "jar"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        java.io.File dest = fc.getSelectedFile();
        if (!dest.getName().endsWith(".jar")) dest = new java.io.File(dest.getAbsolutePath() + ".jar");

        // Find BananaProjectEditor.jar next to the project
        java.io.File jarSrc = new java.io.File(
            new java.io.File(System.getProperty("java.class.path").split(java.io.File.pathSeparator)[0])
                .getParentFile(), "BananaProjectEditor.jar");

        // Fallback: try current dir
        if (!jarSrc.exists()) jarSrc = new java.io.File("BananaProjectEditor.jar");

        final java.io.File finalDest = dest;
        final java.io.File finalSrc  = jarSrc;

        consolePanel.log("[Export] Building " + dest.getName() + "...");

        new Thread(() -> {
            try {
                // Copy the engine jar to destination
                if (finalSrc.exists()) {
                    java.nio.file.Files.copy(finalSrc.toPath(), finalDest.toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }

                // Write a launch config next to it
                java.io.File cfgFile = new java.io.File(
                    finalDest.getParent(), project.name + "_project.bpe.path");
                java.nio.file.Files.write(cfgFile.toPath(),
                    project.getBpeFile().getAbsolutePath().getBytes("UTF-8"));

                SwingUtilities.invokeLater(() -> {
                    consolePanel.log("[Export] Done! " + finalDest.getName());
                    JOptionPane.showMessageDialog(EditorFrame.this,
                        "<html>Exported to:<br><b>" + finalDest.getAbsolutePath() + "</b><br><br>" +
                        "Run with: java -jar " + finalDest.getName() + "</html>",
                        "Export Complete", JOptionPane.INFORMATION_MESSAGE);
                });
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    consolePanel.log("[Export] Error: " + ex.getMessage());
                    JOptionPane.showMessageDialog(EditorFrame.this,
                        "Export failed: " + ex.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
                });
            }
        }).start();
    }

    private void saveProject() {
        objectEditorPanel.syncScriptsToProject(project);
        hierarchyPanel.syncObjectsToProject(project);

        try {
            project.save();
            unsavedChanges = false;
            setTitle(project.name + " - Banana Project Editor");
            statusRight.setText("Saved");
            statusRight.setForeground(new Color(100, 200, 100));
            consolePanel.log("Project saved to: " + project.getBpeFile().getAbsolutePath());

            Timer t = new Timer(3000, e -> statusRight.setText("Ready"));
            t.setRepeats(false);
            t.start();

        } catch (Exception ex) {
            consolePanel.error("Save failed: " + ex.getMessage());
            JOptionPane.showMessageDialog(this, "Save failed:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private GameWindow gameWindow = null;

    private void runProject() {
        // Save first
        saveProject();

        // Close existing game window if open
        if (gameWindow != null) {
            gameWindow.stop();
            gameWindow.dispose();
            gameWindow = null;
        }

        consolePanel.log("Launching game window...");
        statusRight.setText("Running");
        statusRight.setForeground(new Color(100, 220, 100));

        gameWindow = new GameWindow(project,
            msg -> consolePanel.print(msg),
            msg -> consolePanel.warn(msg),
            msg -> consolePanel.error(msg)
        );
        gameWindow.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosed(java.awt.event.WindowEvent e) {
                statusRight.setText("Ready");
                statusRight.setForeground(new Color(100, 200, 100));
                gameWindow = null;
            }
        });
        gameWindow.start();
    }

    private void stopProject() {
        if (gameWindow != null) {
            gameWindow.stop();
            gameWindow.dispose();
            gameWindow = null;
        }
        consolePanel.log("Stopped.");
        statusRight.setText("Ready");
        statusRight.setForeground(new Color(100, 200, 100));
    }

    private void saveProjectAs() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Save Project As...");
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        java.io.File dir = fc.getSelectedFile();
        String oldPath = project.projectPath;
        project.projectPath = dir.getAbsolutePath();
        try {
            project.save();
            consolePanel.log("Saved copy to: " + project.getBpeFile().getAbsolutePath());
        } catch (Exception ex) {
            project.projectPath = oldPath;
            JOptionPane.showMessageDialog(this, "Save As failed:\n" + ex.getMessage());
        }
    }

    private void exportJar() {
        // Save first
        saveProject();
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Export as .jar");
        fc.setSelectedFile(new java.io.File(project.name + ".jar"));
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("JAR files", "jar"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        java.io.File jarFile = fc.getSelectedFile();
        if (!jarFile.getName().endsWith(".jar"))
            jarFile = new java.io.File(jarFile.getAbsolutePath() + ".jar");

        consolePanel.log("Exporting to " + jarFile.getName() + "...");
        statusRight.setText("Exporting...");
        statusRight.setForeground(new Color(220, 160, 40));

        final java.io.File finalJar = jarFile;
        new Thread(() -> {
            try {
                // Create a minimal runnable JAR with project data embedded as JSON
                java.util.jar.Manifest manifest = new java.util.jar.Manifest();
                manifest.getMainAttributes().put(java.util.jar.Attributes.Name.MANIFEST_VERSION, "1.0");
                manifest.getMainAttributes().put(java.util.jar.Attributes.Name.MAIN_CLASS, "com.bpe.runtime.GameLauncher");

                java.io.FileOutputStream fos = new java.io.FileOutputStream(finalJar);
                java.util.jar.JarOutputStream jos = new java.util.jar.JarOutputStream(fos, manifest);

                // Embed project file
                java.io.File bpeFile = project.getBpeFile();
                if (bpeFile.exists()) {
                    jos.putNextEntry(new java.util.zip.ZipEntry("project.bpe"));
                    java.nio.file.Files.copy(bpeFile.toPath(), jos);
                    jos.closeEntry();
                }

                // Embed scripts
                java.io.File scriptsDir = project.getScriptsFolder();
                if (scriptsDir.exists()) {
                    for (java.io.File f : scriptsDir.listFiles()) {
                        jos.putNextEntry(new java.util.zip.ZipEntry("scripts/" + f.getName()));
                        java.nio.file.Files.copy(f.toPath(), jos);
                        jos.closeEntry();
                    }
                }

                // README entry explaining this is a BPE export
                jos.putNextEntry(new java.util.zip.ZipEntry("README.txt"));
                String readme = "BPE Game Export: " + project.name + "\n"
                    + "Generated by Banana Project Editor\n"
                    + "To run: java -jar " + finalJar.getName() + "\n";
                jos.write(readme.getBytes());
                jos.closeEntry();

                jos.close(); fos.close();

                SwingUtilities.invokeLater(() -> {
                    consolePanel.log("Exported: " + finalJar.getAbsolutePath());
                    statusRight.setText("Ready");
                    statusRight.setForeground(new Color(100,200,100));
                    JOptionPane.showMessageDialog(EditorFrame.this,
                        "Exported successfully!\n" + finalJar.getName(),
                        "Export Complete", JOptionPane.INFORMATION_MESSAGE);
                });
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> {
                    consolePanel.error("Export failed: " + ex.getMessage());
                    statusRight.setText("Error");
                    statusRight.setForeground(new Color(220,60,60));
                });
            }
        }).start();
    }

    private void formatScript() {
        String code = objectEditorPanel.getCode();
        if (code.isEmpty()) return;
        String[] lines = code.split("\n");
        StringBuilder sb = new StringBuilder();
        int indent = 0;
        for (String raw : lines) {
            String line = raw.trim();
            if (line.equals("event.end") || line.equals("script.end")) indent = Math.max(0, indent-1);
            sb.append("    ".repeat(indent)).append(line).append("\n");
            if (line.startsWith("event:") || line.startsWith("object.event:") || line.equals("script.start")) indent++;
        }
        try {
            javax.swing.text.Document doc = objectEditorPanel.getCodeEditor().getDocument();
            doc.remove(0, doc.getLength());
            doc.insertString(0, sb.toString().trim(), null);
        } catch (Exception ignored) {}
        consolePanel.log("Script formatted.");
    }

    private void showBCodeDocs() {
        String docs =
            "═══════════════════════════════════════\n" +
            "  BCode Reference\n" +
            "═══════════════════════════════════════\n" +
            "STRUCTURE:\n" +
            "  script.start ... script.end\n" +
            "  attach \"Name\";  deattach;\n" +
            "  local x = 5;\n\n" +
            "EVENTS:\n" +
            "  event:onStart()  event:onUpdate()\n" +
            "  event:onDestroy()  event:onCollide(other)\n" +
            "  object.event:OnClick()\n" +
            "  event.end\n\n" +
            "CONTROL:\n" +
            "  if (cond) = stmt]\n" +
            "  if (cond) = stmt1; stmt2]\n" +
            "  if (cond) = stmt] else = stmt]\n" +
            "  forever = stmt]\n\n" +
            "OBJECT:\n" +
            "  object.SetPosition(x, y)\n" +
            "  local x, y = object.GetPosition()\n" +
            "  object.SetSize(w, h)\n" +
            "  object.SetRotation(deg)\n" +
            "  object.Show(opacity)  object.Hide()\n" +
            "  object.SetText(s)  object.GetText()\n" +
            "  object.Clone()  object.Destroy()\n\n" +
            "INPUT (attach Game Controller first):\n" +
            "  object.KeyDown(\"W\")\n" +
            "  object.KeyPressed(\"Space\")\n" +
            "  object.MouseDown()  object.MouseClicked()\n\n" +
            "ENGINE:\n" +
            "  engine.log/warn/error(msg)\n" +
            "  engine.LoadScene(name)  engine.Quit()\n" +
            "  engine.SceneReload()\n\n" +
            "WINDOW / TIME:\n" +
            "  window.SetTitle(s)  window.GetFPS()\n" +
            "  window.GetDeltaTime()  window.SetSize(w,h)\n" +
            "  time.GetTime()  sound.Play(name)\n\n" +
            "MATH:\n" +
            "  math.Sin/Cos/Abs/Floor/Ceil/Sqrt(x)\n" +
            "  math.Pow(x,y)  math.Random(min,max)\n" +
            "  math.Clamp(v,min,max)\n";
        consolePanel.log(docs);
        JOptionPane.showMessageDialog(this, docs.replace("\n", "\n"),
            "BCode Reference", JOptionPane.INFORMATION_MESSAGE);
    }

    public BPEProject getProject() { return project; }
    public javax.swing.undo.UndoManager getUndoManager() { return undoManager; }
    public ConsolePanel getConsole() { return consolePanel; }
}
