package com.bpe.editor;

import com.bpe.codeeditor.BCodeHighlighter;
import com.bpe.hierarchy.HierarchyNode;
import com.bpe.project.BPEProject;
import com.bpe.ui.BPETheme;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

public class ObjectEditorPanel extends JPanel {

    private static final Color BG = BPETheme.BG_DEEP;
    private static final Color BG_DARK = BPETheme.BG_DEEPEST;
    private static final Color BG_HEADER = BPETheme.BG_MID;
    private static final Color TEXT = BPETheme.TEXT_PRIMARY;

    private HierarchyNode currentNode;
    private BPEProject.ProjectObject currentObject;
    private JLabel objectNameLabel;
    private JTextPane codeEditor;
    private JLabel fileTabLabel;
    private boolean isBlockMode = false;
    private JPanel codeContentPanel;
    private EditorFrame editorFrame;
    private PropertiesPanel propertiesPanel;
    private CostumeEditor costumeEditor;
    private JTabbedPane tabs;

    public ObjectEditorPanel(EditorFrame editorFrame) {
        this.editorFrame = editorFrame;
        setLayout(new BorderLayout());
        setBackground(BG);
        setPreferredSize(new Dimension(320, 0));

        add(buildHeader(), BorderLayout.NORTH);
        tabs = buildTabs();
        add(tabs, BorderLayout.CENTER);
    }

    public ObjectEditorPanel() {
        this(null);
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(BG_HEADER);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, BPETheme.BORDER),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));

        JLabel title = new JLabel("Object Editor");
        title.setForeground(TEXT);
        title.setFont(BPETheme.FONT_MONO_BOLD);
        header.add(title, BorderLayout.WEST);

        objectNameLabel = new JLabel("—");
        objectNameLabel.setForeground(BPETheme.TEXT_DIM);
        objectNameLabel.setFont(BPETheme.FONT_MONO_SMALL);
        header.add(objectNameLabel, BorderLayout.EAST);

        return header;
    }

    private JTabbedPane buildTabs() {
        JTabbedPane tp = new JTabbedPane();
        tp.setBackground(BG);
        tp.setForeground(TEXT);
        tp.setFont(BPETheme.FONT_MONO_SMALL);

        propertiesPanel = new PropertiesPanel(editorFrame);
        costumeEditor = new CostumeEditor();

        tp.addTab("Properties", propertiesPanel);
        tp.addTab("Code", buildCodePanel());
        tp.addTab("Costumes", costumeEditor);
        tp.addTab("Sounds", buildSoundsPanel());

        return tp;
    }

    private JPanel buildCodePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BG);

        // Toolbar
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        toolbar.setBackground(BG_HEADER);
        toolbar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BPETheme.BORDER));

        JButton blockBtn = toolbarBtn("[B] Blocks");
        JButton textBtn = toolbarBtn("[>_] Text");
        textBtn.setForeground(BPETheme.ACCENT); // default active

        fileTabLabel = new JLabel("  —");
        fileTabLabel.setForeground(BPETheme.TEXT_DIM);
        fileTabLabel.setFont(BPETheme.FONT_MONO_SMALL);
        fileTabLabel.setBackground(BPETheme.BG_DEEPEST);
        fileTabLabel.setOpaque(true);
        fileTabLabel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BPETheme.BORDER),
            BorderFactory.createEmptyBorder(2, 8, 2, 8)
        ));

        toolbar.add(blockBtn);
        toolbar.add(textBtn);
        toolbar.add(Box.createHorizontalStrut(4));
        toolbar.add(fileTabLabel);
        panel.add(toolbar, BorderLayout.NORTH);

        // Code content (card layout: block vs text)
        codeContentPanel = new JPanel(new CardLayout());
        codeContentPanel.setBackground(BG_DARK);

        // Text editor
        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setBackground(BG_DARK);
        codeEditor = new JTextPane();
        codeEditor.setBackground(BG_DARK);
        codeEditor.setForeground(TEXT);
        codeEditor.setCaretColor(BPETheme.ACCENT);
        codeEditor.setFont(BPETheme.FONT_MONO);
        codeEditor.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        codeEditor.setStyledDocument(new BCodeHighlighter());
        codeEditor.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { if (editorFrame != null) editorFrame.markUnsaved(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { if (editorFrame != null) editorFrame.markUnsaved(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) {}
        });

        // Line numbers
        JPanel lineNumbers = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(BPETheme.TEXT_DIM);
                g.setFont(BPETheme.FONT_MONO_SMALL);
                FontMetrics fm = g.getFontMetrics();
                int lh = fm.getHeight();
                String text;
                try { text = codeEditor.getDocument().getText(0, codeEditor.getDocument().getLength()); }
                catch (Exception e) { return; }
                int lines = text.split("\n", -1).length;
                for (int i = 1; i <= Math.max(lines, 20); i++) {
                    g.drawString(String.valueOf(i), 4, i * lh - 2);
                }
            }
        };
        lineNumbers.setPreferredSize(new Dimension(32, 0));
        lineNumbers.setBackground(BPETheme.BG_MID);
        codeEditor.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { lineNumbers.repaint(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { lineNumbers.repaint(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) {}
        });

        JScrollPane codeScroll = new JScrollPane(codeEditor);
        codeScroll.setBorder(BorderFactory.createEmptyBorder());
        codeScroll.setBackground(BG_DARK);
        codeScroll.getViewport().setBackground(BG_DARK);
        codeScroll.setRowHeaderView(lineNumbers);
        textPanel.add(codeScroll);

        // Block editor placeholder
        JPanel blockPanel = new JPanel(new BorderLayout());
        blockPanel.setBackground(BG_DARK);
        JLabel blockPlaceholder = new JLabel("<html><center><br><br>Block Editor<br><small style='color:#888'>Coming soon...</small></center></html>", SwingConstants.CENTER);
        blockPlaceholder.setForeground(BPETheme.TEXT_DIM);
        blockPlaceholder.setFont(BPETheme.FONT_MONO);
        blockPanel.add(blockPlaceholder, BorderLayout.CENTER);

        codeContentPanel.add(textPanel, "text");
        codeContentPanel.add(blockPanel, "block");
        panel.add(codeContentPanel, BorderLayout.CENTER);

        // Toggle actions
        blockBtn.addActionListener(e -> {
            isBlockMode = true;
            ((CardLayout) codeContentPanel.getLayout()).show(codeContentPanel, "block");
            blockBtn.setForeground(BPETheme.ACCENT);
            textBtn.setForeground(BPETheme.TEXT_DIM);
        });
        textBtn.addActionListener(e -> {
            isBlockMode = false;
            ((CardLayout) codeContentPanel.getLayout()).show(codeContentPanel, "text");
            textBtn.setForeground(BPETheme.ACCENT);
            blockBtn.setForeground(BPETheme.TEXT_DIM);
        });

        return panel;
    }

    private DefaultListModel<String> soundListModel = new DefaultListModel<>();

    private JPanel buildSoundsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BG_DARK);

        // Header + import button
        JPanel header = new JPanel(new BorderLayout(6,0));
        header.setBackground(BG_HEADER);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0,0,1,0, BPETheme.BORDER),
            BorderFactory.createEmptyBorder(6,10,6,10)));
        JLabel lbl = new JLabel("Sounds");
        lbl.setForeground(TEXT);
        lbl.setFont(BPETheme.FONT_MONO_BOLD);
        JButton importBtn = BPETheme.secondaryButton("+ Import");
        importBtn.setFont(BPETheme.FONT_MONO_SMALL);
        importBtn.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            fc.setMultiSelectionEnabled(true);
            fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                "Audio (mp3, wav, ogg)", "mp3", "wav", "ogg"));
            if (fc.showOpenDialog(panel) == JFileChooser.APPROVE_OPTION) {
                for (java.io.File f : fc.getSelectedFiles()) {
                    String entry = f.getName();
                    if (!soundListModel.contains(entry)) soundListModel.addElement(entry);
                }
            }
        });
        header.add(lbl, BorderLayout.WEST);
        header.add(importBtn, BorderLayout.EAST);
        panel.add(header, BorderLayout.NORTH);

        // Sound list
        JList<String> soundList = new JList<>(soundListModel);
        soundList.setBackground(BG_DARK);
        soundList.setForeground(TEXT);
        soundList.setFont(BPETheme.FONT_MONO_SMALL);
        soundList.setCellRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(
                    JList<?> l, Object v, int i, boolean sel, boolean foc) {
                JLabel c = (JLabel) super.getListCellRendererComponent(l,v,i,sel,foc);
                c.setBorder(BorderFactory.createEmptyBorder(4,10,4,10));
                c.setIcon(new javax.swing.Icon(){
                    public void paintIcon(Component comp, Graphics g, int x, int y){
                        g.setColor(BPETheme.GREEN);
                        g.fillOval(x,y+2,8,8);
                    }
                    public int getIconWidth(){return 12;}
                    public int getIconHeight(){return 12;}
                });
                c.setBackground(sel ? BPETheme.BG_SELECTED : BG_DARK);
                c.setForeground(TEXT);
                return c;
            }
        });

        // Delete key removes entry
        soundList.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_DELETE) {
                    int idx = soundList.getSelectedIndex();
                    if (idx >= 0) soundListModel.remove(idx);
                }
            }
        });

        JScrollPane scroll = new JScrollPane(soundList);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setBackground(BG_DARK);
        panel.add(scroll, BorderLayout.CENTER);

        JLabel hint = new JLabel("  Del key to remove  |  mp3, wav, ogg supported");
        hint.setForeground(BPETheme.TEXT_DIM);
        hint.setFont(BPETheme.FONT_MONO_SMALL);
        hint.setBorder(BorderFactory.createEmptyBorder(4,6,4,6));
        panel.add(hint, BorderLayout.SOUTH);

        return panel;
    }

    private JButton toolbarBtn(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(BG_HEADER);
        btn.setForeground(BPETheme.TEXT_DIM);
        btn.setFont(BPETheme.FONT_MONO_SMALL);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BPETheme.BORDER),
            BorderFactory.createEmptyBorder(3, 8, 3, 8)
        ));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    public void loadObject(HierarchyNode node) {
        this.currentNode = node;
        objectNameLabel.setText(node.getName());
        fileTabLabel.setText("  " + node.getName() + (node.getType() == HierarchyNode.NodeType.OBJECT ? ".BCode" : ""));

        // Find the matching project object
        currentObject = null;
        if (editorFrame != null && node.getType() == HierarchyNode.NodeType.OBJECT) {
            for (BPEProject.ProjectObject obj : editorFrame.getProject().objects) {
                if (obj.name.equals(node.getName())) {
                    currentObject = obj;
                    break;
                }
            }
        }

        // Load properties
        propertiesPanel.loadObject(currentObject);

        // Load script
        if (node.getType() == HierarchyNode.NodeType.OBJECT) {
            String script = "";
            if (editorFrame != null && editorFrame.getProject().scripts.containsKey(node.getName())) {
                script = editorFrame.getProject().scripts.get(node.getName());
            }
            if (script.isEmpty()) {
                script = "script.start\n\n" +
                    "attach \"Banana Project Editor\";\n" +
                    "attach \"" + node.getName() + "\";\n\n" +
                    "event:onStart()\n" +
                    "    -- input script code here\n" +
                    "event.end\n\n" +
                    "script.end";
            }
            final String finalScript = script;
            try {
                codeEditor.getStyledDocument().remove(0, codeEditor.getStyledDocument().getLength());
                codeEditor.getStyledDocument().insertString(0, finalScript, null);
            } catch (Exception ignored) {}
        }
    }

    public void syncScriptsToProject(BPEProject project) {
        if (currentNode != null && currentNode.getType() == HierarchyNode.NodeType.OBJECT) {
            project.scripts.put(currentNode.getName(), getCode());
        }
    }

    public String getCode() {
        try { return codeEditor.getDocument().getText(0, codeEditor.getDocument().getLength()); }
        catch (Exception e) { return ""; }
    }
}
