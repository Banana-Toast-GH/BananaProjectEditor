package com.bpe.editor;

import com.bpe.project.BPEProject;
import com.bpe.ui.BPETheme;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.*;

/**
 * Properties panel shown as first tab in Object Editor.
 * Lets you edit position, size, rotation, opacity, color, layer.
 */
public class PropertiesPanel extends JPanel {

    private BPEProject.ProjectObject currentObject;
    private EditorFrame editorFrame;
    private boolean updating = false;

    // Fields
    private JTextField nameField;
    private JTextField xField, yField;
    private JTextField wField, hField;
    private JTextField rotField;
    private JSlider opacitySlider;
    private JLabel opacityLabel;
    private JCheckBox visibleCheck;
    private JButton colorBtn;
    private JSpinner layerSpinner;
    private JLabel colorPreview;
    private JLabel noSelectionLabel;
    private JPanel fieldsPanel;

    private static final Color BG = BPETheme.BG_DEEP;
    private static final Color BG_FIELD = BPETheme.BG_RAISED;
    private static final Color TEXT = BPETheme.TEXT_PRIMARY;
    private static final Color TEXT_DIM = BPETheme.TEXT_SECONDARY;
    private static final Color BORDER = BPETheme.BORDER;

    public PropertiesPanel(EditorFrame editorFrame) {
        this.editorFrame = editorFrame;
        setLayout(new BorderLayout());
        setBackground(BG);

        // No selection state
        noSelectionLabel = new JLabel("Select an object to edit properties");
        noSelectionLabel.setForeground(BPETheme.TEXT_DIM);
        noSelectionLabel.setFont(BPETheme.FONT_MONO);
        noSelectionLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Fields panel
        fieldsPanel = new JPanel();
        fieldsPanel.setLayout(new BoxLayout(fieldsPanel, BoxLayout.Y_AXIS));
        fieldsPanel.setBackground(BG);
        fieldsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        buildFields();

        JScrollPane scroll = new JScrollPane(fieldsPanel);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(BG);
        scroll.setBackground(BG);

        showNoSelection();
    }

    private void buildFields() {
        // Name
        fieldsPanel.add(sectionLabel("IDENTITY"));
        nameField = styledField("Name");
        fieldsPanel.add(labeledRow("Name", nameField));
        fieldsPanel.add(gap());

        // Transform
        fieldsPanel.add(sectionLabel("TRANSFORM"));
        xField = styledField("0");
        yField = styledField("0");
        fieldsPanel.add(labeledRow("X", xField));
        fieldsPanel.add(gap(4));
        fieldsPanel.add(labeledRow("Y", yField));
        fieldsPanel.add(gap(4));
        wField = styledField("50");
        hField = styledField("50");
        fieldsPanel.add(labeledRow("Width", wField));
        fieldsPanel.add(gap(4));
        fieldsPanel.add(labeledRow("Height", hField));
        fieldsPanel.add(gap(4));
        rotField = styledField("0");
        fieldsPanel.add(labeledRow("Rotation", rotField));
        fieldsPanel.add(gap());

        // Appearance
        fieldsPanel.add(sectionLabel("APPEARANCE"));

        // Opacity slider
        JPanel opacityRow = new JPanel(new BorderLayout(6, 0));
        opacityRow.setBackground(BG);
        opacityRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        JLabel opLbl = new JLabel("Opacity");
        opLbl.setForeground(TEXT_DIM);
        opLbl.setFont(BPETheme.FONT_MONO_SMALL);
        opLbl.setPreferredSize(new Dimension(70, 20));
        opacitySlider = new JSlider(0, 100, 100);
        opacitySlider.setBackground(BG);
        opacitySlider.setForeground(BPETheme.ACCENT);
        opacityLabel = new JLabel("100%");
        opacityLabel.setForeground(TEXT_DIM);
        opacityLabel.setFont(BPETheme.FONT_MONO_SMALL);
        opacityLabel.setPreferredSize(new Dimension(36, 20));
        opacityRow.add(opLbl, BorderLayout.WEST);
        opacityRow.add(opacitySlider, BorderLayout.CENTER);
        opacityRow.add(opacityLabel, BorderLayout.EAST);
        fieldsPanel.add(opacityRow);
        fieldsPanel.add(gap(4));

        // Visible checkbox
        JPanel visRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        visRow.setBackground(BG);
        visRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        visibleCheck = new JCheckBox("Visible");
        visibleCheck.setBackground(BG);
        visibleCheck.setForeground(TEXT_DIM);
        visibleCheck.setFont(BPETheme.FONT_MONO_SMALL);
        visibleCheck.setSelected(true);
        visRow.add(visibleCheck);
        fieldsPanel.add(visRow);
        fieldsPanel.add(gap(4));

        // Color/Tint
        JPanel colorRow = new JPanel(new BorderLayout(6, 0));
        colorRow.setBackground(BG);
        colorRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        JLabel colorLbl = new JLabel("Tint");
        colorLbl.setForeground(TEXT_DIM);
        colorLbl.setFont(BPETheme.FONT_MONO_SMALL);
        colorLbl.setPreferredSize(new Dimension(70, 20));
        colorPreview = new JLabel("  ");
        colorPreview.setOpaque(true);
        colorPreview.setBackground(Color.WHITE);
        colorPreview.setPreferredSize(new Dimension(30, 20));
        colorPreview.setBorder(BorderFactory.createLineBorder(BORDER));
        colorBtn = new JButton("Choose...");
        colorBtn.setFont(BPETheme.FONT_MONO_SMALL);
        colorBtn.setForeground(TEXT_DIM);
        colorBtn.setBackground(BG_FIELD);
        colorBtn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(2, 8, 2, 8)
        ));
        colorBtn.setFocusPainted(false);
        colorBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        JPanel colorRight = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        colorRight.setBackground(BG);
        colorRight.add(colorPreview);
        colorRight.add(colorBtn);
        colorRow.add(colorLbl, BorderLayout.WEST);
        colorRow.add(colorRight, BorderLayout.CENTER);
        fieldsPanel.add(colorRow);
        fieldsPanel.add(gap());

        // Layer
        fieldsPanel.add(sectionLabel("RENDERING"));
        layerSpinner = new JSpinner(new SpinnerNumberModel(0, -100, 100, 1));
        layerSpinner.setBackground(BG_FIELD);
        layerSpinner.setFont(BPETheme.FONT_MONO_SMALL);
        layerSpinner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        fieldsPanel.add(labeledRow("Layer", layerSpinner));

        // Wire up listeners
        wireListeners();
    }

    private void wireListeners() {
        DocumentListener dl = new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { applyChanges(); }
            public void removeUpdate(DocumentEvent e) { applyChanges(); }
            public void changedUpdate(DocumentEvent e) { applyChanges(); }
        };

        nameField.getDocument().addDocumentListener(dl);
        xField.getDocument().addDocumentListener(dl);
        yField.getDocument().addDocumentListener(dl);
        wField.getDocument().addDocumentListener(dl);
        hField.getDocument().addDocumentListener(dl);
        rotField.getDocument().addDocumentListener(dl);

        opacitySlider.addChangeListener(e -> {
            if (!updating && currentObject != null) {
                currentObject.opacity = opacitySlider.getValue() / 100.0;
                opacityLabel.setText(opacitySlider.getValue() + "%");
                editorFrame.markUnsaved();
            }
        });

        visibleCheck.addActionListener(e -> {
            if (!updating && currentObject != null) {
                currentObject.visible = visibleCheck.isSelected();
                editorFrame.markUnsaved();
            }
        });

        colorBtn.addActionListener(e -> {
            if (currentObject == null) return;
            Color chosen = JColorChooser.showDialog(this, "Choose Tint Color", currentObject.getAwtColor());
            if (chosen != null) {
                currentObject.color = String.format("#%02X%02X%02X", chosen.getRed(), chosen.getGreen(), chosen.getBlue());
                colorPreview.setBackground(chosen);
                editorFrame.markUnsaved();
            }
        });

        layerSpinner.addChangeListener(e -> {
            if (!updating && currentObject != null) {
                currentObject.layer = (Integer) layerSpinner.getValue();
                editorFrame.markUnsaved();
            }
        });
    }

    private void applyChanges() {
        if (updating || currentObject == null) return;
        try {
            currentObject.x = parseDouble(xField.getText(), currentObject.x);
            currentObject.y = parseDouble(yField.getText(), currentObject.y);
            currentObject.width = parseDouble(wField.getText(), currentObject.width);
            currentObject.height = parseDouble(hField.getText(), currentObject.height);
            currentObject.rotation = parseDouble(rotField.getText(), currentObject.rotation);
            editorFrame.markUnsaved();
        } catch (Exception ignored) {}
    }

    private double parseDouble(String s, double fallback) {
        try { return Double.parseDouble(s.trim()); }
        catch (Exception e) { return fallback; }
    }

    public void loadObject(BPEProject.ProjectObject obj) {
        this.currentObject = obj;
        if (obj == null) { showNoSelection(); return; }

        showFields();
        updating = true;

        nameField.setText(obj.name);
        xField.setText(String.valueOf((int) obj.x));
        yField.setText(String.valueOf((int) obj.y));
        wField.setText(String.valueOf((int) obj.width));
        hField.setText(String.valueOf((int) obj.height));
        rotField.setText(String.valueOf((int) obj.rotation));
        opacitySlider.setValue((int)(obj.opacity * 100));
        opacityLabel.setText((int)(obj.opacity * 100) + "%");
        visibleCheck.setSelected(obj.visible);
        colorPreview.setBackground(obj.getAwtColor());
        layerSpinner.setValue(obj.layer);

        updating = false;
    }

    public void clearObject() {
        currentObject = null;
        showNoSelection();
    }

    private void showNoSelection() {
        removeAll();
        add(noSelectionLabel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private void showFields() {
        removeAll();
        JScrollPane scroll = new JScrollPane(fieldsPanel);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(BG);
        scroll.setBackground(BG);
        add(scroll, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    // --- UI helpers ---
    private JLabel sectionLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setForeground(BPETheme.ACCENT);
        lbl.setFont(new Font("Consolas", Font.BOLD, 9));
        lbl.setBorder(BorderFactory.createEmptyBorder(6, 0, 4, 0));
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private JTextField styledField(String text) {
        JTextField f = new JTextField(text);
        f.setBackground(BG_FIELD);
        f.setForeground(TEXT);
        f.setFont(BPETheme.FONT_MONO_SMALL);
        f.setCaretColor(BPETheme.ACCENT);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(3, 6, 3, 6)
        ));
        return f;
    }

    private JPanel labeledRow(String label, JComponent field) {
        JPanel row = new JPanel(new BorderLayout(6, 0));
        row.setBackground(BG);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel lbl = new JLabel(label);
        lbl.setForeground(TEXT_DIM);
        lbl.setFont(BPETheme.FONT_MONO_SMALL);
        lbl.setPreferredSize(new Dimension(70, 20));
        row.add(lbl, BorderLayout.WEST);
        row.add(field, BorderLayout.CENTER);
        return row;
    }

    private Component gap() { return Box.createVerticalStrut(10); }
    private Component gap(int h) { return Box.createVerticalStrut(h); }
}
