package com.bpe.editor;

import com.bpe.project.BPEProject;
import com.bpe.ui.BPETheme;

import javax.swing.*;
import javax.swing.TransferHandler;
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Editor scene canvas.
 *
 * COORDINATE MODEL
 *   • Objects are stored in "game space": (0,0) = top-left of the white game rect.
 *   • The canvas draws the game rect centred with offset (ox, oy).
 *   • All mouse ↔ object conversions subtract / add that offset.
 *   • GameWindow has NO offset (the whole panel IS the game), so coords match.
 */
public class SceneCanvas extends JPanel {

    public static boolean lightMode = false;

    private final BPEProject project;
    private BPEProject.ProjectObject selected  = null;
    private BPEProject.ProjectObject dragging  = null;
    private int dragDx, dragDy;
    private Runnable onMoved;

    public SceneCanvas(BPEProject project) {
        this.project = project;
        setBackground(darkBg());
        setBorder(BorderFactory.createLineBorder(BPETheme.BORDER));

        // ── accept drops from hierarchy ───────────────────────────────────────
        setTransferHandler(new TransferHandler() {
            @Override public boolean canImport(TransferSupport s) {
                return s.isDataFlavorSupported(DataFlavor.stringFlavor);
            }
            @Override public boolean importData(TransferSupport s) {
                try {
                    String name = (String) s.getTransferable().getTransferData(DataFlavor.stringFlavor);
                    Point dp = s.getDropLocation().getDropPoint();
                    int gx = dp.x - ox();
                    int gy = dp.y - oy();
                    for (BPEProject.ProjectObject obj : project.objects) {
                        if (obj.name.equals(name)) {
                            obj.x = gx - obj.width  / 2;
                            obj.y = gy - obj.height / 2;
                            selected = obj;
                            repaint();
                            if (onMoved != null) onMoved.run();
                            return true;
                        }
                    }
                } catch (Exception ignored) {}
                return false;
            }
        });

        // ── mouse ─────────────────────────────────────────────────────────────
        MouseAdapter m = new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) {
                int gx = e.getX() - ox();
                int gy = e.getY() - oy();
                selected = null; dragging = null;
                // reverse order → top layer first
                List<BPEProject.ProjectObject> objs = sorted();
                for (int i = objs.size()-1; i >= 0; i--) {
                    BPEProject.ProjectObject o = objs.get(i);
                    if (!o.visible) continue;
                    if (gx >= o.x && gx <= o.x+o.width && gy >= o.y && gy <= o.y+o.height) {
                        selected = o; dragging = o;
                        dragDx = (int)(gx - o.x);
                        dragDy = (int)(gy - o.y);
                        break;
                    }
                }
                repaint();
            }
            @Override public void mouseDragged(MouseEvent e) {
                if (dragging == null) return;
                int gx = e.getX() - ox();
                int gy = e.getY() - oy();
                dragging.x = gx - dragDx;
                dragging.y = gy - dragDy;
                repaint();
                if (onMoved != null) onMoved.run();
            }
            @Override public void mouseReleased(MouseEvent e) { dragging = null; }
        };
        addMouseListener(m);
        addMouseMotionListener(m);
    }

    // canvas-centre offset = game-rect top-left in screen space
    private int ox() { return Math.max(0, (getWidth()  - project.settings.windowWidth)  / 2); }
    private int oy() { return Math.max(0, (getHeight() - project.settings.windowHeight) / 2); }

    public void setOnObjectMoved(Runnable r) { this.onMoved = r; }
    public BPEProject.ProjectObject getSelectedObject() { return selected; }

    private List<BPEProject.ProjectObject> sorted() {
        List<BPEProject.ProjectObject> s = new ArrayList<>(project.objects);
        s.sort((a, b) -> Integer.compare(a.layer, b.layer));
        return s;
    }

    private Color darkBg()  { return lightMode ? new Color(215,215,222) : new Color(18,18,22); }
    private Color gridCol() { return lightMode ? new Color(195,195,205) : new Color(28,28,33); }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // ── background grid ───────────────────────────────────────────────────
        g2.setColor(darkBg());
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.setColor(gridCol());
        int gs = 20;
        for (int x=0; x<getWidth();  x+=gs) g2.drawLine(x,0,x,getHeight());
        for (int y=0; y<getHeight(); y+=gs) g2.drawLine(0,y,getWidth(),y);

        // ── game rect ─────────────────────────────────────────────────────────
        int ox = ox(), oy = oy();
        Color bgColor = Color.WHITE;
        try { bgColor = Color.decode(project.settings.backgroundColor); } catch (Exception ignored) {}
        g2.setColor(bgColor);
        g2.fillRect(ox, oy, project.settings.windowWidth, project.settings.windowHeight);
        g2.setColor(new Color(100,100,110));
        g2.setStroke(new BasicStroke(1.5f));
        g2.drawRect(ox, oy, project.settings.windowWidth, project.settings.windowHeight);
        g2.setStroke(new BasicStroke(1f));

        // ── objects ───────────────────────────────────────────────────────────
        for (BPEProject.ProjectObject obj : sorted()) {
            // screen position = canvas offset + game-space position
            int x = ox + (int) obj.x;
            int y = oy + (int) obj.y;
            int w = Math.max(4, (int) obj.width);
            int h = Math.max(4, (int) obj.height);
            boolean sel = obj == selected;

            Color tint = obj.getAwtColor();
            Color fill = blend(baseColor(obj.type), tint);
            Color dark = fill.darker();

            float visAlpha = obj.visible ? 0.90f : 0.25f;
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, visAlpha));

            switch (obj.type) {
                case "UIButton": {
                    GradientPaint gp = new GradientPaint(x,y, fill.brighter(), x,y+h, fill);
                    g2.setPaint(gp);
                    g2.fillRoundRect(x,y,w,h,10,10);
                    g2.setColor(dark);
                    g2.setStroke(new BasicStroke(1.2f));
                    g2.drawRoundRect(x,y,w,h,10,10);
                    break;
                }
                case "Camera2D": case "Viewport": {
                    g2.setColor(new Color(80,200,200,50));
                    g2.fillRect(x,y,w,h);
                    g2.setColor(new Color(80,200,200));
                    float[] dash = {6,4};
                    g2.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1f, dash, 0));
                    g2.drawRect(x,y,w,h);
                    break;
                }
                case "Light2D": {
                    g2.setColor(new Color(255,240,100,40));
                    g2.fillOval(x,y,w,h);
                    g2.setColor(new Color(255,240,100,160));
                    g2.setStroke(new BasicStroke(1f));
                    g2.drawOval(x,y,w,h);
                    break;
                }
                default: {
                    g2.setColor(fill);
                    g2.fillRect(x,y,w,h);
                    g2.setColor(dark);
                    g2.setStroke(new BasicStroke(1f));
                    g2.drawRect(x,y,w,h);
                }
            }

            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
            g2.setStroke(new BasicStroke(1f));

            // name tag
            g2.setColor(sel ? BPETheme.ACCENT : new Color(220,220,220));
            if (lightMode) g2.setColor(sel ? BPETheme.ACCENT_DIM : new Color(30,30,40));
            g2.setFont(new Font("Consolas", Font.PLAIN, 9));
            g2.drawString(obj.type + ": " + obj.name, x+3, y+11);

            // selection border + handles
            if (sel) {
                g2.setColor(BPETheme.ACCENT);
                g2.setStroke(new BasicStroke(2f));
                g2.drawRect(x-1, y-1, w+2, h+2);
                g2.setStroke(new BasicStroke(1f));
                int hs = 7;
                int[][] corners = {{x,y},{x+w,y},{x,y+h},{x+w,y+h}};
                for (int[] c : corners) {
                    g2.setColor(BPETheme.ACCENT);
                    g2.fillRect(c[0]-hs/2, c[1]-hs/2, hs, hs);
                    g2.setColor(Color.WHITE);
                    g2.drawRect(c[0]-hs/2, c[1]-hs/2, hs, hs);
                }
            }
        }

        // ── empty hint ────────────────────────────────────────────────────────
        if (project.objects.isEmpty()) {
            g2.setColor(BPETheme.TEXT_DIM);
            g2.setFont(new Font("Consolas", Font.PLAIN, 12));
            String msg = "Use [+] to add objects, then drag them here";
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(msg, (getWidth()-fm.stringWidth(msg))/2, getHeight()/2);
        }

        // ── HUD ───────────────────────────────────────────────────────────────
        if (selected != null) {
            String hud = selected.name
                + "   x:" + (int)selected.x + "  y:" + (int)selected.y
                + "   " + (int)selected.width + "×" + (int)selected.height;
            g2.setFont(new Font("Consolas", Font.PLAIN, 10));
            FontMetrics fm = g2.getFontMetrics();
            int pw = fm.stringWidth(hud) + 16;
            g2.setColor(new Color(0,0,0,180));
            g2.fillRoundRect(6, getHeight()-26, pw, 20, 6, 6);
            g2.setColor(BPETheme.ACCENT);
            g2.drawString(hud, 14, getHeight()-11);
        }
    }

    private Color baseColor(String type) {
        switch (type) {
            case "Sprite": case "AnimatedSprite": case "Image": return new Color(130,190,255);
            case "Part":          return new Color(160,165,175);
            case "UIButton":      return new Color(220,120, 80);
            case "UILabel": case "Label": return new Color(240,220, 60);
            case "UIFrame":       return new Color(180,180,220);
            case "RigidBody":     return new Color(240,160, 40);
            case "Collider":      return new Color(240,200, 40);
            case "TriggerZone":   return new Color(180,240, 80);
            case "ParticleSystem":return new Color(255,130, 50);
            case "Sound": case "Music": return new Color(80,220,140);
            case "Light2D":       return new Color(255,240,100);
            default:              return new Color(180,180,195);
        }
    }

    private Color blend(Color base, Color tint) {
        if (tint == null || tint.equals(Color.WHITE)) return base;
        return new Color(
            Math.min(255, base.getRed()   * tint.getRed()   / 255),
            Math.min(255, base.getGreen() * tint.getGreen() / 255),
            Math.min(255, base.getBlue()  * tint.getBlue()  / 255)
        );
    }
}
