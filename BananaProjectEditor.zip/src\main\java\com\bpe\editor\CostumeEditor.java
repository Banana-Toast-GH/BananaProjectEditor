package com.bpe.editor;

import com.bpe.ui.BPETheme;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Costume drawing editor. Fixed coordinate scaling and tool dispatch.
 */
public class CostumeEditor extends JPanel {

    private static final int CW = 200, CH = 200, SCALE = 3;

    private final BufferedImage canvas = new BufferedImage(CW, CH, BufferedImage.TYPE_INT_ARGB);
    private final Graphics2D    cg     = canvas.createGraphics();
    private final DrawPanel     drawPanel;

    // drawing state - kept in outer class so DrawPanel can always access them
    private Color   color    = Color.BLACK;
    private int     brush    = 5;
    private Tool    tool     = Tool.PENCIL;
    private int     lastX = -1, lastY = -1;
    private int     lineX0, lineY0;
    private BufferedImage lineSnap;

    private JLabel  activeSwatch;

    enum Tool { PENCIL, ERASER, FILL, LINE }

    public CostumeEditor() {
        setLayout(new BorderLayout());
        setBackground(BPETheme.BG_DEEP);
        cg.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        clearCanvas();

        drawPanel = new DrawPanel();
        add(buildToolbar(), BorderLayout.NORTH);
        add(buildCenter(),  BorderLayout.CENTER);
        add(buildColors(),  BorderLayout.SOUTH);
    }

    // ── toolbar ───────────────────────────────────────────────────────────────
    private JPanel buildToolbar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 4));
        bar.setBackground(BPETheme.BG_MID);
        bar.setBorder(BorderFactory.createMatteBorder(0,0,1,0, BPETheme.BORDER));

        ButtonGroup grp = new ButtonGroup();
        for (Tool t : Tool.values()) {
            JToggleButton b = new JToggleButton(capitalize(t.name()));
            b.setFont(BPETheme.FONT_MONO_SMALL);
            b.setForeground(t == Tool.PENCIL ? BPETheme.ACCENT : BPETheme.TEXT_SECONDARY);
            b.setBackground(BPETheme.BG_RAISED);
            b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BPETheme.BORDER),
                BorderFactory.createEmptyBorder(3,8,3,8)));
            b.setFocusPainted(false);
            b.setSelected(t == Tool.PENCIL);
            b.addActionListener(e -> { tool = t; b.setForeground(BPETheme.ACCENT); });
            b.addItemListener(e -> { if (e.getStateChange() == ItemEvent.DESELECTED) b.setForeground(BPETheme.TEXT_SECONDARY); });
            grp.add(b); bar.add(b);
        }

        bar.add(Box.createHorizontalStrut(8));
        JLabel sl = label("Size:");
        JSpinner sz = new JSpinner(new SpinnerNumberModel(brush, 1, 40, 1));
        sz.setPreferredSize(new Dimension(52, 22));
        sz.setFont(BPETheme.FONT_MONO_SMALL);
        sz.addChangeListener(e -> brush = (Integer) sz.getValue());
        bar.add(sl); bar.add(sz);

        bar.add(Box.createHorizontalStrut(6));
        JButton clear = BPETheme.secondaryButton("Clear");
        clear.setFont(BPETheme.FONT_MONO_SMALL);
        clear.addActionListener(e -> { clearCanvas(); drawPanel.repaint(); });
        bar.add(clear);

        JButton imp = BPETheme.secondaryButton("Import…");
        imp.setFont(BPETheme.FONT_MONO_SMALL);
        imp.addActionListener(e -> importImg());
        bar.add(imp);

        JButton exp = BPETheme.secondaryButton("Export…");
        exp.setFont(BPETheme.FONT_MONO_SMALL);
        exp.addActionListener(e -> exportImg());
        bar.add(exp);

        return bar;
    }

    private JPanel buildCenter() {
        JPanel wrap = new JPanel(new GridBagLayout());
        wrap.setBackground(BPETheme.BG_DEEPEST);
        wrap.add(drawPanel);
        return wrap;
    }

    // ── colour bar ────────────────────────────────────────────────────────────
    private JPanel buildColors() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        bar.setBackground(BPETheme.BG_MID);
        bar.setBorder(BorderFactory.createMatteBorder(1,0,0,0, BPETheme.BORDER));
        bar.add(label("Color:"));

        Color[] presets = {
            Color.BLACK, Color.WHITE,
            new Color(220,60,60), new Color(60,180,60), new Color(60,100,220),
            new Color(255,200,30), new Color(255,130,0), new Color(200,60,200),
            new Color(0,200,220), new Color(140,90,40), new Color(140,140,140)
        };
        for (Color c : presets) bar.add(swatch(c));

        JButton pick = new JButton("⋯");
        pick.setFont(BPETheme.FONT_MONO_SMALL);
        pick.setPreferredSize(new Dimension(26,20));
        pick.setBackground(BPETheme.BG_RAISED);
        pick.setForeground(BPETheme.TEXT_DIM);
        pick.setBorder(BorderFactory.createLineBorder(BPETheme.BORDER));
        pick.setFocusPainted(false);
        pick.addActionListener(e -> { Color c = JColorChooser.showDialog(this,"Pick",color); if(c!=null){color=c;refreshSwatch();} });
        bar.add(pick);

        bar.add(Box.createHorizontalStrut(6));
        bar.add(label("Active:"));
        activeSwatch = new JLabel("  ");
        activeSwatch.setOpaque(true);
        activeSwatch.setBackground(color);
        activeSwatch.setPreferredSize(new Dimension(22,20));
        activeSwatch.setBorder(BorderFactory.createLineBorder(BPETheme.BORDER));
        bar.add(activeSwatch);

        return bar;
    }

    private JButton swatch(Color c) {
        JButton b = new JButton();
        b.setBackground(c);
        b.setPreferredSize(new Dimension(20,20));
        b.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY));
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addActionListener(e -> { color = c; refreshSwatch(); });
        return b;
    }

    private void refreshSwatch() {
        if (activeSwatch != null) { activeSwatch.setBackground(color); activeSwatch.repaint(); }
    }

    // ── ops ───────────────────────────────────────────────────────────────────
    private void clearCanvas() {
        cg.setComposite(AlphaComposite.Clear);
        cg.fillRect(0,0,CW,CH);
        cg.setComposite(AlphaComposite.SrcOver);
        cg.setColor(Color.WHITE);
        cg.fillRect(0,0,CW,CH);
    }

    private void floodFill(int x, int y) {
        if (x<0||x>=CW||y<0||y>=CH) return;
        int target = canvas.getRGB(x,y), fill = color.getRGB();
        if (target == fill) return;
        Queue<Point> q = new LinkedList<>();
        q.add(new Point(x,y));
        while (!q.isEmpty()) {
            Point p = q.poll();
            if (p.x<0||p.x>=CW||p.y<0||p.y>=CH) continue;
            if (canvas.getRGB(p.x,p.y) != target) continue;
            canvas.setRGB(p.x,p.y,fill);
            q.add(new Point(p.x+1,p.y)); q.add(new Point(p.x-1,p.y));
            q.add(new Point(p.x,p.y+1)); q.add(new Point(p.x,p.y-1));
        }
    }

    private void stroke(int x1, int y1, int x2, int y2) {
        cg.setStroke(new BasicStroke(brush, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        cg.setColor(tool == Tool.ERASER ? Color.WHITE : color);
        if (x1<0) { x1=x2; y1=y2; }
        cg.drawLine(x1,y1,x2,y2);
    }

    private void importImg() {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Images","png","jpg","jpeg","bmp"));
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try {
            BufferedImage img = ImageIO.read(fc.getSelectedFile());
            cg.drawImage(img, 0, 0, CW, CH, null);
            drawPanel.repaint();
        } catch (Exception ex) { JOptionPane.showMessageDialog(this, "Error: "+ex.getMessage()); }
    }

    private void exportImg() {
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new File("costume.png"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        try {
            File f = fc.getSelectedFile();
            if (!f.getName().endsWith(".png")) f = new File(f.getAbsolutePath()+".png");
            ImageIO.write(canvas,"PNG",f);
            JOptionPane.showMessageDialog(this,"Saved: "+f.getName());
        } catch (Exception ex) { JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage()); }
    }

    public BufferedImage getImage() { return canvas; }

    // ── helpers ───────────────────────────────────────────────────────────────
    private JLabel label(String t) {
        JLabel l = new JLabel(t);
        l.setForeground(BPETheme.TEXT_SECONDARY);
        l.setFont(BPETheme.FONT_MONO_SMALL);
        return l;
    }
    private String capitalize(String s) {
        return s.isEmpty() ? s : s.charAt(0) + s.substring(1).toLowerCase();
    }

    // ── draw panel (inner class — accesses outer fields directly) ─────────────
    private class DrawPanel extends JPanel {
        DrawPanel() {
            setPreferredSize(new Dimension(CW*SCALE, CH*SCALE));
            setBorder(BorderFactory.createLineBorder(BPETheme.BORDER, 2));
            setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
            setOpaque(true);

            addMouseListener(new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) {
                    int cx = clampX(e.getX()), cy = clampY(e.getY());
                    if (tool == Tool.FILL) {
                        floodFill(cx, cy);
                    } else if (tool == Tool.LINE) {
                        lineX0 = cx; lineY0 = cy;
                        lineSnap = new BufferedImage(CW, CH, BufferedImage.TYPE_INT_ARGB);
                        lineSnap.createGraphics().drawImage(canvas, 0, 0, null);
                    } else {
                        stroke(cx, cy, cx, cy);
                    }
                    lastX = cx; lastY = cy;
                    repaint();
                }
                @Override public void mouseReleased(MouseEvent e) {
                    lastX = -1; lastY = -1; lineSnap = null;
                }
            });

            addMouseMotionListener(new MouseMotionAdapter() {
                @Override public void mouseDragged(MouseEvent e) {
                    int cx = clampX(e.getX()), cy = clampY(e.getY());
                    if (tool == Tool.LINE && lineSnap != null) {
                        cg.drawImage(lineSnap, 0, 0, null);
                        cg.setStroke(new BasicStroke(brush, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                        cg.setColor(color);
                        cg.drawLine(lineX0, lineY0, cx, cy);
                    } else if (tool != Tool.FILL) {
                        stroke(lastX, lastY, cx, cy);
                    }
                    lastX = cx; lastY = cy;
                    repaint();
                }
            });
        }

        private int clampX(int px) { return Math.max(0, Math.min(CW-1, px/SCALE)); }
        private int clampY(int py) { return Math.max(0, Math.min(CH-1, py/SCALE)); }

        @Override protected void paintComponent(Graphics g) {
            // Draw checkerboard (do NOT call super - we own the whole background)
            for (int ty=0; ty<CH; ty+=8)
                for (int tx=0; tx<CW; tx+=8) {
                    g.setColor(((tx/8+ty/8)%2==0) ? new Color(205,205,205) : new Color(245,245,245));
                    g.fillRect(tx*SCALE, ty*SCALE, 8*SCALE, 8*SCALE);
                }
            // Paint canvas image on top
            g.drawImage(canvas, 0, 0, CW*SCALE, CH*SCALE, null);
        }
    }
}
